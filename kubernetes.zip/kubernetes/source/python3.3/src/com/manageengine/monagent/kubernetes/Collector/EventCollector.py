from datetime import datetime
import traceback
import sys, copy, time

from com.manageengine.monagent.kubernetes.Logging import KubeLogger as AgentLogger
from com.manageengine.monagent.kubernetes import KubeGlobal
from com.manageengine.monagent.kubernetes.Collector.DataCollector import DataCollector

if 'com.manageengine.monagent.kubernetes.KubeUtil' in sys.modules:
    KubeUtil = sys.modules['com.manageengine.monagent.kubernetes.KubeUtil']
else:
    from com.manageengine.monagent.kubernetes import KubeUtil

BUFFER_LIMIT = 3000
lastRepTime=None
bufLen=0

class EventCollector(DataCollector):
    def collect_data(self):
        global lastRepTime, bufLen
        try:
            self.final_json = []
            url = KubeGlobal.apiEndpoint + KubeGlobal.eventsListenerPath + '?limit=500'
            KubeUtil.get_api_data_by_limit(url, self.eventsFilter, self.final_json)
            lastRepTime = datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
            AgentLogger.log(AgentLogger.KUBERNETES, 'EventCollector ends')
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, 'Events Streaming stopped for {}'.format(e))
            traceback.print_exc()
        finally:
            bufLen = 0

    def eventsFilter(self, lineJson, final_data):
        global bufLen
        try:
            for event in lineJson["items"]:
                if bufLen > BUFFER_LIMIT:
                    AgentLogger.log(AgentLogger.KUBERNETES, 'Exceeded Buffer Limit of Events {}')
                    break

                if self.isValidEvent(event):
                    eveDict={}
                    self.eventParser(eveDict, event)
                    final_data.append(eveDict)
                    bufLen += 1
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, 'Exception while parsing the Events {}'.format(e))
            traceback.print_exc()

    @KubeUtil.exception_handler
    def eventParser(self, eveDict, event):
        if "metadata" in event and "creationTimestamp" in event["metadata"]:
            eveDict["EventTime"] = event["metadata"]["creationTimestamp"]
            if "deprecatedLastTimestamp" in event["metadata"]:
                eveDict["EventTime"] = event["metadata"]["deprecatedLastTimestamp"]

        if "regarding" in event:
            regDict = event["regarding"]
            if "kind" in regDict:
                eveDict["Kind"] = regDict["kind"]
            if "namespace" in regDict:
                eveDict["Namespace"] = regDict["namespace"]
            if "name" in regDict:
                eveDict["Name"] = regDict["name"]
            if "uid" in regDict:
                eveDict["Id"] = regDict["uid"]

        if "reason" in event:
            eveDict["Reason"] = event["reason"]
        if "note" in event:
            eveDict["Note"] = event["note"]
        if "type" in event:
            eveDict["Type"] = event["type"]
        if "deprecatedCount" in event:
            eveDict["deprecatedCount"] = event["deprecatedCount"]

        if "deprecatedSource" in event:
            source = ""
            if "component" in event["deprecatedSource"]:
                source += event["deprecatedSource"]["component"]
            if "host" in event["deprecatedSource"]:
                source += ", " + event["deprecatedSource"]["host"]
            eveDict["Source"] = source

        eveDict["_zl_timestamp"] = time.time() * 1000
        eveDict["s247agentuid"] = KubeGlobal.mid

    def isValidEvent(self, eventJson):
        try:
            if lastRepTime:
                eventTime = eventJson["deprecatedLastTimestamp"] if "deprecatedLastTimestamp" in eventJson else eventJson["metadata"]["creationTimestamp"]
                eventTime = eventTime.replace('T', ' ').replace('Z', '.0000')     #converting TimeStamp to datetime
                eventTime = datetime.strptime(eventTime, '%Y-%m-%d %H:%M:%S.%f')

                if lastRepTime > eventTime:
                    return False

            return True
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, 'Exception in isValidEvent {}'.format(e))
            traceback.print_exc()
            return False

    @KubeUtil.exception_handler
    def split_data(self):
        for listChunks in KubeUtil.list_chunks(self.final_json, int(KubeGlobal.eventsWriteCount)):
            self.final_splitted_data.append({
                    "k8s_events": listChunks
            })
