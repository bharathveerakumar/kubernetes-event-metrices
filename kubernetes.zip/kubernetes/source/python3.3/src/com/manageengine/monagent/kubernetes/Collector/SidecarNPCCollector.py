'''
@author: bharath.veerakumar

Created on Feb 20 2023
'''


import os
import traceback

from com.manageengine.monagent.kubernetes import KubeGlobal, KubeUtil
from com.manageengine.monagent.kubernetes.Collector.NPCDataCollector import NPCDataCollector
from com.manageengine.monagent.kubernetes.Logging import KubeLogger as AgentLogger


class SidecarNPCCollector(NPCDataCollector):
    def collect_data(self):
        # need to check whether site24x7-agent pod is running on this node
        # if running, then skip this DC of sidecar NPC
        status, response = KubeUtil.curl_api_with_token(KubeGlobal.apiEndpoint + '/api/v1/pods?fieldSelector=spec.nodeName={}&labelSelector=app%3Dsite24x7-agent'.format(KubeGlobal.nodeName))
        if status == 200 and len(response.get('items', [])):
            return
        super().collect_data()

    def merge_apis_data(self):
        super().merge_apis_data()
        sidecar_pod_name = os.environ.get("S247_POD_NAME") + "_" + os.environ.get("S247_POD_NS")
        self.final_json['Pods'] = {
            sidecar_pod_name: self.final_json['Pods'][sidecar_pod_name]
        }
        self.final_json['kubernetes'] = KubeUtil.fetch_cluster_metadata()
