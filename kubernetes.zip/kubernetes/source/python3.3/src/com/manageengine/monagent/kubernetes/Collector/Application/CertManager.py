from com.manageengine.monagent.kubernetes.Collector.DataCollectorInterface import DataCollector, DCRequisites
from com.manageengine.monagent.kubernetes.Collector.EventCollector import KubeUtil
from com.manageengine.monagent.kubernetes.Parser import ParserFactory


# class CertManager(DataCollector):
#     def collect_data(self):
#         self.final_json = ParserFactory.get_prometheus_parser('CertManager')()
#         self.final_json['Certificates'].update(
#             ParserFactory.get_json_parser('Certificates')().get_data()
#         )
#         self.final_json['Issuers'].update(
#             ParserFactory.get_json_parser('Issuers')().get_data()
#         )
#         self.final_json['ClusterIssuers'].update(
#             ParserFactory.get_json_parser('ClusterIssuers')().get_data()
#         )



final_json = ParserFactory.get_prometheus_parser('CertManager')().final_data
final_json['Certificates'] = KubeUtil.MergeDataDictionaries(
    ParserFactory.get_json_parser('Certificates')().get_data(),
    final_json['Certificates']
)
final_json['Issuers'] = ParserFactory.get_json_parser('Issuers')().get_data()
final_json['ClusterIssuers'] = ParserFactory.get_json_parser('ClusterIssuers')().get_data()

print(final_json)
