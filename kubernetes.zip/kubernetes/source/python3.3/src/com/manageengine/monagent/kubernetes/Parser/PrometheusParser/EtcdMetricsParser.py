import os
import traceback
from prometheus_client.parser import text_string_to_metric_families

from com.manageengine.monagent.kubernetes import KubeGlobal,KubeUtil
from com.manageengine.monagent.kubernetes.Logging import KubeLogger as AgentLogger
from com.manageengine.monagent.kubernetes.Parser.PrometheusParserInterface import PrometheusParser


def exception_handler(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, "*** EXCEPTION *** => [EtcdMetricsParser] => {} => {} => {} ******".format(func.__name__, e, traceback.format_exc()))
    return wrapper


class EtcdMetrics(PrometheusParser):
    @exception_handler
    def __init__(self, etcd_config):
        etcd_endpoint = KubeUtil.construct_node_ip_url('https://{}'+':{}/metrics'.format(etcd_config["port"]), etcd_config["ip"])
        self.health_endpoint = KubeUtil.construct_node_ip_url('https://{}'+':{}/health'.format(etcd_config["port"]), etcd_config["ip"])
        self.livez_endpoint = KubeUtil.construct_node_ip_url('https://{}'+':{}/livez'.format(etcd_config["port"]), etcd_config["ip"])
        self.dc_enabled = False
        self.auth_config = {}
        self.fetch_authentication_config()
        super().__init__(etcd_endpoint)
        self.parser_config = {
            "go_threads": [
                {
                    "short_name": "GT",
                    "group_name": "",
                },
            ],
            "go_goroutines": [
                {
                    "short_name": "GR",
                    "group_name": "",
                },
            ],
            "process_resident_memory_bytes": [
                {
                    "short_name": "PRMB",
                    "group_name": "",
                },
            ],
            "process_cpu_seconds": [
                {
                    "short_name": "PCS",
                    "group_name": "",
                },
            ],
            "process_open_fds": [
                {
                    "short_name": "POF",
                    "group_name": "",
                },
            ],
            "process_max_fds": [
                {
                    "short_name": "PMF",
                    "group_name": "",
                },
            ],
            "process_virtual_memory_bytes": [
                {
                    "short_name": "PVMB",
                    "group_name": "",
                },
            ],
            "etcd_server_id": [

                self.parse_etcd_server_id,
            ],
            "etcd_server_version": [

                self.parse_etcd_server_version,
            ],
            "os_fd_used": [
                {
                    "short_name": "OFU",
                    "group_name": "",
                },
            ],
            "os_fd_limit": [
                {
                    "short_name": "OFL",
                    "group_name": "",
                },
            ],
            "etcd_server_has_leader": [
                {
                    "short_name": "ESL",
                    "group_name": "",
                },
            ],
            "etcd_server_leader_changes_seen_total": [
                {
                    "short_name": "ESLCT",
                    "group_name": "",
                },
            ],
            "etcd_server_is_learner": [
                {
                    "short_name": "ESIL",
                    "group_name": "",
                },
            ],
            "etcd_server_health_failures": [
                {
                    "short_name": "ESHF",
                    "group_name": "",
                },
            ],
            "etcd_server_heartbeat_send_failures": [
                {
                    "short_name": "ESHSF",
                    "group_name": "",
                },
            ],
            "etcd_server_is_leader": [
                {
                    "short_name": "ESIS",
                    "group_name": "",
                },
            ],
            "etcd_server_health_success": [
                {
                    "short_name": "ESHS",
                    "group_name": "",
                },
            ],
            "etcd_server_leader_changes_seen": [
                {
                    "short_name": "ESLC",
                    "group_name": "",
                },
            ],
            "etcd_server_proposals_committed": [
                {
                    "short_name": "ESPC",
                    "group_name": "",
                },
            ],
            "etcd_server_proposals_committed_total": [
                {
                    "short_name": "ESPC",
                    "group_name": "",
                },
            ],
            "etcd_server_proposals_applied": [
                {
                    "short_name": "ESPA",
                    "group_name": "",
                },
            ],
            "etcd_server_proposals_applied_total": [
                {
                    "short_name": "ESPA",
                    "group_name": "",
                },
            ],
            "etcd_server_proposals_pending": [
                {
                    "short_name": "ESPP",
                    "group_name": "",
                },
            ],
            "etcd_server_proposals_failed": [
                {
                    "short_name": "ESPF",
                    "group_name": "",
                },
            ],
            "etcd_disk_wal_fsync_duration_seconds": [
                {
                    "short_name": "EDWFD",
                    "group_name": "",
                },
            ],
            "etcd_server_quota_backend_bytes": [
                {
                    "short_name": "ESQBB",
                    "group_name": "",
                },
            ],
            "etcd_server_read_indexes_failed": [
                {
                    "short_name": "ESRIF",
                    "group_name": "",
                },
            ],
            "etcd_server_slow_apply": [
                {
                    "short_name": "ESSA",
                    "group_name": "",
                },
            ],
            "etcd_server_slow_read_indexes": [
                {
                    "short_name": "ESSRI",
                    "group_name": "",
                },
            ],
            "etcd_disk_backend_commit_duration_seconds": [
                {
                    "short_name": "EDBC",
                    "group_name": "",
                },
            ],
            "etcd_snap_db_fsync_duration_seconds": [
                {
                    "short_name": "ESDFD",
                    "group_name": "",
                },
            ],
            "etcd_snap_db_save_total_duration_seconds": [
                {
                    "short_name": "ESDTD",
                    "group_name": "",
                },
            ],
            "etcd_snap_fsync_duration_seconds": [
                {
                    "short_name": "ESFDS",
                    "group_name": "",
                },
            ],
            "etcd_network_peer_round_trip_time_seconds": [
                {
                    "short_name": "ENPRT",
                    "group_name": "etcd_peers",
                    "labels": {
                        "To": "na"
                    },
                    "group_labels": ["To"],
                    "root_name": ["To"]
                },
            ],
            "etcd_network_peer_sent_bytes": [
                {
                    "short_name": "ENPSB",
                    "group_name": "etcd_peers",
                    "labels": {
                        "To": "na"
                    },
                    "group_labels": ["To"],
                    "root_name": ["To"]
                },
            ],
            "etcd_network_peer_received_bytes": [
                {
                    "short_name": "ENPRB",
                    "group_name": "etcd_peers",
                    "labels": {
                        "From": "na"
                    },
                    "group_labels": ["From"],
                    "root_name": ["From"]
                },
            ],
            "etcd_network_peer_sent_failures": [
                {
                    "short_name": "ENPSF",
                    "group_name": "etcd_peers",
                    "labels": {
                        "To": "na"
                    },
                    "group_labels": ["To"],
                    "root_name": ["To"]
                },
            ],
            "etcd_server_client_requests": [
                {
                    "short_name": "ESCR",
                    "sum": ["", "ESCR", "sum_only"]
                },
            ],
            "etcd_network_peer_received_failures": [
                {
                    "short_name": "ENPRF",
                    "group_name": "etcd_peers",
                    "labels": {
                        "From": "na"
                    },
                    "group_labels": ["From"],
                    "root_name": ["From"]
                },
            ],
            "etcd_debugging_mvcc_db_compaction_keys": [
                {
                    "short_name": "EDMDC",
                    "group_name": "",
                },
            ],
            "etcd_debugging_mvcc_db_compaction_pause_duration_milliseconds": [
                {
                    "short_name": "EDMDCP",
                    "group_name": "",
                },
            ],
            "etcd_debugging_mvcc_db_compaction_total_duration_milliseconds": [
                {
                    "short_name": "EDMDCT",
                    "group_name": "",
                },
            ],
            "etcd_debugging_mvcc_events": [
                {
                    "short_name": "EDME",
                    "group_name": "",
                },
            ],
            "etcd_debugging_mvcc_index_compaction_pause_duration_milliseconds": [
                {
                    "short_name": "EDCPD",
                    "group_name": "",
                },
            ],
            "etcd_debugging_mvcc_keys": [
                {
                    "short_name": "EDMK",
                    "group_name": "",
                },
            ],
            "etcd_debugging_mvcc_keys_total": [
                {
                    "short_name": "EDMK",
                    "group_name": "",
                },
            ],
            "etcd_debugging_mvcc_pending_events": [
                {
                    "short_name": "EDMPE",
                    "group_name": "",
                },
            ],
            "etcd_debugging_mvcc_pending_events_total": [
                {
                    "short_name": "EDMPE",
                    "group_name": "",
                },
            ],
            "etcd_debugging_mvcc_range": [
                {
                    "short_name": "EDMR",
                    "group_name": "",
                },
            ],
            "etcd_debugging_mvcc_slow_watcher": [
                {
                    "short_name": "EDMSW",
                    "group_name": "",
                },
            ],
            "etcd_debugging_mvcc_slow_watcher_total": [
                {
                    "short_name": "EDMSW",
                    "group_name": "",
                },
            ],
            "etcd_debugging_mvcc_watch_stream": [
                {
                    "short_name": "EDMWS",
                    "group_name": "",
                },
            ],
            "etcd_debugging_mvcc_watch_stream_total": [
                {
                    "short_name": "EDMWS",
                    "group_name": "",
                },
            ],
            "etcd_debugging_mvcc_watcher": [
                {
                    "short_name": "EDMW",
                    "group_name": "",
                },
            ],
            "etcd_debugging_mvcc_watcher_total": [
                {
                    "short_name": "EDMW",
                    "group_name": "",
                },
            ],
            "etcd_debugging_server_lease_expired": [
                {
                    "short_name": "EDSLE",
                    "group_name": "",
                },
            ],
            "etcd_debugging_snap_save_marshalling_duration_seconds": [
                {
                    "short_name": "EDSMD",
                    "group_name": "",
                },
            ],
            "etcd_debugging_snap_save_total_duration_seconds": [
                {
                    "short_name": "EDSTD",
                    "group_name": "",
                },
            ],
            "etcd_debugging_store_expires": [
                {
                    "short_name": "EDSE",
                    "group_name": "",
                },
            ],
            "etcd_debugging_store_reads": [
                {
                    "short_name": "EDSR",
                    "sum": ["", "EDSR", "sum_only"]
                },
            ],
            "etcd_debugging_store_watch_requests": [
                {
                    "short_name": "EDSWR",
                    "group_name": "",
                },
            ],
            "etcd_debugging_store_watchers": [
                {
                    "short_name": "EDSW",
                    "group_name": "",
                },
            ],
            "etcd_debugging_store_writes": [
                {
                    "short_name": "EDSWRI",
                    "sum": ["", "EDSWRI", "sum_only"]
                },
            ],
            "etcd_disk_backend_snapshot_duration_seconds": [
                {
                    "short_name": "EDBSD",
                    "group_name": "",
                },
            ],
            "etcd_disk_wal_write_bytes": [
                {
                    "short_name": "EDWWB",
                    "group_name": "",
                },
            ],
            "etcd_disk_wal_write_bytes_total": [
                {
                    "short_name": "EDWWB",
                    "group_name": "",
                },
            ],
            "etcd_grpc_proxy_cache_hits": [
                {
                    "short_name": "EGPCH",
                    "group_name": "",
                },
            ],
            "etcd_grpc_proxy_cache_hits_total": [
                {
                    "short_name": "EGPCH",
                    "group_name": "",
                },
            ],
            "etcd_grpc_proxy_cache_keys": [
                {
                    "short_name": "EGPCK",
                    "group_name": "",
                },
            ],
            "etcd_grpc_proxy_cache_keys_total": [
                {
                    "short_name": "EGPCK",
                    "group_name": "",
                },
            ],
            "etcd_grpc_proxy_cache_misses": [
                {
                    "short_name": "EGPCM",
                    "group_name": "",
                },
            ],
            "etcd_grpc_proxy_cache_misses_total": [
                {
                    "short_name": "EGPCM",
                    "group_name": "",
                },
            ],
            "etcd_grpc_proxy_events_coalescing": [
                {
                    "short_name": "EGPEC",
                    "group_name": "",
                },
            ],
            "etcd_grpc_proxy_watchers_coalescing": [
                {
                    "short_name": "EGPWC",
                    "group_name": "",
                },
            ],
            "etcd_grpc_proxy_watchers_coalescing_total": [
                {
                    "short_name": "EGPWC",
                    "group_name": "",
                },
            ],
            "etcd_mvcc_db_total_size_in_bytes": [
                {
                    "short_name": "EMDTSB",
                    "group_name": "",
                },
            ],
            "etcd_mvcc_db_total_size_in_use_in_bytes": [
                {
                    "short_name": "EMDTSU",
                    "group_name": "",
                },
            ],
            "etcd_mvcc_delete": [
                {
                    "short_name": "EMDL",
                    "group_name": "",
                },
            ],
            "etcd_mvcc_put": [
                {
                    "short_name": "EMPT",
                    "group_name": "",
                },
            ],
            "etcd_mvcc_range": [
                {
                    "short_name": "EMRG",
                    "group_name": "",
                },
            ],
            "etcd_mvcc_txn": [
                {
                    "short_name": "EMTX",
                    "group_name": "",
                },
            ],
            "etcd_network_client_grpc_received_bytes": [
                {
                    "short_name": "ENCGR",
                    "group_name": "",
                },
            ],
            "etcd_network_client_grpc_sent_bytes": [
                {
                    "short_name": "ENCGS",
                    "group_name": "",
                },
            ],
            "etcd_network_active_peers": [
                {
                    "short_name": "ENAP",
                    "group_name": "etcd_peers",
                    "labels": {
                        "Local": "lo",
                        "Remote": "na"
                    },
                    "group_labels": ["Remote"],
                    "root_name": ["Remote"]
                },
            ],
            "etcd_network_disconnected_peers": [
                {
                    "short_name": "ENDP",
                    "group_name": "etcd_peers",
                    "labels": {
                        "Local": "lo",
                        "Remote": "na"
                    },
                    "group_labels": ["Remote"],
                    "root_name": ["Remote"]
                },
            ],
        }
        if self.dc_enabled:
            self.get_data()
            self.decide_health_check_status()
            self.decide_instance_role()
            self.peer_metric_summation()
            self.change_data_format(etcd_config)
        else:
            self.create_dummy_etcd_monitor()

    @exception_handler
    def decide_health_check_status(self):
        status, response = KubeUtil.curl_api_with_cert_key(self.health_endpoint, self.auth_config)
        if status == 200:
            self.final_data['healthz_check_status'] = 1
        else:
            self.final_data['healthz_check_status'] = 0
            self.final_data['DCErrors']['healthz_check_status'] = {status: response}

        status, response = KubeUtil.curl_api_with_cert_key(self.livez_endpoint, self.auth_config)
        if status == 200:
            self.final_data['livez_check_status'] = 1
        else:
            self.final_data['livez_check_status'] = 0
            self.final_data['DCErrors']['livez_check_status'] = {status: response}


    @exception_handler
    def decide_instance_role(self):
        if "ESIS" in self.final_data and int(self.final_data["ESIS"]) == 1:
            self.final_data["ESR"] = "Leader"
        elif "ESIL" in self.final_data and int(self.final_data["ESIL"]) == 1:
            self.final_data["ESR"] = "Learner"
        elif "ESIS" in self.final_data and int(self.final_data["ESIS"]) == 0 and "ESL" in self.final_data and int(self.final_data["ESL"] == 1):
            self.final_data["ESR"] = "Follower"
        else:
            self.final_data["ESR"] = "Unknown"


    @exception_handler
    def peer_metric_summation(self):
        if "etcd_peers" in self.final_data and self.final_data["etcd_peers"]:
            if "0" in self.final_data["etcd_peers"]:
                self.final_data["etcd_peers"].pop("0")
            for peer_name, peer_data in self.final_data["etcd_peers"].items():
                if peer_name not in ["0", "None", None]:
                    for metric_name, metric_data in peer_data.items():
                        if metric_name in ["ENPSB", "ENPRB", "ENPSF", "ENPRF", "ENPRT", "ENPRTS", "ENPRTC"]:
                            parent_metric_key = "P"+metric_name
                            if parent_metric_key in self.final_data:
                                self.final_data[parent_metric_key] += metric_data
                            else:
                                self.final_data[parent_metric_key] = metric_data


    @exception_handler
    def parse_etcd_server_id(self, family_list):
        for entry in family_list:
            if "server_id" in entry.labels and int(entry.value) == 1:
                self.final_data["ESI"] = entry.labels["server_id"]
                break


    @exception_handler
    def parse_etcd_server_version(self, family_list):
        for entry in family_list:
            if "server_version" in entry.labels and int(entry.value) == 1:
                self.final_data["ESV"] = entry.labels["server_version"]
                break


    @exception_handler
    def fetch_authentication_config(self):
        if 'server_cert' in os.environ and 'server_key' in os.environ:
            self.dc_enabled = True
            self.auth_config["ca_cert"] = os.environ.get('ca_cert') if 'ca_cert' in os.environ else False #"/host/etc/kubernetes/static-pod-resources/etcd-certs/configmaps/etcd-serving-ca/ca-bundle.crt"
            self.auth_config["server_cert"] = os.environ.get('server_cert') #"/host/etc/kubernetes/static-pod-resources/etcd-certs/secrets/etcd-all-certs/etcd-serving-ip-10-0-129-76.ec2.internal.crt"
            self.auth_config["server_key"] = os.environ.get('server_key') #"/host/etc/kubernetes/static-pod-resources/etcd-certs/secrets/etcd-all-certs/etcd-serving-ip-10-0-129-76.ec2.internal.key"
        elif os.path.exists('/etc/etcd-certs'):
            cert_file_list = os.listdir('/etc/etcd-certs')
            for each_file in cert_file_list:
                if "tls.key" == each_file:
                    self.auth_config["server_key"] = "/etc/etcd-certs/{}".format(each_file)
                elif "tls.crt" == each_file:
                    self.auth_config["server_cert"] = "/etc/etcd-certs/{}".format(each_file)
                elif ".crt" in each_file and "serving" in each_file and KubeGlobal.nodeName in each_file:
                    self.auth_config["server_cert"] = "/etc/etcd-certs/{}".format(each_file)
                elif ".key" in each_file and "serving" in each_file and KubeGlobal.nodeName in each_file:
                    self.auth_config["server_key"] = "/etc/etcd-certs/{}".format(each_file)
            else:
                if "server_cert" in self.auth_config and "server_key" in self.auth_config:
                    self.dc_enabled = True
                else:
                    AgentLogger.log(AgentLogger.KUBERNETES, "*** INFO *** => Etcd DC requirement not satisfied : {} ******".format(cert_file_list))
        else:
            AgentLogger.log(AgentLogger.KUBERNETES, "*** INFO *** => Etcd DC requirement not satisfied : {}:{} ******".format(os.environ.get('server_cert'),os.environ.get('server_key')))

    @exception_handler
    def create_dummy_etcd_monitor(self):
        AgentLogger.log(AgentLogger.KUBERNETES, "*** INFO *** => Need to write flow for dummy Etcd Monitor ******")
        pass

    @exception_handler
    def change_data_format(self, etcd_config):
        etcd_keyname = "{}:{}".format(etcd_config["ip"],etcd_config["port"])
        self.final_data.update({"host": etcd_keyname, "cp_type": "KUBERNETES_ETCD", "Hostname": KubeGlobal.KUBELET_NODE_NAME})
        self.final_data = {
            etcd_keyname : self.final_data
        }

    @exception_handler
    def get_etcd_data(self):
        if self.ksm_data is None:
            self.status_code, data = KubeUtil.curl_api_with_cert_key(self.url, self.auth_config)
            if self.status_code == 200:
                self.raw_data = list(text_string_to_metric_families(data))
            else:
                self.final_data["DCErrors"] = data
                self.connection_error = True
        else:
            if "conn_err" in self.ksm_data:
                self.final_data["DCErrors"] = self.ksm_data
                self.connection_error = True
            else:
                self.raw_data = list(text_string_to_metric_families(self.ksm_data))

    @exception_handler
    def get_data(self):
        self.get_etcd_data()
        self.parse_data()
        self.update_counter_metric_value()
        self.update_onchange_metric_value()
