from com.manageengine.monagent.kubernetes.Parser.JSONParserInterface import JSONParser

class Certificates(JSONParser):
    def __init__(self):
        super().__init__('Certificates')
        self.fetch_with_limit = False

    def get_perf_metrics(self):
        self.value_dict['start_timestamp'] = self.get_2nd_path_value(['status', 'notBefore'], '')
        self.value_dict['expiration_timestamp'] = self.get_2nd_path_value(['status', 'notAfter'], '')
        self.value_dict['renewal_timestamp'] = self.get_2nd_path_value(['status', 'renewalTime'], '')
        self.value_dict['dns_names'] = ','.join(self.get_2nd_path_value(['spec', 'dnsNames'], []))
