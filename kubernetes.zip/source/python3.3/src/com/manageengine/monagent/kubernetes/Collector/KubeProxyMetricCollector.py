from com.manageengine.monagent.kubernetes.Collector.DataCollectorInterface import DataCollector
from com.manageengine.monagent.kubernetes import KubeUtil, KubeGlobal
from com.manageengine.monagent.kubernetes.Parser.PrometheusParser.KubeProxyMetricsParser import KubeProxyMetricsParser



class KubeProxyMetricCollector(DataCollector):
    def get_data_for_cluster_agent(self, req_params=None):
        return KubeProxyMetricsParser(f'http://[{req_params['ip']}]:10249/metrics')

    def collect_data(self):
        kube_proxy_url = f'http://{KubeGlobal.IP_ADDRESS}:10249/{{}}' if ':' not in KubeGlobal.IP_ADDRESS else f'http://[{KubeGlobal.IP_ADDRESS}]:10249/{{}}'
        status, response = KubeUtil.curl_api_without_token(kube_proxy_url.format('/healthz'))
        if status == 200:
            pass
