import os
import json

from com.manageengine.monagent.kubernetes.Integrations.Integrations import Integrations

INPUT_FILE_PATH_VS_DB_TYPE = {
    'MYSQL': '/opt/site24x7/monagent/conf/mysql_input',
    'POSTGRES': '/opt/site24x7/monagent/conf/postgres_input',
    'ORACLE': '/opt/site24x7/monagent/conf/oracle_input'
}


class DatabaseIntegration(Integrations):
    def __init__(self):
        super().__init__('database_integration')
        self.input_file_path = None
        self.integration_matching_key_name = ['HOST', 'PORT', 'USER', 'PASSWORD', 'DB_TYPE']
        self.instance_list = []
        self.config_parser_obj = None

    def pre_action(self):
        db_type = self.integration_config['DB_TYPE'].upper()
        if db_type in INPUT_FILE_PATH_VS_DB_TYPE:
            self.input_file_path = INPUT_FILE_PATH_VS_DB_TYPE[db_type]

    def handle_integration(self):
        if self.is_config_map_modified and self.input_file_path:
            self.instance_list.append({
                'host': self.instance_config['host'],
                'port': self.integration_config['PORT'],
                'user': self.integration_config['USER'],
                'password': os.getenv(self.integration_config['PASSWORD'].split('env_')[1])
            })

    def post_action(self):
        if self.instance_list:
            with open(self.input_file_path, 'w') as write_obj:
                write_obj.write(json.dumps(self.instance_list))
