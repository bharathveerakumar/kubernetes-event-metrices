import sys

try:
    import configparser
except Exception as e:
    import ConfigParser as configparser
import os, shutil
import traceback
from com.manageengine.monagent.kubernetes.Integrations.Integrations import Integrations

PLUGIN_FOLDER_PATH = '/opt/site24x7/monagent/plugins'
PYFILE_PATH = {
    'Redis': '/opt/site24x7/monagent/scripts/tmp/redis/Redis.py',
    'RedisSentinel': '/opt/site24x7/monagent/scripts/tmp/redis/RedisSentinel.py',
    'nginx': '/opt/site24x7/monagent/scripts/tmp/nginx/nginx.py'
}


class PluginsIntegration(Integrations):
    def __init__(self):
        super().__init__('plugin_integration')
        self.integration_matching_key_name = ['PLUGIN_NAME', 'NAMESPACE']
        self.system_keys = ["PLUGIN_NAME", "NAMESPACE", "LABELS_TO_SELECT_PODS", "POD_NAME", "SVC_NAME"]
        self.config_file_path = None
        self.config_parser_obj = None
        self.folder_path = None
        self.pyfile_path = None
        self.is_config_file_modified = False

    def pre_action(self):
        self.folder_path = os.path.join(PLUGIN_FOLDER_PATH, self.integration_config['PLUGIN_NAME'])
        self.pyfile_path = self.folder_path + '/{}.py'.format(self.integration_config['PLUGIN_NAME'])
        self.config_file_path = self.folder_path + '/{}.cfg'.format(self.integration_config['PLUGIN_NAME'])
        self.set_config_parser()
        if not os.path.exists(self.pyfile_path):
            shutil.copyfile(PYFILE_PATH[self.integration_config['PLUGIN_NAME']], self.pyfile_path)

    def set_config_parser(self):
        if not os.path.exists(self.folder_path):
            os.mkdir(self.folder_path)
        self.config_parser_obj = configparser.RawConfigParser()
        self.config_parser_obj.read(self.config_file_path)

    def handle_integration(self):
        if self.display_name not in self.config_parser_obj.sections():
            self.config_parser_obj.add_section(self.display_name)
            for key, value in self.integration_config.items():
                if key not in self.system_keys:
                    self.config_parser_obj.set(self.display_name, key, self.replace_values(value))
                    self.is_config_file_modified = True
            return
        self.check_and_delete_old_options()
        self.update_config_file_values()

    def check_and_delete_old_options(self):
        options_to_remove = []
        for option, value in self.config_parser_obj.items(self.display_name):
            if option != 'encrypted.password' and option not in self.integration_config:
                options_to_remove.append(option)

        for option in options_to_remove:
            self.is_config_file_modified = True
            self.config_parser_obj.remove_option(self.display_name, option)

    def update_config_file_values(self):
        for key, value in self.integration_config.items():
            if key not in self.system_keys and key != 'password':
                replaced_value = self.replace_values(value)
                if not self.config_parser_obj.has_option(self.display_name, key):
                    self.config_parser_obj.set(self.display_name, key, replaced_value)
                    self.is_config_file_modified = True
                    continue

                if self.config_parser_obj.get(self.display_name, key) != replaced_value:
                    self.is_config_file_modified = True
                    self.config_parser_obj.set(self.display_name, key, replaced_value)

    def replace_values(self, value):
        if "env_" in value:
            return os.getenv(value.split("env_")[1])
        elif "%%pod_ip%%" in value:
            return value.replace("%%pod_ip%%", self.instance_config['host'])
        return value

    def post_action(self):
        options_to_remove = []
        for display_name in self.config_parser_obj.sections():
            if display_name not in self.active_instances:
                options_to_remove.append(display_name)

        for option in options_to_remove:
            self.is_config_file_modified = True
            self.config_parser_obj.remove_section(option)

        if self.is_config_file_modified:
            setattr(sys.modules['com.manageengine.monagent.AgentConstants'], 'FORCE_LOAD_PLUGINS', True)
            with open(self.config_file_path, 'w') as write_obj:
                self.config_parser_obj.write(write_obj)
