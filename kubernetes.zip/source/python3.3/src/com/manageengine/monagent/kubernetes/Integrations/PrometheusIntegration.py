import configparser

from com.manageengine.monagent.kubernetes.Integrations.Integrations import Integrations
from com.manageengine.monagent.kubernetes.Logging import KubeLogger


class PrometheusIntegration(Integrations):
    def __init__(self):
        super().__init__('prometheus_integration')
        self.config_file_path = '/opt/site24x7/monagent/metrics/k8sprometheus/k8sprometheus.cfg'
        self.integration_matching_key_name = ['INCLUDE_PATTERN', 'PROTOCOL', 'NAMESPACE', 'PATH', 'PORT']
        self.config_parser_obj = None
        self.is_config_file_modified = False

    def pre_action(self):
        self.config_parser_obj = configparser.RawConfigParser()
        self.config_parser_obj.read(self.config_file_path)

    def handle_integration(self):
        if self.display_name not in self.config_parser_obj.sections():
            self.config_parser_obj.add_section(self.display_name)
            self.config_parser_obj.set(self.display_name, 'prometheus_url', self.construct_prometheus_url())
            self.config_parser_obj.set(self.display_name, 'include_pattern', self.integration_config['INCLUDE_PATTERN'])
            self.config_parser_obj.set(self.display_name, 'kube_instance', '1')
            self.is_config_file_modified = True
            return

        if self.is_config_map_modified:
            self.update_config_file_values()

    def update_config_file_values(self):
        url = self.construct_prometheus_url()
        if self.config_parser_obj.get(self.display_name, 'prometheus_url') != url:
            self.is_config_file_modified = True
            self.config_parser_obj.set(self.display_name, 'prometheus_url', url)

        if self.config_parser_obj.get(self.display_name, 'include_pattern') != self.integration_config['INCLUDE_PATTERN']:
            self.is_config_file_modified = True
            self.config_parser_obj.set(self.display_name, 'include_pattern', self.integration_config['INCLUDE_PATTERN'])

    def construct_prometheus_url(self):
        path = ('/' if self.integration_config['PATH'][0] != '/' else '') + self.integration_config['PATH']
        return '{}://{}:{}'.format(
            self.integration_config['PROTOCOL'], self.instance_config['host'], self.integration_config['PORT']
        ) + path

    def post_action(self):
        if self.is_config_file_modified:
            KubeLogger.log(KubeLogger.KUBERNETES, '****** K8s Prometheus file modified ******\n')
            with open(self.config_file_path, 'w') as write_obj:
                self.config_parser_obj.write(write_obj)
            from com.manageengine.monagent.util.MetricsUtil import start_prometheus_monitoring, stop_prometheus_monitoring
            stop_prometheus_monitoring()
            start_prometheus_monitoring()
