import json
import traceback
import time
import copy
from itertools import islice
from com.manageengine.monagent.kubernetes import KubeUtil, KubeGlobal
from com.manageengine.monagent.kubernetes.KubeUtil import exception_handler
from com.manageengine.monagent.kubernetes.Logging import KubeLogger as AgentLogger
from abc import abstractmethod


KSM_DATA = {}

'''
Extend this class for k8s Data Collections
(Currently extended it for PerfDataCollector, ConfDataCollector, EventCollector, ResourceDependency)
'''
class DataCollector():
    def __init__(self, dc_requisites_obj):
        global KSM_DATA
        self.dc_requisites_obj = dc_requisites_obj

        if self.dc_requisites_obj.ksm_needed:
            KSM_DATA = KSM_DATA if KSM_DATA else KubeUtil.get_ca_parsed_data('npc_ksm' if KubeUtil.is_conf_agent() else 'node_base_ksm')

        self.child_write_count = self.dc_requisites_obj.child_write_count
        self.final_splitted_data = []
        self.dc_type = KubeUtil.get_dctype()

    def initiate_dc(self):
        try:
            dc_start = time.time()
            final_data = self.collect_data(KSM_DATA) if self.dc_requisites_obj.ksm_needed else self.collect_data(None)
            AgentLogger.debug(AgentLogger.APPS, "## final DC data {}".format(json.dumps(final_data)))

            if self.dc_requisites_obj.termination_needed and KubeUtil.get_dctype() == "false":
                KubeUtil.mark_deleted_data(final_data)

            self.split_data(final_data)
            AgentLogger.log(AgentLogger.KUBERNETES, "Time taken for DC-{} {}".format(self.dc_requisites_obj.dc_name, time.time() - dc_start))
        except Exception as e:
            traceback.print_exc()
        finally:
            return self.final_splitted_data

    @abstractmethod
    def collect_data(self, kube_state_data):
        pass

    @exception_handler
    @abstractmethod
    def split_data(self, data, termination_dc=False):
        prevChildDict = {}
        finalFileDict = {}
        currPrevCount = 0
        splitNumber = 0

        chunkSize = self.child_write_count
        ct = int(round(time.time()*1000))

        if data:
            pushFlag = False
            for k, v in data.items():
                if type(v) is dict and k != "kubernetes":
                    for v1 in KubeUtil.dict_chunks(v, chunkSize):
                        vLen = len(v1)
                        if currPrevCount + vLen == chunkSize:
                            finalFileDict = copy.deepcopy(prevChildDict)
                            if k not in finalFileDict: finalFileDict[k] = {}
                            finalFileDict[k].update(v1)
                            KubeUtil.clear_and_init_dict(prevChildDict)
                            currPrevCount = 0
                            pushFlag = True
                        elif currPrevCount + vLen < chunkSize:
                            if k not in prevChildDict: prevChildDict[k] = {}
                            prevChildDict[k].update(v1)
                            currPrevCount += vLen
                        else:
                            if k not in prevChildDict: prevChildDict[k] = {}
                            prevChildDict[k].update(dict(islice(v1.items(), chunkSize - currPrevCount)))
                            finalFileDict = copy.deepcopy(prevChildDict)
                            KubeUtil.clear_and_init_dict(prevChildDict)
                            prevChildDict[k] = dict(islice(v1.items(), chunkSize - currPrevCount, vLen))
                            currPrevCount = currPrevCount + vLen - chunkSize
                            pushFlag = True

                        if pushFlag:
                            pushFlag = False
                            splitNumber += 1
                            self.push_to_file_list(finalFileDict, ct)
                else:
                    prevChildDict[k] = v

            if currPrevCount > 0 or "kubernetes" in prevChildDict:
                splitNumber += 1
                self.push_to_file_list(prevChildDict, ct)

            AgentLogger.log(AgentLogger.KUBERNETES, 'last zip count - {0}'.format(splitNumber))

    def push_to_file_list(self, file_data, ct):
        file_data["ct"] = ct
        file_data["servlet"] = self.dc_requisites_obj.servlet_name

        # if self.dc_requisites_obj.dc_type_needed:
        #     file_data["perf"] = self.dc_type

        self.final_splitted_data.append(copy.deepcopy(file_data))
        KubeUtil.clear_and_init_dict(file_data)

    def get_dc_name(self):
        return self.dc_requisites_obj.dc_name


class DCRequisites:
    def __init__(self):
        self.ksm_needed = False
        self.child_write_count = 500
        self.servlet_name = KubeGlobal.KDR_SERVLET
        self.termination_needed = False
        self.dc_type_needed = False
        self.dc_name = "DataCollector"

    def set_ksm_needed(self, boolean):
        self.ksm_needed = boolean

    def set_child_write_count(self, count):
        self.child_write_count = count

    def set_servlet_name(self, servlet):
        self.servlet_name = servlet

    def set_termination_needed(self, boolean):
        self.termination_needed = boolean

    def set_dc_type_needed(self, boolean):
        self.dc_type_needed = boolean

    def set_dc_name(self, name):
        self.dc_name = name
