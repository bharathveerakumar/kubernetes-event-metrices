import json
import traceback
import time
import copy
from itertools import islice
from com.manageengine.monagent.kubernetes import KubeUtil, KubeGlobal
from com.manageengine.monagent.kubernetes.ClusterAgent import ClusterAgentUtil
from com.manageengine.monagent.kubernetes.KubeUtil import exception_handler
from com.manageengine.monagent.kubernetes.Logging import KubeLogger as AgentLogger
from abc import abstractmethod
from concurrent.futures import ThreadPoolExecutor, as_completed



'''
Extend this class for k8s Data Collections
(extended it for PerfDataCollector, ConfDataCollector, EventCollector, ResourceDependency, ClusterMetricsAggregator, GuidanceMetrics)
'''

class DataCollector:
    def __init__(self, dc_requisites_obj):
        self.dc_requisites_obj = dc_requisites_obj
        self.ksm_data = ClusterAgentUtil.get_ca_parsed_data("node_base_ksm") if self.dc_requisites_obj.node_base_ksm_needed else None
        self.final_splitted_data = []
        self.final_json = {}

    def execute_dc_tasks(self):
        if self.dc_requisites_obj.dependent_classes:
            final_json = {}
            with ThreadPoolExecutor(max_workers = 2) as exe:
                futures = [exe.submit(self.initiate_dc)]

                for obj in self.dc_requisites_obj.dependent_classes:
                    if KubeUtil.is_eligible_to_execute(obj.dc_name, KubeGlobal.DC_START_TIME):
                        futures.append(
                            exe.submit(
                                obj.dc_class(obj).initiate_dc
                            )
                        )

                for future in as_completed(futures):
                    final_json = KubeUtil.MergeDataDictionaries(final_json, future.result())

            self.final_json = final_json

            if self.dc_requisites_obj.split_data_required:
                self.split_data()
                return self.final_splitted_data

            self.final_json["servlet"] = self.dc_requisites_obj.servlet_name
            return [self.final_json]
        else:
            return self.initiate_dc()

    def initiate_dc(self):
        try:
            dc_start = time.time()
            self.collect_data()

            if self.dc_requisites_obj.id_mapping_needed:
                self.map_id()

            if self.dc_requisites_obj.termination_needed and KubeGlobal.isTerminationDc:
                self.execute_termination_task()

            if self.dc_requisites_obj.split_data_required and not self.dc_requisites_obj.dependent_classes:
                self.split_data()
                AgentLogger.log(AgentLogger.KUBERNETES, "Time taken for DC-{} {}".format(self.dc_requisites_obj.dc_name, time.time() - dc_start))
                return self.final_splitted_data

            AgentLogger.log(AgentLogger.KUBERNETES, "Time taken for DC-{} {}".format(self.dc_requisites_obj.dc_name, time.time() - dc_start))
        except Exception:
            traceback.print_exc()
        return self.final_json

    @abstractmethod
    def collect_data(self):
        pass

    @exception_handler
    def map_id(self):
        for grp_name, grp_value in self.final_json.items():
            if grp_name in KubeGlobal.API_ENDPOINT_RES_NAME_MAP:
                grp_ids = KubeGlobal.kubeIds.get(grp_name, {})
                if grp_name == "Pods":
                    self.handle_pod_id_mapping(grp_ids)
                    continue

                for res_name, res_value in grp_value.items():
                    res_value['id'] = grp_ids.get(res_name, {}).get('id')

    @exception_handler
    def handle_pod_id_mapping(self, pod_id_dict):
        for pod_name, pod_value in self.final_json["Pods"].items():
            pod_value['id'] = pod_id_dict.get(pod_name, {}).get('id')
            for cont_name, cont_value in pod_value.get("Cont", {}).items():
                cont_value['id'] = pod_id_dict.get(pod_name, {}).get("Cont", {}).get("id")

    @exception_handler
    def execute_termination_task(self):
        with ThreadPoolExecutor(max_workers = 4) as exe:
            for group_type, group_value in KubeGlobal.kubeIds.items():
                exe.submit(self.mark_deleted_data, group_type, group_value)

    @exception_handler
    def mark_deleted_data(self, group_type, group_value):
        if group_type not in KubeGlobal.TERMINATION_NOT_SUPPORTED_GRPS:
            url = KubeGlobal.apiEndpoint + KubeGlobal.API_ENDPOINT_RES_NAME_MAP[group_type] + '?fieldSelector=metadata.name={}'
            for res_name, res_val in group_value.items():
                key_name_split = res_name.split("_")
                name = key_name_split[0]
                ns = key_name_split[1] if group_type not in KubeGlobal.NO_NS_UNIQUNESS_TYPES else None
                status, resp = KubeUtil.curl_api_with_token(url.format(name + (('&metadata.namespace='+ns) if ns else '')))
                if status == 200 and len(resp.get("items", [])) == 0:
                    self.final_json[group_type] = self.final_json.get(group_type, {})
                    self.final_json[group_type][res_name] = res_val
                    self.final_json[group_type][res_name]["deleted"] = "true"

    @exception_handler
    @abstractmethod
    def split_data(self):
        prevChildDict = {}
        finalFileDict = {}
        currPrevCount = 0
        splitNumber = 0

        chunkSize = self.dc_requisites_obj.child_write_count
        ct = int(round(time.time()*1000))

        pushFlag = False
        for k, v in self.final_json.items():
            if type(v) != dict or k == "kubernetes":
                prevChildDict[k] = v
                continue

            for v1 in KubeUtil.dict_chunks(v, chunkSize):
                vLen = len(v1)
                if currPrevCount + vLen == chunkSize:
                    finalFileDict = copy.deepcopy(prevChildDict)
                    if k not in finalFileDict: finalFileDict[k] = {}
                    finalFileDict[k].update(v1)
                    KubeUtil.clear_and_init_dict(prevChildDict)
                    currPrevCount = 0
                    pushFlag = True
                elif currPrevCount + vLen < chunkSize:
                    if k not in prevChildDict: prevChildDict[k] = {}
                    prevChildDict[k].update(v1)
                    currPrevCount += vLen
                else:
                    if k not in prevChildDict: prevChildDict[k] = {}
                    prevChildDict[k].update(dict(islice(v1.items(), chunkSize - currPrevCount)))
                    finalFileDict = copy.deepcopy(prevChildDict)
                    KubeUtil.clear_and_init_dict(prevChildDict)
                    prevChildDict[k] = dict(islice(v1.items(), chunkSize - currPrevCount, vLen))
                    currPrevCount = currPrevCount + vLen - chunkSize
                    pushFlag = True

                if pushFlag:
                    pushFlag = False
                    splitNumber += 1
                    self.push_to_file_list(finalFileDict, ct)

        if currPrevCount > 0 or "kubernetes" in prevChildDict:
            splitNumber += 1
            self.push_to_file_list(prevChildDict, ct)

            AgentLogger.log(AgentLogger.KUBERNETES, 'last zip count - {0}'.format(splitNumber))

    def push_to_file_list(self, file_data, ct):
        file_data["ct"] = ct
        file_data["servlet"] = self.dc_requisites_obj.servlet_name

        if self.dc_requisites_obj.dc_type_needed:
            file_data["perf"] = KubeUtil.get_dctype()

        self.final_splitted_data.append(copy.deepcopy(file_data))
        KubeUtil.clear_and_init_dict(file_data)



class DCRequisites:
    def __init__(self):
        self.node_base_ksm_needed = False
        self.child_write_count = 500
        self.servlet_name = KubeGlobal.KDR_SERVLET
        self.termination_needed = False
        self.dc_type_needed = False
        self.dc_name = "DataCollector"
        self.dc_class = None
        self.split_data_required = False
        self.dependent_classes = []
        self.use_cluster_agent = False
        self.id_mapping_needed = False
        self.workloads_aggregation_needed = True
        self.is_sidecar_agent = False

    def set_node_base_ksm_needed(self, boolean):
        self.node_base_ksm_needed = boolean

    def set_child_write_count(self, count):
        self.child_write_count = count

    def set_servlet_name(self, servlet):
        self.servlet_name = servlet

    def set_termination_needed(self, boolean):
        self.termination_needed = boolean

    def set_dc_type_needed(self, boolean):
        self.dc_type_needed = boolean

    def set_dc_name(self, name):
        self.dc_name = name

    def set_dc_class(self, class_name):
        self.dc_class = class_name

    def set_split_data_required(self, boolean):
        self.split_data_required = boolean

    def set_dependent_classes(self, requisites_objs):
        self.dependent_classes = requisites_objs

    def get_from_cluster_agent(self, boolean):
        self.use_cluster_agent = boolean

    def set_id_mapping_needed(self, boolean):
        self.id_mapping_needed = boolean

    def set_workloads_aggregation_needed(self, boolean):
        self.workloads_aggregation_needed = boolean

    def set_is_sidecar_agent(self, boolean):
        self.is_sidecar_agent = boolean
