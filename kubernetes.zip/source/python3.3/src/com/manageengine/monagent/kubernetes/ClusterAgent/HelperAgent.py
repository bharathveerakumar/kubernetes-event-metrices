import os
import sys
import time
import json

if os.environ.get("CLUSTER_AGENT") != "true":
    sys.stdout.write("\n***** CLUSTER_AGENT env is not set *****\n")
    sys.exit()

CLUSTER_AGENT_SRC = '/opt/site24x7/monagent/lib/devops/source/python3.3/src'
CONF_FOLDER_PATH = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(CLUSTER_AGENT_SRC))))) + '/conf'
CLUSTER_AGENT_WORKING_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(CLUSTER_AGENT_SRC)))))
LOGS_FOLDER_PATH = CLUSTER_AGENT_WORKING_DIR + '/logs'

sys.path.append(CLUSTER_AGENT_SRC)

from com.manageengine.monagent.kubernetes.Logging import LoggerUtil, KubeLogger
LoggerUtil.initialize_cluster_agent_logging(CONF_FOLDER_PATH + '/logging.xml', LOGS_FOLDER_PATH)
KubeLogger.initialize()

from com.manageengine.monagent.kubernetes.ClusterAgent import ClusterAgentUtil
from com.manageengine.monagent.kubernetes import KubeGlobal
from com.manageengine.monagent.kubernetes import KubeUtil
KubeGlobal.set_cluster_agent_constants(CLUSTER_AGENT_SRC)


def start_watcher_daemon():
    while True:
        try:
            if not os.path.isfile(CONF_FOLDER_PATH + '/upgrade_lock_file.txt'):
                break

            status, ksm_api_data = KubeUtil.curl_api_without_token(KubeGlobal.kubeStateMetricsUrl + '/metrics')
            with open(KubeGlobal.KSM_OUTPUT_FILE, 'w') as write_obj:
                write_obj.write(ksm_api_data)

            parse_data()
            time.sleep(50)
        except Exception:
            pass

def parse_data():
    ksm_data = ClusterAgentUtil.get_ksm_api_resp()
    with open(KubeGlobal.PARSED_DATA_FOLDER_PATH + '/{}'.format(KubeGlobal.DATA_TYPE_PARSED_FILE_MAP['conf']), 'w') as write_obj:
        write_obj.write(
            json.dumps(
                KubeGlobal.DATA_TYPE_METHOD_MAP['conf'][0](KubeGlobal.DATA_TYPE_METHOD_MAP['conf'][1])
            )
        )

    with open(KubeGlobal.PARSED_DATA_FOLDER_PATH + '/{}'.format(KubeGlobal.DATA_TYPE_PARSED_FILE_MAP['resource_dependency']), 'w') as write_obj:
        write_obj.write(
            json.dumps(
                KubeGlobal.DATA_TYPE_METHOD_MAP['resource_dependency'][0](KubeGlobal.DATA_TYPE_METHOD_MAP['resource_dependency'][1], ksm_data)
            )
        )

    npc_data = KubeGlobal.DATA_TYPE_METHOD_MAP['npc_ksm'][0](KubeGlobal.DATA_TYPE_METHOD_MAP['npc_ksm'][1], ksm_data)
    with open(KubeGlobal.PARSED_DATA_FOLDER_PATH + '/{}'.format(KubeGlobal.DATA_TYPE_PARSED_FILE_MAP['npc_ksm']), 'w') as write_obj:
        write_obj.write(
            json.dumps(npc_data)
        )

    split_node_base_data(npc_data)


def split_node_base_data(npc_ksm):
    final_dict = {}

    for key, value in npc_ksm["Nodes"].items():
        final_dict[key] = {
            "Nodes": {
                key: value
            },
            "Pods": {},
            "Cont": {}
        }

    for key, value in npc_ksm["Pods"].items():
        try:
            final_dict[value["No"]]["Pods"][key] = value
        except Exception:
            continue

    for key, value in npc_ksm["Cont"].items():
        try:
            final_dict[value["No"]]["Cont"][key] = value
        except Exception:
            continue

    with open(KubeGlobal.PARSED_DATA_FOLDER_PATH + '/{}'.format(KubeGlobal.DATA_TYPE_PARSED_FILE_MAP['node_base_ksm']), 'w') as write_obj:
        write_obj.write(
            json.dumps(final_dict)
        )


if __name__ == "__main__":
    start_watcher_daemon()