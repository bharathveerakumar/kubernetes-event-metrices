import os
import sys
import time
import json

if os.environ.get("CLUSTER_AGENT") != "true":
    sys.stdout.write("\n***** CLUSTER_AGENT env is not set *****\n")
    sys.exit()

CLUSTER_AGENT_SRC = '/opt/site24x7/monagent/lib/devops/source/python3.3/src'
CONF_FOLDER_PATH = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(CLUSTER_AGENT_SRC))))) + '/conf'
CLUSTER_AGENT_WORKING_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(CLUSTER_AGENT_SRC)))))
LOGS_FOLDER_PATH = CLUSTER_AGENT_WORKING_DIR + '/logs'

sys.path.append(CLUSTER_AGENT_SRC)

from com.manageengine.monagent.kubernetes.Logging import LoggerUtil, KubeLogger
LoggerUtil.initialize_cluster_agent_logging(CONF_FOLDER_PATH + '/logging.xml', LOGS_FOLDER_PATH)
KubeLogger.initialize()

from com.manageengine.monagent.kubernetes.ClusterAgent import ClusterAgentUtil
from com.manageengine.monagent.kubernetes import KubeGlobal
from com.manageengine.monagent.kubernetes import KubeUtil
KubeGlobal.set_cluster_agent_constants(CLUSTER_AGENT_SRC)


def start_watcher_daemon():
    while True:
        try:
            if not os.path.isfile(CONF_FOLDER_PATH + '/upgrade_lock_file.txt'):
                break

            status, ksm_api_data = KubeUtil.curl_api_without_token(KubeGlobal.kubeStateMetricsUrl + '/metrics')
            with open(KubeGlobal.KSM_OUTPUT_FILE, 'w') as write_obj:
                write_obj.write(ksm_api_data)

            time.sleep(40)
        except Exception:
            pass

def parse_ksm_data():
    ksm_data = ClusterAgentUtil.get_ksm_api_resp()





if __name__ == "__main__":
    start_watcher_daemon()