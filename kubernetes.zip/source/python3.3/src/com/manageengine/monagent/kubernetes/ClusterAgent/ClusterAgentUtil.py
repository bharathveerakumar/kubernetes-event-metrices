import time, os, json, traceback
from com.manageengine.monagent.kubernetes import KubeUtil, KubeGlobal
from com.manageengine.monagent.kubernetes.Logging import KubeLogger as AgentLogger



def check_and_discover_cluster_agent_svc():
    try:
        url = "/api/v1/services?labelSelector={}%3D{}"
        status, resp = KubeUtil.curl_api_with_token(KubeGlobal.host + url.format("app", "site24x7-cluster-agent"))

        if status == 200 and "items" in resp and len(resp["items"]):
            svc_data = resp['items'][0]
            KubeGlobal.CLUSTER_AGENT_SVC = "http://{}.{}:5000".format(svc_data["metadata"]["name"], svc_data["metadata"]["namespace"])
            KubeGlobal.CLUSTER_AGENT_STATS["cluster_agent_status"] = 1
            return
    except Exception:
        traceback.print_exc()
    KubeGlobal.CLUSTER_AGENT_STATS["cluster_agent_status"] = 0
    KubeGlobal.CLUSTER_AGENT_SVC = None

def check_last_mtime(file_path, expiry_time = None):
    return True if time.time() - os.stat(file_path).st_mtime <= float(60 if not expiry_time else expiry_time) else False

def get_ca_parsed_data(data_type, failover_needed = True):
    try:
        if KubeGlobal.CLUSTER_AGENT_SVC and KubeUtil.is_eligible_to_execute("clusteragent", KubeGlobal.DC_START_TIME, False, True):
            url = KubeGlobal.CLUSTER_AGENT_SVC + KubeGlobal.CLUSTER_AGENT_URL_DATA_TYPE_MAP[data_type]

            if "node_name" in url:
                url = url.format(KubeGlobal.nodeName if KubeGlobal.nodeName else KubeGlobal.KUBELET_NODE_NAME)

            bef_req = time.time()
            status, resp = KubeUtil.curl_api_without_token(url)
            if status == 200:
                try:
                    resp = json.loads(resp)
                    KubeGlobal.CLUSTER_AGENT_STATS[data_type][status] = KubeGlobal.CLUSTER_AGENT_STATS[data_type].get(status, 0) + 1
                    if validate_ca_response(resp, data_type):
                        remove_invalid_nodes(data_type, resp)
                        resp_time = time.time() - bef_req
                        KubeGlobal.CLUSTER_AGENT_STATS[data_type]["response_time"] = resp_time
                        AgentLogger.log(AgentLogger.KUBERNETES, "********* Cluster agent responded in {} for {} *********\n".format(resp_time, data_type))
                        return resp
                except json.JSONDecodeError:
                    KubeGlobal.CLUSTER_AGENT_STATS[data_type]["JSONDecodeError"] = KubeGlobal.CLUSTER_AGENT_STATS[data_type].get("JSONDecodeError", 0) + 1
    except Exception as e:
        KubeGlobal.CLUSTER_AGENT_STATS["get_ca_parsed_data"] = e
        traceback.print_exc()
    AgentLogger.log(AgentLogger.KUBERNETES, "******** Cluster Agent not Ready - {} - {} *********\n".format(data_type, KubeGlobal.CLUSTER_AGENT_STATS[data_type]))
    return KubeGlobal.DATA_TYPE_METHOD_MAP[data_type][0](KubeGlobal.DATA_TYPE_METHOD_MAP[data_type][1]) if failover_needed else None

def get_parsed_data_for_ca(data_type, ksm_needed = True):
    # checking if exists in cache (npc_ksm is required for aggregation)
    file_path = KubeGlobal.PARSED_DATA_FOLDER_PATH + '/{}'.format(KubeGlobal.DATA_TYPE_PARSED_FILE_MAP[data_type])
    parsed_data = read_json_from_file(file_path)

    # initiate data parsing if not exists in cache
    if not parsed_data:
        parsed_data = KubeGlobal.DATA_TYPE_METHOD_MAP[data_type][0](KubeGlobal.DATA_TYPE_METHOD_MAP[data_type][1], get_ksm_api_resp()) if ksm_needed else KubeGlobal.DATA_TYPE_METHOD_MAP[data_type][0](KubeGlobal.DATA_TYPE_METHOD_MAP[data_type][1])

    return parsed_data

def validate_ca_response(response, data_type):
    if not len(response):
        KubeGlobal.CLUSTER_AGENT_STATS[data_type]["resp_len_invalid"] = KubeGlobal.CLUSTER_AGENT_STATS[data_type].get("resp_len_invalid", 0) + 1
        return False
    if "Pods" not in response and "DaemonSets" not in response and data_type != "resource_dependency":
        KubeGlobal.CLUSTER_AGENT_STATS[data_type]["mandatory_keys_failed"] = KubeGlobal.CLUSTER_AGENT_STATS[data_type].get("mandatory_keys_failed", 0) + 1
        return False
    return True

def get_ksm_api_resp():
    ksm_data = None
    if os.path.exists(KubeGlobal.KSM_OUTPUT_FILE) and check_last_mtime(KubeGlobal.KSM_OUTPUT_FILE):
        with open(KubeGlobal.KSM_OUTPUT_FILE, 'r') as read_obj:
            ksm_data = read_obj.read()
    return ksm_data

def read_json_from_file(file_path):
    try:
        if os.path.exists(file_path) and check_last_mtime(file_path):
            with open(file_path, 'r') as read_obj:
                parsed_data = read_obj.read()
            return json.loads(parsed_data)
    except Exception:
        traceback.print_exc()
    return None

def remove_invalid_nodes(data_type, resp_json):
    if data_type in ["conf"]:
        update_needed = False
        if data_type == "conf":
            update_needed = True

        for key_name in resp_json.keys():
            if not KubeUtil.is_eligible_to_execute(key_name.lower(), KubeGlobal.DC_START_TIME, update_needed):
                resp_json.pop(key_name, None)
