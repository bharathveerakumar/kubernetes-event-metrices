import os
import sys
import time
import threading
import socket
import traceback

try:
    import win32service
except Exception as e:
    pass

try:
    import win32serviceutil
except ImportError:
    # Mock out for Linux.
    class Object(object):
        pass
    win32serviceutil = Object()
    win32serviceutil.ServiceFramework = Object

SRC = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0]))))))
# if os.path.split(SRC)[1] == 'com':
#     sys.path.append(SRC)

from com.manageengine.monagent.kubernetes.Logging import LoggerUtil
from com.manageengine.monagent.kubernetes import KubeGlobal
from com.manageengine.monagent.kubernetes.Logging import KubeLogger

LoggerUtil.initialize_cluster_agent_logging(KubeGlobal.KUBE_LOGGING_XML_FILE, KubeGlobal.KUBE_AGENT_LOGS_FOLDER_PATH)
KubeLogger.initialize()
print(12344)

from com.manageengine.monagent.kubernetes import KubeDCExecutor
from com.manageengine.monagent.kubernetes.SettingsHandler import Initializer
from com.manageengine.monagent.kubernetes.SettingsHandler import DMSWatcher

"""
1. Set the SRC to system path
2. Initialize the agent logging module.
3. Initializes the k8s agent modules. (Initializer.init())
4. Start the WMS watcher thread
5. Start the DataCollection task in thread or execute it right from here.
"""

def start_kube_dc_tasks():
    print("executing DC tasks!!!!")
    while True:
        final_json = KubeDCExecutor.execute_tasks()
        print(final_json)
        time.sleep(10)

def start_dms_thread():
    dms_daemon = threading.Thread(target=DMSWatcher.start_dms_message_watcher, name='DMSWatcherThread')
    dms_daemon.daemon = True
    dms_daemon.start()

def main():
    Initializer.init()
    start_dms_thread()
    start_kube_dc_tasks()

class KubeAgentSvc(win32serviceutil.ServiceFramework):
    _svc_name_ = "Site24x7 Kubernetes Agent"
    _svc_display_name_ = "Site24x7 Kubernetes Agent"

    def __init__(self, args):
        import win32event

        win32serviceutil.ServiceFramework.__init__(self, args)
        self.hWaitStop = win32event.CreateEvent(None, 0, 0, None)
        socket.setdefaulttimeout(60)

    def SvcStop(self):
        import win32event

        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        win32event.SetEvent(self.hWaitStop)

    def SvcDoRun(self):
        import servicemanager

        servicemanager.LogMsg(servicemanager.EVENTLOG_INFORMATION_TYPE, servicemanager.PYS_SERVICE_STARTED, (self._svc_name_, ''))
        main()
        servicemanager.LogMsg(servicemanager.EVENTLOG_INFORMATION_TYPE, servicemanager.PYS_SERVICE_STOPPED, (self._svc_name_,  ''))


if __name__ == '__main__':
    if not sys.platform.startswith('win'):
        main()
    elif len(sys.argv) == 1:
        try:
            import win32service
            import servicemanager

            evtsrc_dll = os.path.abspath(servicemanager.__file__)
            servicemanager.PrepareToHostSingle(KubeAgentSvc)
            servicemanager.Initialize('KubeAgentSvc', evtsrc_dll)
            servicemanager.StartServiceCtrlDispatcher()
        except Exception as details:
            traceback.print_exc()
