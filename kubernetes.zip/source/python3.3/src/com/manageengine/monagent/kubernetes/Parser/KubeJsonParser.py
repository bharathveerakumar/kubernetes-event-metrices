import sys
import traceback
import json
from com.manageengine.monagent.kubernetes.Logging import KubeLogger as AgentLogger
from com.manageengine.monagent.kubernetes import KubeUtil
from com.manageengine.monagent.kubernetes import KubeGlobal
import re
from datetime import datetime

valDict = {}
dcErrors = {}

def load_k8s_perf_xml(xmlFile):
    global valDict, dcErrors
    parsedData = {}
    try:
        root = KubeUtil.load_xml_root_from_file(xmlFile)
        node_name = KubeGlobal.KUBELET_NODE_NAME
        if root is not None:
            AgentLogger.log(AgentLogger.KUBERNETES, 'KubeGlobal.apiEndpoint - {0}'.format(KubeGlobal.apiEndpoint))

            for api in root.findall('api'):
                if api.get("conf") != "true":
                    continue

                KubeUtil.clear_and_init_dict(valDict)
                url = api.get('url')

                status, valDict = KubeUtil.curl_api_with_token(KubeGlobal.apiEndpoint + url + "=" + node_name)

                if status and status != 200:
                    AgentLogger.log(AgentLogger.KUBERNETES, 'dcError - adding {0}'.format(url))
                    dcErrors[url] = status

                if valDict and valDict is not {}:
                    for group in api.findall("Group"):
                        process_groups(group, valDict, parsedData)
                    for itemsGroup in api.findall("itemsGroup"):
                        items_group(itemsGroup, valDict, parsedData)
                    for merge in api.findall("Merge"):
                        merge_items_groups(merge, parsedData)
                else:
                    AgentLogger.log(AgentLogger.KUBERNETES, 'valDict is empty/None - skipping api - ' + url)
                KubeUtil.clear_and_init_dict(valDict)

            parsedData["DCErrors"] = dcErrors
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES, 'LoadK8sConfigXml -> Exception -> {0}'.format(e))
        traceback.print_exc()
    KubeUtil.clear_and_init_dict(valDict)
    KubeUtil.clear_and_init_dict(dcErrors)
    return parsedData


def load_k8s_config_xml(xmlFile, isConf = True,isPerf = False, throughProxy=False, node=""):
    AgentLogger.log(AgentLogger.KUBERNETES,' inside LoadK8sConfigXml.....')
    parsedData = {}
    global valDict,dcErrors
    try:
        root = KubeUtil.load_xml_root_from_file(xmlFile)
        if root is not None:
            AgentLogger.debug(AgentLogger.KUBERNETES,' root not none.....')
            AgentLogger.log(AgentLogger.KUBERNETES,'KubeGlobal.apiEndpoint - {0}'.format(KubeGlobal.apiEndpoint))
            
            for api in root.findall('api'):
                try:
                    KubeUtil.clear_and_init_dict(valDict)
                    url = api.get('url')
                    api_name = api.get('Name')
                    AgentLogger.debug(AgentLogger.KUBERNETES,'url - ' + url)
                    url = KubeUtil.replace_tokens(url, node, throughProxy)
                    AgentLogger.log(AgentLogger.KUBERNETES,'replaced url - ' + url)

                    perf_api = api.get("perf")

                    if isPerf and perf_api:
                        status, valDict = KubeUtil.curl_api_with_token(url)
                        handle_config_response(status, parsedData, url, isPerf, api)
                    elif isConf and not perf_api:
                        if not KubeUtil.is_eligible_to_execute(api_name.lower(), KubeGlobal.DC_START_TIME, False, True):
                            continue

                        continue_token = None
                        while True:
                            constructed_url = KubeGlobal.apiEndpoint + url + "&continue={}".format(continue_token) if continue_token else KubeGlobal.apiEndpoint + url
                            status, valDict = KubeUtil.curl_api_with_token(constructed_url)
                            if status == 200:
                                if 'continue' in valDict['metadata'] and valDict['metadata']['remainingItemCount'] > 0:
                                    continue_token = valDict['metadata']['continue']
                                    handle_config_response(status, parsedData, url, isPerf, api)
                                    continue
                                handle_config_response(status, parsedData, url, isPerf, api)
                            break
                    KubeUtil.clear_and_init_dict(valDict)
                except Exception as e:
                    traceback.print_exc()

            parsedData["DCErrors"] = dcErrors
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'LoadK8sConfigXml -> Exception -> {0}'.format(e))
        traceback.print_exc()
    KubeUtil.clear_and_init_dict(valDict)
    KubeUtil.clear_and_init_dict(dcErrors)
    return parsedData

def handle_config_response(status, parsedData, url, isPerf, api):
    global valDict, dcErrors
    # add to DCError
    if status and status != 200:
        AgentLogger.log(AgentLogger.KUBERNETES, 'dcError - adding {0}'.format(url))
        dcErrors[url] = status
        if isPerf:
            node_name = KubeGlobal.nodeName
            url = KubeGlobal.apiEndpoint + '/api/v1/nodes/{}/proxy/stats/summary'.format(node_name)
            status, valDict = KubeUtil.curl_api_with_token(url)

    if valDict and valDict is not {}:
        for group in api.findall("Group"):
            process_groups(group, valDict, parsedData)
        for itemsGroup in api.findall("itemsGroup"):
            items_group(itemsGroup, valDict, parsedData)
        for merge in api.findall("Merge"):
            merge_items_groups(merge, parsedData)
    else:
        AgentLogger.log(AgentLogger.KUBERNETES, 'valDict is empty/None - skipping api - ' + url)

def items_group(itemsGroup,ItemsGroupValDict,dictToAdd):
    AgentLogger.debug(AgentLogger.KUBERNETES,'ItemsGroup ....... ')
    try:       
        if itemsGroup:               
            name = itemsGroup.get('Name')
            path = itemsGroup.get('Path')
            isKeyValuepair = itemsGroup.get('isKeyValuepair')
            isHidden = itemsGroup.get('isHidden')
            
            mapIdVal = itemsGroup.get('MapId')
            if mapIdVal and mapIdVal == 'False':
                AgentLogger.debug(AgentLogger.KUBERNETES,'not mapping ids')
                mapID = False
            else:
                mapID = True
            
            if mapID:              
                idGroupName = itemsGroup.get('IDGroupName')
                if not idGroupName:
                    idGroupName = name
            
            #get val
            itemsGroupValList = KubeUtil.get_dict_node(ItemsGroupValDict,path)
            if itemsGroupValList:            
                if name and path:
                    dictToAddInner = {} if name not in dictToAdd else dictToAdd[name]

                    if isHidden:
                        dict = dictToAdd
                    else:
                        dict = dictToAddInner
                    
                    if isKeyValuepair:
                        for itemsGroupValList1 in itemsGroupValList:
                            process_key_value_items_group(itemsGroup,itemsGroupValList1,dict)
                    else:
                        for itemsGroupValList1 in itemsGroupValList:
                            process_items_group(itemsGroup,itemsGroupValList1,dict)
                    
                    if not isHidden:
                        if dictToAddInner is not None:
                            dictToAdd[name] = dictToAddInner
            else:
                AgentLogger.debug(AgentLogger.KUBERNETES,'value for path - ' + str(path) + 'does not exist')
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'ItemsGroup -> Exception -> {0}'.format(e))
        
def process_items_group(itemsGroup,itemsGroupValList,dictToAdd):
    AgentLogger.debug(AgentLogger.KUBERNETES,'ProcessItemsGroup ....... ')    
    try:
        thisDic = {}
        rootName = None
        rootVal = None
        for root in itemsGroup.findall('Root'):
            rootName = root.get('Name')
            val = process_items(root,itemsGroupValList,None)
            if rootVal:
                rootVal = rootVal + "_" + val #handling multiple roots
            else:
                rootVal = val
        
        if rootVal:        
            
            for group in itemsGroup.findall("Group"):
                process_groups(group,itemsGroupValList,thisDic)
            for item in itemsGroup.findall("item"):
                process_items(item,itemsGroupValList,thisDic)
            for itemsG in itemsGroup.findall("itemsGroup"):
                 items_group(itemsG,itemsGroupValList,thisDic)
            for merge in itemsGroup.findall("Merge"):
                merge_items_groups(merge,thisDic)
            
            dictToAdd[rootVal] = thisDic
        else:
           AgentLogger.debug(AgentLogger.KUBERNETES,'ProcessItemsGroup -> rootVal is None') 
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'ProcessItemsGroup -> Exception -> {0}'.format(e))
    return None   

def process_groups(group,itemsGroupValList,thisDic):
    AgentLogger.debug(AgentLogger.KUBERNETES,'ProcessGroups ....... ')
    try:
        if group:
            name = group.get('Name')
            if name:
                groupDic = {}
                for item in group.findall("item"):
                    process_items(item,itemsGroupValList,groupDic)
                for itemsG in group.findall("itemsGroup"):
                    items_group(itemsG,itemsGroupValList,groupDic)
                thisDic[name] = groupDic
            else:
                AgentLogger.debug(AgentLogger.KUBERNETES,'ProcessGroups -> Name is None')            
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'ProcessGroups -> Exception -> {0}'.format(e))
    return None

def process_key_value_items_group(itemsGroup,itemsGroupValList,dictToAdd):
    AgentLogger.debug(AgentLogger.KUBERNETES,'ProcessNodeValueItemsGroup ....... ')
    try:
        thisDic = {}
        for key in itemsGroup.findall('Key'):
            keyVal = process_items(key,itemsGroupValList,None)
            if keyVal and keyVal != "":
               for value in key.findall('Value'):
                   valVal = process_items(value,itemsGroupValList,None)
                   if valVal:
                       dictToAdd[keyVal] = valVal                
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'ProcessNodeValueItemsGroup -> Exception -> {0}'.format(e))
    return None 

def process_items(item,valNode,thisDic):
    #AgentLogger.log(AgentLogger.KUBERNETES,'ProcessItems ....... ')
    try:   
        name = item.get('Name')
        path = item.get('Path')
        shortName = item.get('shortName')
        toString = item.get('ToString')        
        getAsList = item.get('getAsList')
        script_path = item.get('module')
        script_name = item.get('method')
        args = item.get('args')
        val = None
        
        if not script_path:
            val = get_items_val(valNode,path,name,getAsList)

        if script_path and args in thisDic:
            args_value = thisDic[args]
            script_path=sys.modules[script_path]
            val=getattr(script_path,script_name)(args_value, datetime.now())
            AgentLogger.debug(AgentLogger.KUBERNETES,'result -- {}'.format(val))

        #adding  if item is not present
        if val is None:
            AgentLogger.debug(AgentLogger.KUBERNETES,'value for path - ' + str(path) + 'does not exist -> hence adding "" val')
            val = ""
        
        if toString:
            val = json.dumps(val)
            
        unit_stripper = item.get("strip_unit")
        
        if unit_stripper:
            val = Math(val, unit_stripper)
        
        rate = item.get("rate")
        if rate:
            ref_name=""
            if 'podRef' in valNode:
                ref_name = valNode['podRef']['name']
            elif 'node' in valNode:
                ref_name = valNode['node']['nodeName']
            val = KubeUtil.get_counter_value(name+"_"+ref_name,val, item.get("noDiv") == "true")
        
        expression = item.get("expr")
        if expression and len(str(val)) > 0:
            val = float(val)
            d={name:val}
            val = KubeUtil.get_value_from_expression(expression,d)
        
        if thisDic is None: #case 1 - directly return the val
            return val
        else:               #case 2 - add it to the dict 
            thisDic[shortName] = val
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'ProcessItems -> Exception -> {0}'.format(e))
        traceback.print_exc()
    return None 

def get_items_val(dataNode,path,name,getAsList):
    try:
        toReturnNode = dataNode
        if path:
            for patharg in path.split('/'):
                if patharg in toReturnNode:
                    tempNode = toReturnNode[patharg]
                    toReturnNode = tempNode
                else:
                    toReturnNode =''
                    break
        if getAsList:
            return toReturnNode

        if name in toReturnNode:
            return toReturnNode[name]
        else:
            AgentLogger.debug(AgentLogger.KUBERNETES,'GetItemsVal -> toReturnNode - NONE')
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'GetItemsVal -> Exception -> {0}'.format(e))
        traceback.print_exc()
    return None

def Math(val,unit_splitter):
    try:
        if val:
            if unit_splitter:
                split_val = re.findall('(\d+|[A-Za-z]+)', val)
                if split_val:
                    val = split_val[0]
                AgentLogger.debug(AgentLogger.KUBERNETES,'Math -> val after unit split - {0}'.format(val))
        else:
            AgentLogger.debug(AgentLogger.KUBERNETES,'Math -> val - NONE')
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'Math -> Exception -> {0}'.format(e))
    return val

def merge_items_groups(merge,valDic):
    AgentLogger.debug(AgentLogger.KUBERNETES,'MergeItemsGroups')
    try:            
        itemsGroup1 = merge.get('itemsGroup1')
        itemsGroup2 = merge.get('itemsGroup2')
        newKey = merge.get('key')
        
        if valDic and newKey:
            itemsGroupDic1 = None
            itemsGroupDic2 = None
            
            if itemsGroup1 in valDic:
                itemsGroupDic1 = valDic.get(itemsGroup1)
                del valDic[itemsGroup1]
            if itemsGroup2 in valDic:
                itemsGroupDic2 = valDic.get(itemsGroup2)
                del valDic[itemsGroup2]
            
            dictNew = KubeUtil.MergeDataDictionaries(itemsGroupDic1,itemsGroupDic2)
            if dictNew:
                valDic[newKey] = dictNew
            else:
                AgentLogger.debug(AgentLogger.KUBERNETES,'MergeItemsGroups -> failed')
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'MergeItemsGroups -> Exception -> {0}'.format(e))