from com.manageengine.monagent.kubernetes.Parser.JSONParserInterface import JSONParser
from com.manageengine.monagent.kubernetes import KubeGlobal

class Jobs(JSONParser):

    def parse(self, value_dict):
        value_dict['CT'] = self.get_value(['metadata', 'creationTimestamp'])

        value_dict['Pa'] = self.get_value(['spec', 'parallelism'])

        value_dict['Co'] = self.get_value(['spec', 'completions'])
