import sys

from cx_Freeze import setup, Executable
import os

SRC = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
print(SRC)

if __name__ == '__main__':
    setup(name="Site24x7Agent",
          version="0.1",
          description="",
          options={
              'build_exe': {
                  'build_exe': os.path.join(os.getenv('HOME'), 'kubernetes'),
                  'path': sys.path + [SRC]
              }
          },
          executables=[
              Executable("KubeAgent.py", target_name = "kubernetes.exe")
          ]
    )