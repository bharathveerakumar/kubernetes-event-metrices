import os

from com.manageengine.monagent.kubernetes.Logging import KubeLogger as AgentLogger

try:
    import requests
    REQUEST_MODULE = requests
except Exception as e:
    REQUEST_MODULE = None

#constants    
configParserSection = "kubernetes"
configMidParam = "mid"
configStatusParam = "enabled"
sendConfigParam = "sendConfig"
sendPerfParam = "sendPerf"
childWriteCountParam = "childWriteCount"
configDCIntervalParam = "configDCInterval"
apiEndpointParam = "apiServerEndpointUrl"
kubeStateMetricsParam = "kubestateMetricsUrl"
clusterDNParam = "clusterDisplayName"
eventsEnabledParam = "eventsEnabled"
eventsWriteCountParam="eventswritecount"
confData = ["[kubernetes] \n","enabled=1 \n","mid=0 \n","sendConfig=true \n","sendPerf=true \n","configDCInterval=15 \n","childWriteCount=500 \n","apiServerEndpointUrl= \n","kubestateMetricsUrl= \n","clusterDisplayName= \n","eventsEnabled=true \n", "eventswritecount=500 \n"] #configDCInterval in mins
KSM_MATCH_LABELS = {
    "app": "site24x7-kube-state-metrics",
    "app.kubernetes.io/name": "kube-state-metrics",
    "k8s-app": "kube-state-metrics"
}
RES_BASED_LAST_DC_TIME = {}
KUBE_GLOBAL_SETTINGS = {
    "kubernetes": "300",
    "daemonsets": "300",
    "deployments": "300",
    "statefulsets": "300",
    "pods": "300",
    "nodes": "300",
    "services": "300",
    "replicasets": "900",
    "ingresses": "300",
    "jobs": "300",
    "pv": "300",
    "persistentvolumeclaim": "300",
    "componentstatuses": "300",
    "horizontalpodautoscalers": "300",
    "endpoints": "3600",
    "namespaces": "300",
    "eventcollector": "60",
    "npcdatacollector": "300",
    "resourcedependency": "900",
    "confdatacollector": "300",
    "clustermetricsaggregator": "300",
    "dcinit": "900",
    "clusteragent": "1",
    "ksm": "1",
    "guidancemetrics": "20600",
    "termination": "900",
    "discovery": "900"
}
PROVIDER = "Self-Managed"
CLUSTER_AGENT_SVC = None
DC_START_TIME = None
API_ENDPOINT_RES_NAME_MAP = {
    "Nodes": "/api/v1/nodes",
    "Pods": "/api/v1/pods",
    "Deployments": "/apis/apps/v1/deployments",
    "DaemonSets": "/apis/apps/v1/daemonsets",
    "Namespaces": "/api/v1/namespaces",
    "Endpoints": "/api/v1/endpoints",
    "HorizontalPodAutoscalers": "/apis/autoscaling/v1/horizontalpodautoscalers",
    "Services": "/api/v1/services",
    "ReplicaSets": "/apis/apps/v1/replicasets",
    "StatefulSets": "/apis/apps/v1/statefulsets",
    "PV": "/api/v1/persistentvolumes",
    "PersistentVolumeClaim": "/api/v1/persistentvolumeclaims",
    "Jobs": "/apis/batch/v1/jobs",
    "Ingresses": "/apis/networking.k8s.io/v1/ingresses"
}

#xml files
confFile = ''
confXmlFile = ''
perfXmlFile = ''
resourceDependencyXmlFile = ''
npcConfigXmlFile = ''
npcPerfXmlFile = ''
cadvisorXmlFile = ''

# Servlet
KDR_SERVLET = '/dp/kb/KubernetesDataReceiver?'
RD_SERVLET = '/dp/kb/ResourceDependencyServlet?'

#kubernetes cluster details
kubernetesPresent = False
kubeServer = ""
kubeCluster = ""
kubeUniqueID = None
kubePlatform = None
kubeNamespace = ""
nodeType = ""
isContainerAgent = False
apiEndpoint = "https://kubernetes.default"
kubeStateMetricsUrl = ""
clusterDN = ""
nodeName = ""
fargate = False
mid = None
monStatus = 0
gkeAutoPilot = False
nonMountedAgent = False
isConfDc = False
isTerminationDc = False

#other configs       
childWriteCount = "500"
urlTimeout = 30
sendConfig = "true"
sendPerf = "true"
eventsWriteCount = "500"
PERF_POLL_INTERVAL = "300"
IP_ADDRESS = None

#secrets
serviceAccPath = "/var/run/secrets/kubernetes.io/serviceaccount"
bearerToken = ""
host = "https://kubernetes.default"
clusterDNPATH = "/api/v1/configmaps?fieldSelector=metadata.name=kube-proxy"
kubeletPath = "/api/v1/nodes/{}/proxy/"
kubeStatePodIP = None #10.244.1.120
kubeStatePort = "8080"
kubeletStatsPort = "10250"
gkeClusterNameEndpoint = "http://metadata.google.internal/computeMetadata/v1/instance/attributes/cluster-name"

#Events Constants
EVENTS_ENABLED = "true"
eventsListenerPath = "/apis/events.k8s.io/v1/events"

#on change data configs
prevConfigDataTime = -1
sendConfigDataInterval = 5 * 60 * 60 #in secs

#id configs
kubeIds = None
KUBELET_NODE_NAME = None
NO_NS_UNIQUNESS_TYPES=["Namespaces","Nodes","PV"]
TERMINATION_NOT_SUPPORTED_GRPS = ["ResourceQuota", "ComponentStatuses"]

# CLUSTER AGENT
CLUSTER_AGENT_VERSION = '1.0'
IS_CLUSTER_AGENT = False
CLUSTER_AGENT_SRC = ''
CONF_FOLDER_PATH = ''
CLUSTER_AGENT_WORKING_DIR = ''
LOGS_FOLDER_PATH = ''
PARSED_DATA_FOLDER_PATH = ''
DETAILS_LOGS_FOLDER_PATH = ''
KUBE_CONF_FOLDER_PATH = ''
DATA_TYPE_PARSED_FILE_MAP = ''
DATA_TYPE_METHOD_MAP = ''
KSM_OUTPUT_FILE = ''
CLUSTER_AGENT_UPGRADE_LOCK_FILE = ''
CLUSTER_AGENT_URL_DATA_TYPE_MAP = {
    'npc_ksm': '/pd/npc_ksm?ksm_needed=true',
    'node_base_ksm': '/pd/node_base_ksm?node_name={}',
    'conf_ksm': '/pd/conf_ksm?ksm_needed=true',
    'conf': '/pd/conf',
    'resource_dependency': '/pd/resource_dependency?ksm_needed=true',
    'cma': '/pd/cma'
}

def set_ca_type_map_constants():
    global DATA_TYPE_METHOD_MAP

    from com.manageengine.monagent.kubernetes.Parser.KubePrometheusParser import load_k8s_perf_xml
    from com.manageengine.monagent.kubernetes.Parser.KubeJsonParser import load_k8s_config_xml

    DATA_TYPE_METHOD_MAP = {
        'npc_ksm': [load_k8s_perf_xml, npcPerfXmlFile],
        'conf_ksm': [load_k8s_perf_xml, perfXmlFile],
        'resource_dependency': [load_k8s_perf_xml, resourceDependencyXmlFile],
        'conf': [load_k8s_config_xml, confXmlFile],
        'node_base_ksm': [load_k8s_perf_xml, npcPerfXmlFile]
    }

def set_cluster_agent_constants(src_path):
    global IS_CLUSTER_AGENT, CLUSTER_AGENT_SRC, CONF_FOLDER_PATH, CLUSTER_AGENT_WORKING_DIR, LOGS_FOLDER_PATH, PARSED_DATA_FOLDER_PATH, DETAILS_LOGS_FOLDER_PATH, KUBE_CONF_FOLDER_PATH, confXmlFile, perfXmlFile, npcPerfXmlFile, resourceDependencyXmlFile, DATA_TYPE_PARSED_FILE_MAP, KSM_OUTPUT_FILE, CLUSTER_AGENT_UPGRADE_LOCK_FILE

    CLUSTER_AGENT_SRC = src_path
    CONF_FOLDER_PATH = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(src_path))))) + '/conf'
    CLUSTER_AGENT_WORKING_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(src_path)))))
    LOGS_FOLDER_PATH = CLUSTER_AGENT_WORKING_DIR + '/logs'
    PARSED_DATA_FOLDER_PATH = CLUSTER_AGENT_WORKING_DIR + '/parsed_data'
    DETAILS_LOGS_FOLDER_PATH = LOGS_FOLDER_PATH + '/details'
    KUBE_CONF_FOLDER_PATH = src_path + '/com/manageengine/monagent/kubernetes/Conf'
    CLUSTER_AGENT_UPGRADE_LOCK_FILE = CONF_FOLDER_PATH + '/upgrade_lock_file.txt'
    confXmlFile = KUBE_CONF_FOLDER_PATH + '/kubernetesDCConfig.xml'
    perfXmlFile = KUBE_CONF_FOLDER_PATH + '/kubernetesDCPerf.xml'
    npcPerfXmlFile = KUBE_CONF_FOLDER_PATH + '/KubernetesNPCPerf.xml'
    resourceDependencyXmlFile = KUBE_CONF_FOLDER_PATH + '/KubernetesResourceDependency.xml'
    DATA_TYPE_PARSED_FILE_MAP = {
        'npc_ksm': 'npc_ksm_parsed_data.txt',
        'conf_ksm': 'conf_ksm_parsed_data.txt',
        'resource_dependency': 'rs_parsed_data.txt',
        'conf': 'conf_parsed_data.txt',
        'node_base_ksm': 'node_base_ksm.txt',
        'cma': 'cma_parsed_data.txt'
    }
    IS_CLUSTER_AGENT = True
    KSM_OUTPUT_FILE = PARSED_DATA_FOLDER_PATH + '/{}'.format('ksm_output.txt')
    set_ca_type_map_constants()

def set_mid(newMid):
    try:
        global mid
        if newMid and newMid!=mid:
            AgentLogger.log(AgentLogger.KUBERNETES,'KubeGlobal :: setting mid - '.format(newMid))
            mid = newMid
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'KubeGlobal :: setmid -> Exception -> {0}'.format(e))

def set_mon_status(newMonStatus):
    try:
        global monStatus
        if newMonStatus and newMonStatus!=monStatus:
            AgentLogger.log(AgentLogger.KUBERNETES,'KubeGlobal :: setting monStatus - '.format(newMonStatus))
            monStatus = newMonStatus
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'KubeGlobal :: setmid -> Exception -> {0}'.format(e))