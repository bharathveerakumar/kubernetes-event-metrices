import traceback
import json
import copy

from com.manageengine.monagent.kubernetes import KubeUtil, KubeGlobal
from com.manageengine.monagent.kubernetes.ClusterAgent import ClusterAgentUtil
from com.manageengine.monagent.kubernetes.Collector.DataCollector import DataCollector
from com.manageengine.monagent.kubernetes.Logging import KubeLogger as AgentLogger


class ConfDataCollector(DataCollector):

    def collect_data(self):
        try:
            self.final_json = ClusterAgentUtil.get_ca_parsed_data("conf")
            self.aggregate_workloads_metrics(self.final_json)
            AgentLogger.debug(AgentLogger.DA, "## final config data {}".format(json.dumps(self.final_json)))
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'collect_config_data -> Exception -> {0}'.format(e))

    def aggregate_workloads_metrics(self, perf_data):
        try:
            if KubeUtil.is_eligible_to_execute("kubernetes", False):
                perf_data["kubernetes"] = {}
                perf_data["kubernetes"]["version"] = KubeUtil.getKubeClusterVersion()

                KubeUtil.shift_data_to_k8s_node(perf_data)
                self.fetch_count_metrics(perf_data)
                self.process_ns_metrics(perf_data)
                self.process_service_metrics(perf_data)
                self.process_components_metrics(perf_data)
                self.process_job_metrics(perf_data)
                self.process_deployment_metrics(perf_data)
                self.process_dameonset_metrics(perf_data)
                self.process_replicaset_metrics(perf_data)
                self.process_statefulset_metrics(perf_data)
                self.process_node_metrics(perf_data)
                self.process_container_metrics(perf_data)
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'aggregate_workloads_metrics -> Exception -> {0}'.format(e))

    def fetch_count_metrics(self, perf_data):
        try:
            url = KubeGlobal.apiEndpoint + '{}?limit=1'

            perf_data["kubernetes"]["PC"] = KubeUtil.get_count_metric(url.format(KubeGlobal.API_ENDPOINT_RES_NAME_MAP["Pods"]))
            perf_data["kubernetes"]["NoC"] = KubeUtil.get_count_metric(url.format(KubeGlobal.API_ENDPOINT_RES_NAME_MAP["Nodes"]))
            perf_data["kubernetes"]["JC"] = KubeUtil.get_count_metric(url.format(KubeGlobal.API_ENDPOINT_RES_NAME_MAP["Jobs"]))
            perf_data["kubernetes"]["DPC"] = KubeUtil.get_count_metric(url.format(KubeGlobal.API_ENDPOINT_RES_NAME_MAP["Deployments"]))
            perf_data["kubernetes"]["DSC"] = KubeUtil.get_count_metric(url.format(KubeGlobal.API_ENDPOINT_RES_NAME_MAP["DaemonSets"]))
            perf_data["kubernetes"]["SSC"] = KubeUtil.get_count_metric(url.format(KubeGlobal.API_ENDPOINT_RES_NAME_MAP["StatefulSets"]))
            perf_data["kubernetes"]["RSC"] = KubeUtil.get_count_metric(url.format(KubeGlobal.API_ENDPOINT_RES_NAME_MAP["ReplicaSets"]))
            perf_data["kubernetes"]["SC"] = KubeUtil.get_count_metric(url.format(KubeGlobal.API_ENDPOINT_RES_NAME_MAP["Services"]))
            perf_data["kubernetes"]["NSCNT"] = KubeUtil.get_count_metric(url.format(KubeGlobal.API_ENDPOINT_RES_NAME_MAP["Namespaces"]))
        except Exception:
            traceback.print_exc()

    def process_ns_metrics(self, perf_data):
        try:
            for ns_name, ns_val in perf_data["Namespaces"].items():
                url = KubeGlobal.apiEndpoint + KubeGlobal.API_ENDPOINT_RES_NAME_MAP["Pods"] + "?fieldSelector=metadata.namespace={}&limit=1"
                ph_cnt_url = KubeGlobal.apiEndpoint + KubeGlobal.API_ENDPOINT_RES_NAME_MAP["Pods"] + "?fieldSelector=metadata.namespace={},status.phase={}&limit=1"
                ns_val["PC"] = KubeUtil.get_count_metric(url.format(ns_name))
                ns_val["Running"] = KubeUtil.get_count_metric(ph_cnt_url.format(ns_name, "Running"))
                ns_val["Succeeded"] = KubeUtil.get_count_metric(ph_cnt_url.format(ns_name, "Succeeded"))
                ns_val["Pending"] = KubeUtil.get_count_metric(ph_cnt_url.format(ns_name, "Pending"))
                ns_val["Failed"] = KubeUtil.get_count_metric(ph_cnt_url.format(ns_name, "Failed"))
                ns_val["Unknown"] = KubeUtil.get_count_metric(ph_cnt_url.format(ns_name, "Unknown"))
        except Exception as e:
            traceback.print_exc()

    def process_node_metrics(self, perf_data):
        try:
            KNR, KNNR, KNTC, KNTM, KNAC, KNAM, KNPA, KCPU, KCMU = 0, 0, 0, 0, 0, 0, 0, 0, 0
            if "Nodes" in self.ksm_data:
                for node_key, node_metrics in self.ksm_data["Nodes"].items():
                    if "KNSCCC" in node_metrics:
                        KNTC += int(node_metrics["KNSCCC"])
                    if "KNSACC" in node_metrics:
                        KNAC += float(node_metrics["KNSACC"])
                    if "KNSCMG" in node_metrics:
                        KNTM += int(node_metrics["KNSCMG"])
                    if "KNSAMG" in node_metrics:
                        KNAM += int(node_metrics["KNSAMG"])
                    if "KNSAP" in node_metrics:
                        KNPA += int(node_metrics["KNSAP"])
                    if "Cn" in node_metrics and node_metrics["Cn"] == "Ready" and "St" in node_metrics and node_metrics["St"] == "true":
                        KNR += 1
                    else:
                        KNNR += 1

                perf_data["kubernetes"]["KNR"] = KNR
                perf_data["kubernetes"]["KNNR"] = KNNR
                perf_data["kubernetes"]["KNTC"] = KNTC
                perf_data["kubernetes"]["KNAC"] = KNAC
                perf_data["kubernetes"]["KNTM"] = KNTM
                perf_data["kubernetes"]["KNAM"] = KNAM
                perf_data["kubernetes"]["KNPA"] = KNPA
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'process_node_metrics -> Exception -> {0}'.format(e))

    def process_job_metrics(self, perfData):
        KJSC, KJFC = 0, 0
        try:
            if perfData and 'Jobs' in perfData:
                for key, value in perfData['Jobs'].items():
                    if "Co" in value and value["Co"] == "":
                        value["Co"] = 0
                    if "Su" in value and value["Su"] == "":
                        value["Su"] = 0

                    if "KJSS" in value and int(value["KJSS"]) == 1:
                        KJSC += int(value["KJSS"])
                    if "KJSF" in value and int(value["KJSF"]) == 1:
                        KJFC += int(value["KJSF"])
                    if "Su" in value and int(value["Su"]) == 1:
                        if "STM" in value and value["STM"] and "CMPT" in value and value["CMPT"]:
                            ct = value["CMPT"].split("T")
                            ct = ct[0] + " " + ct[1].split('Z')[0] + ".000000"
                            value["duration"] = KubeUtil.getAge(value["STM"], ct)
                    value["GRJTTL"] = "ttl" in value and not value["ttl"]  # GR
                perfData["kubernetes"]["KJSC"] = KJSC
                perfData["kubernetes"]["KJFC"] = KJFC
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'process_job_metrics -> Exception -> {0}'.format(e))

    def process_deployment_metrics(self, perfData):
        KDR, KDRA, KDRUA, KDRUP, KDDR, KDPR, KDMUR = 0, 0, 0, 0, 0, 0, 0
        try:
            if perfData and 'Deployments' in perfData:
                for key, value in perfData['Deployments'].items():
                    try:
                        value["KDSRUA"] = value["KDSpR"] - value["KDSRA"]
                        if "KDSR" in value and len(str(value["KDSR"])) > 0:
                            KDR += int(value["KDSR"])
                        if "KDSRA" in value and len(str(value["KDSRA"])) > 0:
                            KDRA += int(value["KDSRA"])
                        if "KDSRUA" in value and len(str(value["KDSRUA"])) > 0:
                            KDRUA += int(value["KDSRUA"])
                        if "KDSRUP" in value and len(str(value["KDSRUP"])) > 0:
                            KDRUP += int(value["KDSRUP"])
                        if "KDSpR" in value and len(str(value["KDSpR"])) > 0:
                            KDDR += int(value["KDSpR"])
                        if "KDSpPa" in value and value["KDSpPa"] == True:
                            KDPR += 1
                            value["KDSpPa"] = 1
                        if "KDSpSRMUA" in value and "%" in str(value["KDSpSRMUA"]):
                            value["KDSpSRMUA"] = value["KDSpR"]
                            KDMUR += int(value["KDSpSRMUA"])
                        value["GRDMR"] = int(value["KDSpR"]) > 1
                    except Exception as e:
                        traceback.print_exc()

                perfData["kubernetes"]["KDR"] = KDR
                perfData["kubernetes"]["KDRA"] = KDRA
                perfData["kubernetes"]["KDRUA"] = KDRUA
                perfData["kubernetes"]["KDRUP"] = KDRUP
                perfData["kubernetes"]["KDDR"] = KDDR
                perfData["kubernetes"]["KDPR"] = KDPR
                perfData["kubernetes"]["KDMUR"] = KDMUR
                perfData["kubernetes"]["KDO"] = KDR - KDRUP
                perfData["kubernetes"]["KDDNA"] = KDDR - KDRA
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'process_deployment_metrics -> Exception -> {0}'.format(e))

    def process_dameonset_metrics(self, perfData):
        KDSD, KDSR, KDSA, KDSS, KDSM = 0, 0, 0, 0, 0
        try:
            if perfData and 'DaemonSets' in perfData:
                for key, value in perfData['DaemonSets'].items():
                    try:
                        if "KDSNA" in value and len(str(value["KDSNA"])) > 0:
                            KDSA += int(value["KDSNA"])
                        if "KDSNM" in value and len(str(value["KDSNM"])) > 0:
                            KDSM += int(value["KDSNM"])
                        if "KDSCNR" in value and len(str(value["KDSCNR"])) > 0:
                            KDSR += int(value["KDSCNR"])
                        if "KDSDNS" in value and len(str(value["KDSDNS"])) > 0:
                            KDSD += int(value["KDSDNS"])
                        if "KDSCNS" in value and len(str(value["KDSCNS"])) > 0:
                            KDSS += int(value["KDSCNS"])
                    except Exception as e:
                        traceback.print_exc()

                perfData["kubernetes"]["KDSD"] = KDSD
                perfData["kubernetes"]["KDSR"] = KDSR
                perfData["kubernetes"]["KDSA"] = KDSA
                perfData["kubernetes"]["KDSS"] = KDSS
                perfData["kubernetes"]["KDSNR"] = KDSD - KDSR
                perfData["kubernetes"]["KDSM"] = KDSM
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'process_dameonset_metrics -> Exception -> {0}'.format(e))

    def process_statefulset_metrics(self, perfData):
        KSSD, KSSCC, KSSU, KSSRR, KSSC, KSSCRe, KSSURe = 0, 0, 0, 0, 0, 0, 0
        try:
            if perfData and 'StatefulSets' in perfData:
                for key, value in perfData['StatefulSets'].items():
                    try:
                        if "Re" in value and len(str(value["Re"])) > 0:
                            KSSD += int(value["Re"])
                        if "CR" in value and len(str(value["CR"])) > 0:
                            KSSC += int(value["CR"])
                        if "UR" in value and len(str(value["UR"])) > 0:
                            KSSU += int(value["UR"])

                        if "RR" in value and len(str(value["RR"])) > 0:
                            KSSRR += int(value["RR"])
                        else:
                            value["RR"] = 0

                        if "CC" in value and len(str(value["CC"])) > 0:
                            KSSCC += int(value["CC"])

                        if "RR" in value and len(str(value["RR"])) > 0 and "Re" in value and len(str(value["Re"])) > 0:
                            value["NR"] = value["Re"] - value["RR"]
                        else:
                            value["NR"] = 0
                    except Exception as e:
                        traceback.print_exc()

                perfData["kubernetes"]["KSSD"] = KSSD
                perfData["kubernetes"]["KSSCC"] = KSSCC
                perfData["kubernetes"]["KSSU"] = KSSU
                perfData["kubernetes"]["KSSRR"] = KSSRR
                perfData["kubernetes"]["KSSNR"] = KSSD - KSSRR
                perfData["kubernetes"]["KSSC"] = KSSC
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'process_statefulset_metrics -> Exception -> {0}'.format(e))

    def process_replicaset_metrics(self, perfData):
        KRCS, KRS, KRR, KRD, KRIA, KRNR = 0, 0, 0, 0, 0, 0
        try:
            if perfData and 'ReplicaSets' in perfData:
                for key, value in perfData['ReplicaSets'].items():
                    if "KRSSR" in value and len(str(value["KRSSR"])) > 0:
                        KRS += int(value["KRSSR"])
                    if "KRSSRR" in value and len(str(value["KRSSRR"])) > 0:
                        KRR += int(value["KRSSRR"])
                    if "KRSSRC" in value and len(str(value["KRSSRC"])) > 0:
                        KRCS += 1
                    if "KRSpSR" in value and len(str(value["KRSpSR"])) > 0:
                        KRD += int(value["KRSpSR"])
                    if "KRSSR" in value and len(str(value["KRSSR"])) == 0:
                        KRIA += 1
            perfData["kubernetes"]["KRA"] = KRCS - KRIA
            perfData["kubernetes"]["KRIA"] = KRIA
            perfData["kubernetes"]["KRNR"] = KRD - KRR
            perfData["kubernetes"]["KRS"] = KRS
            perfData["kubernetes"]["KRCS"] = KRCS
            perfData["kubernetes"]["KRR"] = KRR
            perfData["kubernetes"]["KRD"] = KRD
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'process_replicaset_metrics -> Exception -> {0}'.format(e))

    def process_components_metrics(self, perfData):
        try:
            for comp, status in perfData["kubernetes"]["ComponentStatuses"].items():
                if "Cnds" in status and "Healthy" in status["Cnds"] and status["Cnds"]["Healthy"]["St"] == "True":
                    status["Ph"] = 1
                    status["Fi"] = "Ok"
                    status["Me"] = "Ok"
                else:
                    status["Ph"] = 0
                    status["Fi"] = "Not Healthy"
                    status["Me"] = "Not Healthy"
                status.pop("Cnds")
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'process_components_metrics -> Exception -> {0}'.format(e))
        return perfData

    def process_container_metrics(self, perf_data):
        KPCSW, KPCST, KPCSR, KPCSRe, CONT_CNT = 0, 0, 0, 0, 0
        try:
            cont_dict = self.ksm_data.get("Cont", {})

            for cont_key, cont_data in cont_dict.items():
                try:
                    if type(cont_data) == dict:
                        CONT_CNT += 1
                        if "KPCST" in cont_data and str(cont_data["KPCST"]) == '1':
                            KPCST += 1
                        if "KPCSW" in cont_data and str(cont_data["KPCSW"]) == '1':
                            KPCSW += 1
                        if "KPCSRe" in cont_data and str(cont_data["KPCSRe"]) == '1':
                            KPCSRe += 1
                        if "KPCSR" in cont_data and str(cont_data["KPCSR"]) == '1':
                            KPCSR += 1
                except Exception as e:
                    traceback.print_exc()

            perf_data["kubernetes"]["CC"] = CONT_CNT
            perf_data["kubernetes"]["KPCSW"] = KPCSW
            perf_data["kubernetes"]["KPCSR"] = KPCSR
            perf_data["kubernetes"]["KPCST"] = KPCST
            perf_data["kubernetes"]["KPCSRe"] = KPCSRe

            perf_data["kubernetes"]["CTR_C"] = cont_dict.pop("CTR_Completed", 0)
            perf_data["kubernetes"]["CTR_OOM"] = cont_dict.pop("CTR_OOMKilled", 0)
            perf_data["kubernetes"]["CRT_E"] = cont_dict.pop("CTR_Error", 0)
            perf_data["kubernetes"]["CTR_CCR"] = cont_dict.pop("CTR_ContainerCannotRun", 0)
            perf_data["kubernetes"]["CTR_DE"] = cont_dict.pop("CTR_DeadlineExceeded", 0)
            perf_data["kubernetes"]["CTR_E"] = cont_dict.pop("CTR_Evicted", 0)
            perf_data["kubernetes"]["CWR_CC"] = cont_dict.pop("CWR_ContainerCreating", 0)
            perf_data["kubernetes"]["CWR_CLP"] = cont_dict.pop("CWR_CrashLoopBackOff", 0)
            perf_data["kubernetes"]["CWR_CE"] = cont_dict.pop("CWR_CreateContainerConfigError", 0)
            perf_data["kubernetes"]["CWR_EI"] = cont_dict.pop("CWR_ErrImagePull", 0)
            perf_data["kubernetes"]["CWR_IP"] = cont_dict.pop("CWR_ImagePullBackOff", 0)
            perf_data["kubernetes"]["CWR_CCE"] = cont_dict.pop("CWR_CreateContainerError", 0)
            perf_data["kubernetes"]["CWR_II"] = cont_dict.pop("CWR_InvalidImageName", 0)
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'process_container_metrics -> Exception -> {0}'.format(e))

    def process_service_metrics(self, perfData):
        try:
            if perfData and "Services" in perfData:
                for key, value in perfData['Services'].items():
                    ports = {}
                    if "Po" in value:
                        port_map = value["Po"]
                        for k, v in port_map.items():
                            p = str(v["NPo"]) + "/" + v["Pr"] if "NPo" in v else v["Pr"]
                            ports[str(k)] = p
                    value["Po"] = json.dumps(ports)

                    value["eps_map"] = json.dumps("")

                    if "Ty" in value:
                        service_type = value["Ty"]
                        if service_type not in perfData["kubernetes"]:
                            perfData["kubernetes"][service_type] = 1
                        else:
                            perfData["kubernetes"][service_type] += 1

                    if "Sel" in value:
                        selector = value["Sel"]
                        value["Sel"] = json.dumps(selector)
                        self.decide_service_status(selector, value)

                    if "LIP" in value:
                        if "ingress" in value["LIP"] and isinstance(value["LIP"]["ingress"], list):
                            ip_lst = copy.deepcopy(value["LIP"]["ingress"])
                            value["LIPs"] = []
                            for ip in ip_lst:
                                if "ip" in ip:
                                    value["EXIP"].append(ip["ip"])
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'process_service_metrics -> Exception -> {0}'.format(e))

    def decide_service_status(self, selector, svc_data):
        try:
            svc_data["ready_status"] = "true"
            ns = svc_data["NS"]

            match_labels = []
            for key, value in selector.items():
                match_labels.append("{}%3D{}".format(key, value))

            status, json = KubeUtil.curl_api_with_token(
                "https://kubernetes.default/api/v1/pods?fieldSelector=status.phase!=Running,metadata.namespace={}&labelSelector={}".format(
                    ns, ",".join(match_labels)))
            if status == 200 and "items" in json and len(json["items"]) > 0:
                svc_data["ready_status"] = "false"
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'decide_service_status -> Exception -> {0}'.format(e))