import traceback
import json
import copy
from datetime import datetime

from com.manageengine.monagent.kubernetes import KubeUtil, KubeGlobal
from com.manageengine.monagent.kubernetes.ClusterAgent import ClusterAgentUtil
from com.manageengine.monagent.kubernetes.Collector.DataCollector import DataCollector
from com.manageengine.monagent.kubernetes.Logging import KubeLogger as AgentLogger


class ConfDataCollector(DataCollector):
    def __init__(self, dc_requisites_obj):
        super().__init__(dc_requisites_obj)
        self.ksm_data = ClusterAgentUtil.get_ca_parsed_data("npc_ksm")

    def collect_data(self):
        try:
            self.final_json = ClusterAgentUtil.get_ca_parsed_data("conf")
            self.aggregate_workloads_metrics(self.final_json)
            AgentLogger.debug(AgentLogger.DA, "## final config data {}".format(json.dumps(self.final_json)))
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'collect_config_data -> Exception -> {0}'.format(e))

    def aggregate_workloads_metrics(self, perf_data):
        try:
            if KubeUtil.is_eligible_to_execute("kubernetes", False):
                perf_data["kubernetes"] = {}
                perf_data["kubernetes"]["version"] = KubeUtil.getKubeClusterVersion()

                KubeUtil.shift_data_to_k8s_node(perf_data)
                self.fetch_count_metrics(perf_data)
                self.process_ns_metrics(perf_data)
                self.process_pod_metrics(perf_data)
                self.process_node_metrics(perf_data)
                self.process_container_metrics(perf_data)
                self.process_service_metrics(perf_data)
                self.process_components_metrics(perf_data)
                self.process_job_metrics(perf_data)
                self.process_deployment_metrics(perf_data)
                self.process_dameonset_metrics(perf_data)
                self.process_replicaset_metrics(perf_data)
                self.process_statefulset_metrics(perf_data)
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'aggregate_workloads_metrics -> Exception -> {0}'.format(e))

    def fetch_count_metrics(self, perf_data):
        try:
            url = KubeGlobal.apiEndpoint + '{}?limit=1'
            perf_data["kubernetes"]["PC"] = KubeUtil.get_count_metric(url.format(KubeGlobal.API_ENDPOINT_RES_NAME_MAP["Pods"]))
            perf_data["kubernetes"]["NoC"] = KubeUtil.get_count_metric(url.format(KubeGlobal.API_ENDPOINT_RES_NAME_MAP["Nodes"]))
            perf_data["kubernetes"]["JC"] = KubeUtil.get_count_metric(url.format(KubeGlobal.API_ENDPOINT_RES_NAME_MAP["Jobs"]))
            perf_data["kubernetes"]["DPC"] = KubeUtil.get_count_metric(url.format(KubeGlobal.API_ENDPOINT_RES_NAME_MAP["Deployments"]))
            perf_data["kubernetes"]["DSC"] = KubeUtil.get_count_metric(url.format(KubeGlobal.API_ENDPOINT_RES_NAME_MAP["DaemonSets"]))
            perf_data["kubernetes"]["SSC"] = KubeUtil.get_count_metric(url.format(KubeGlobal.API_ENDPOINT_RES_NAME_MAP["StatefulSets"]))
            perf_data["kubernetes"]["RSC"] = KubeUtil.get_count_metric(url.format(KubeGlobal.API_ENDPOINT_RES_NAME_MAP["ReplicaSets"]))
            perf_data["kubernetes"]["SC"] = KubeUtil.get_count_metric(url.format(KubeGlobal.API_ENDPOINT_RES_NAME_MAP["Services"]))
            perf_data["kubernetes"]["NSCNT"] = KubeUtil.get_count_metric(url.format(KubeGlobal.API_ENDPOINT_RES_NAME_MAP["Namespaces"]))
        except Exception:
            traceback.print_exc()

    def process_ns_metrics(self, perf_data):
        try:
            for ns_name, ns_val in perf_data["Namespaces"].items():
                ns_pod_cnt_url = KubeGlobal.apiEndpoint + '/api/v1/namespaces/{}/pods?limit=1'
                ns_val["PC"] = KubeUtil.get_count_metric(ns_pod_cnt_url.format(ns_name))
                ns_val["Running"] = 0
                ns_val["Succeeded"] = 0
                ns_val["Pending"] = 0
                ns_val["Failed"] = 0
                ns_val["Unknown"] = 0
        except Exception:
            traceback.print_exc()

    def process_pod_metrics(self, perf_data):
        try:
            phase_stats = {
                "Running": 0,
                "Succeeded": 0,
                "Pending": 0,
                "Failed": 0,
                "Unknown": 0
            }

            for pod_key, pod_metrics in self.ksm_data["Pods"].items():
                ph = pod_metrics["Ph"]
                perf_data["Namespaces"][pod_metrics["NS"]][ph] += 1
                phase_stats[ph] += 1

            perf_data["kubernetes"]["KPR"] = phase_stats.get("Running")
            perf_data["kubernetes"]["KPS"] = phase_stats.get("Succeeded")
            perf_data["kubernetes"]["KPP"] = phase_stats.get("Pending")
            perf_data["kubernetes"]["KPF"] = phase_stats.get("Failed")
            perf_data["kubernetes"]["KPU"] = phase_stats.get("Unknown")
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'process_pod_metrics -> Exception -> {0}'.format(e))

    def process_node_metrics(self, perf_data):
        try:
            KNR, KNNR, KNTC, KNTM, KNAC, KNAM, KNPA, KCPU, KCMU = 0, 0, 0, 0, 0, 0, 0, 0, 0
            for node_key, node_metrics in self.ksm_data["Nodes"].items():
                KNTC += int(node_metrics.get("KNSCCC", 0))
                KNAC += float(node_metrics.get("KNSACC", 0))
                KNTM += int(node_metrics.get("KNSCMG", 0))
                KNAM += int(node_metrics.get("KNSAMG", 0))
                KNPA += int(node_metrics.get("KNSAP", 0))
                KNR, KNNR = (KNR + 1, KNNR) if node_metrics.get("Cn") == "Ready" and node_metrics.get("St") == "true" else (KNR, KNNR + 1)

            perf_data["kubernetes"]["KNR"] = KNR
            perf_data["kubernetes"]["KNNR"] = KNNR
            perf_data["kubernetes"]["KNTC"] = KNTC
            perf_data["kubernetes"]["KNAC"] = KNAC
            perf_data["kubernetes"]["KNTM"] = KNTM
            perf_data["kubernetes"]["KNAM"] = KNAM
            perf_data["kubernetes"]["KNPA"] = KNPA
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'process_node_metrics -> Exception -> {0}'.format(e))

    def process_container_metrics(self, perf_data):
        KPCSW, KPCST, KPCSR, KPCSRe, CONT_CNT = 0, 0, 0, 0, 0
        try:
            cont_dict = self.ksm_data.get("Cont", {})

            for cont_key, cont_data in cont_dict.items():
                if type(cont_data) == dict:
                    CONT_CNT += 1
                    KPCST = (KPCST + 1) if str(cont_data.get("KPCST")) == '1' else KPCST
                    KPCSW = (KPCSW + 1) if str(cont_data.get("KPCSW")) == '1' else KPCSW
                    KPCSRe = (KPCSRe + 1) if str(cont_data.get("KPCSRe")) == '1' else KPCSRe
                    KPCSR = (KPCSR + 1) if str(cont_data.get("KPCSR")) == '1' else KPCSR

            perf_data["kubernetes"]["CC"] = CONT_CNT
            perf_data["kubernetes"]["KPCSW"] = KPCSW
            perf_data["kubernetes"]["KPCSR"] = KPCSR
            perf_data["kubernetes"]["KPCST"] = KPCST
            perf_data["kubernetes"]["KPCSRe"] = KPCSRe

            perf_data["kubernetes"]["CTR_C"] = cont_dict.pop("CTR_Completed", 0)
            perf_data["kubernetes"]["CTR_OOM"] = cont_dict.pop("CTR_OOMKilled", 0)
            perf_data["kubernetes"]["CRT_E"] = cont_dict.pop("CTR_Error", 0)
            perf_data["kubernetes"]["CTR_CCR"] = cont_dict.pop("CTR_ContainerCannotRun", 0)
            perf_data["kubernetes"]["CTR_DE"] = cont_dict.pop("CTR_DeadlineExceeded", 0)
            perf_data["kubernetes"]["CTR_E"] = cont_dict.pop("CTR_Evicted", 0)
            perf_data["kubernetes"]["CWR_CC"] = cont_dict.pop("CWR_ContainerCreating", 0)
            perf_data["kubernetes"]["CWR_CLP"] = cont_dict.pop("CWR_CrashLoopBackOff", 0)
            perf_data["kubernetes"]["CWR_CE"] = cont_dict.pop("CWR_CreateContainerConfigError", 0)
            perf_data["kubernetes"]["CWR_EI"] = cont_dict.pop("CWR_ErrImagePull", 0)
            perf_data["kubernetes"]["CWR_IP"] = cont_dict.pop("CWR_ImagePullBackOff", 0)
            perf_data["kubernetes"]["CWR_CCE"] = cont_dict.pop("CWR_CreateContainerError", 0)
            perf_data["kubernetes"]["CWR_II"] = cont_dict.pop("CWR_InvalidImageName", 0)
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'process_container_metrics -> Exception -> {0}'.format(e))

    def process_job_metrics(self, perfData):
        try:
            job_phase_cnt = {
                'active': 0,
                'failed': 0,
                'succeeded': 0,
                'completed': 0
            }
            for key, value in perfData['Jobs'].items():
                value["KJSS"], value["KJSF"], value["KJC"], value["KJSA"] = 0, 0, 0, 0
                value["job_status"] = self.decide_job_status(value, job_phase_cnt)
                ct = datetime.now()

                if "CMPT" in value and value["CMPT"]:
                    ct = value["CMPT"].split("T")
                    ct = ct[0] + " " + ct[1].split('Z')[0] + ".000000"

                value["duration"] = KubeUtil.getAge(value.get("STM"), ct)
                value["GRJTTL"] = "ttl" in value and not value["ttl"]  # GR

            perfData["kubernetes"]["KJSC"] = job_phase_cnt.pop('succeeded')
            perfData["kubernetes"]["KJFC"] = job_phase_cnt.pop('failed')
            perfData["kubernetes"]["KJAC"] = job_phase_cnt.pop('active')
            perfData["kubernetes"]["KJCC"] = job_phase_cnt.pop('completed')
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'process_job_metrics -> Exception -> {0}'.format(e))

    def decide_job_status(self, job_data, ph_cnt):
        status = ""
        if job_data.get("Su"):
            job_data["KJSS"], ph_cnt['succeeded'], status = 1, ph_cnt['succeeded'] + 1, "Succeeded"

        if job_data.get("failed"):
            job_data["KJSF"], ph_cnt['failed'], status = 1, ph_cnt['failed'] + 1, "Failed"

        if job_data.get("CMPT"):
            job_data["KJC"], ph_cnt['completed'], status = 1, ph_cnt['completed'] + 1, "Completed"

        if job_data["KJSS"] and job_data["KJSF"] and job_data["KJC"]:
            job_data["KJSA"], ph_cnt['active'], status = 1, ph_cnt['active'] + 1, "Active"

        return status

    def process_deployment_metrics(self, perfData):
        KDR, KDRA, KDRUA, KDRUP, KDDR, KDPR, KDMUR = 0, 0, 0, 0, 0, 0, 0
        try:
            for key, value in perfData['Deployments'].items():
                try:
                    if "KDSRA" not in value or not len(str(value["KDSRA"])) > 0:
                        value["KDSRA"] = 0
                    if "KDSR" in value and len(str(value["KDSR"])) > 0:
                        KDR += int(value["KDSR"])
                    if "KDSRA" in value and len(str(value["KDSRA"])) > 0:
                        KDRA += int(value["KDSRA"])
                    if "KDSRUA" in value and len(str(value["KDSRUA"])) > 0:
                        KDRUA += int(value["KDSRUA"])
                    if "KDSRUP" in value and len(str(value["KDSRUP"])) > 0:
                        KDRUP += int(value["KDSRUP"])
                    if "KDSpR" in value and len(str(value["KDSpR"])) > 0:
                        KDDR += int(value["KDSpR"])
                    if "KDSpPa" in value and value["KDSpPa"] == True:
                        KDPR += 1
                        value["KDSpPa"] = 1
                    else: value["KDSpPa"] = 0
                    if "KDSpSRMUA" in value and "%" in str(value["KDSpSRMUA"]):
                        value["KDSpSRMUA"] = value["KDSpR"]
                        KDMUR += int(value["KDSpSRMUA"])
                    value["GRDMR"] = int(value["KDSpR"]) > 1
                    value["KDSRUA"] = int(value["KDSpR"]) - int(value["KDSRA"])
                except Exception as e:
                    traceback.print_exc()

                perfData["kubernetes"]["KDR"] = KDR
                perfData["kubernetes"]["KDRA"] = KDRA
                perfData["kubernetes"]["KDRUA"] = KDRUA
                perfData["kubernetes"]["KDRUP"] = KDRUP
                perfData["kubernetes"]["KDDR"] = KDDR
                perfData["kubernetes"]["KDPR"] = KDPR
                perfData["kubernetes"]["KDMUR"] = KDMUR
                perfData["kubernetes"]["KDO"] = KDR - KDRUP
                perfData["kubernetes"]["KDDNA"] = KDDR - KDRA
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'process_deployment_metrics -> Exception -> {0}'.format(e))

    def process_dameonset_metrics(self, perfData):
        KDSD, KDSR, KDSA, KDSS, KDSM = 0, 0, 0, 0, 0
        try:
            for key, value in perfData['DaemonSets'].items():
                try:
                    if "KDSNA" in value and len(str(value["KDSNA"])) > 0:
                        KDSA += int(value["KDSNA"])
                    if "KDSNM" in value and len(str(value["KDSNM"])) > 0:
                        KDSM += int(value["KDSNM"])
                    if "KDSCNR" in value and len(str(value["KDSCNR"])) > 0:
                        KDSR += int(value["KDSCNR"])
                    if "KDSDNS" in value and len(str(value["KDSDNS"])) > 0:
                        KDSD += int(value["KDSDNS"])
                    if "KDSCNS" in value and len(str(value["KDSCNS"])) > 0:
                        KDSS += int(value["KDSCNS"])
                except Exception:
                    traceback.print_exc()

                perfData["kubernetes"]["KDSD"] = KDSD
                perfData["kubernetes"]["KDSR"] = KDSR
                perfData["kubernetes"]["KDSA"] = KDSA
                perfData["kubernetes"]["KDSS"] = KDSS
                perfData["kubernetes"]["KDSNR"] = KDSD - KDSR
                perfData["kubernetes"]["KDSM"] = KDSM
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'process_dameonset_metrics -> Exception -> {0}'.format(e))

    def process_statefulset_metrics(self, perfData):
        KSSD, KSSCC, KSSU, KSSRR, KSSC, KSSCRe, KSSURe = 0, 0, 0, 0, 0, 0, 0
        try:
            for key, value in perfData['StatefulSets'].items():
                try:
                    if "Re" in value and len(str(value["Re"])) > 0:
                        KSSD += int(value["Re"])
                    if "CR" in value and len(str(value["CR"])) > 0:
                        KSSC += int(value["CR"])
                    if "UR" in value and len(str(value["UR"])) > 0:
                        KSSU += int(value["UR"])

                    if "RR" in value and len(str(value["RR"])) > 0:
                        KSSRR += int(value["RR"])
                    else:
                        value["RR"] = 0

                    if "CC" in value and len(str(value["CC"])) > 0:
                        KSSCC += int(value["CC"])

                    if "RR" in value and len(str(value["RR"])) > 0 and "Re" in value and len(str(value["Re"])) > 0:
                        value["NR"] = value["Re"] - value["RR"]
                    else:
                        value["NR"] = 0
                except Exception:
                    traceback.print_exc()

                perfData["kubernetes"]["KSSD"] = KSSD
                perfData["kubernetes"]["KSSCC"] = KSSCC
                perfData["kubernetes"]["KSSU"] = KSSU
                perfData["kubernetes"]["KSSRR"] = KSSRR
                perfData["kubernetes"]["KSSNR"] = KSSD - KSSRR
                perfData["kubernetes"]["KSSC"] = KSSC
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'process_statefulset_metrics -> Exception -> {0}'.format(e))

    def process_replicaset_metrics(self, perfData):
        KRCS, KRS, KRR, KRD, KRIA, KRNR = 0, 0, 0, 0, 0, 0
        try:
            if perfData and 'ReplicaSets' in perfData:
                for key, value in perfData['ReplicaSets'].items():
                    if "KRSSR" in value and len(str(value["KRSSR"])) > 0:
                        KRS += int(value["KRSSR"])
                    if "KRSSRR" in value and len(str(value["KRSSRR"])) > 0:
                        KRR += int(value["KRSSRR"])
                    if "KRSSRC" in value and len(str(value["KRSSRC"])) > 0:
                        KRCS += 1
                    if "KRSpSR" in value and len(str(value["KRSpSR"])) > 0:
                        KRD += int(value["KRSpSR"])
                    if "KRSSR" in value and len(str(value["KRSSR"])) == 0:
                        KRIA += 1
            perfData["kubernetes"]["KRA"] = KRCS - KRIA
            perfData["kubernetes"]["KRIA"] = KRIA
            perfData["kubernetes"]["KRNR"] = KRD - KRR
            perfData["kubernetes"]["KRS"] = KRS
            perfData["kubernetes"]["KRCS"] = KRCS
            perfData["kubernetes"]["KRR"] = KRR
            perfData["kubernetes"]["KRD"] = KRD
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'process_replicaset_metrics -> Exception -> {0}'.format(e))

    def process_components_metrics(self, perfData):
        try:
            for comp, status in perfData["kubernetes"]["ComponentStatuses"].items():
                if "Cnds" in status and "Healthy" in status["Cnds"] and status["Cnds"]["Healthy"]["St"] == "True":
                    status["Ph"] = 1
                    status["Fi"] = "Ok"
                    status["Me"] = "Ok"
                else:
                    status["Ph"] = 0
                    status["Fi"] = "Not Healthy"
                    status["Me"] = "Not Healthy"
                status.pop("Cnds")
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'process_components_metrics -> Exception -> {0}'.format(e))
        return perfData

    def process_service_metrics(self, perfData):
        for key, value in perfData.get('Services', {}).items():
            try:
                ports = {}
                node_ports = []
                ext_ips = []

                for k, v in value.get("Po",{}).items():
                    p = (str(v["NPo"]) + "/" + v["Pr"], node_ports.append(str(v["NPo"])))[0] if v.get("NPo") else v["Pr"]
                    ports[str(k)] = p

                value["Po"] = json.dumps(ports)
                value["NPo"] = ",".join(node_ports)

                if "Ty" in value:
                    service_type = value["Ty"]
                    perfData["kubernetes"][service_type] = perfData["kubernetes"].get(service_type, 0) + 1

                selector = value.get("Sel")
                if selector:
                    value["Sel"] = json.dumps(selector)
                    value["eps"] = self.construct_endpoints(key, ports.keys())
                    value["ready_status"] = self.decide_service_status(selector, value["NS"])

                for ips in value.get("LIPs", {}).get("ingress", []):
                    ext_ips.append(ips["ip"])
                value.pop("LIPs", None)
                value["LIP"] = ",".join(ext_ips)
            except Exception as e:
                value.pop("LIPs", None)
                value.pop("Sel", None)
                value.pop("Po", None)
                traceback.print_exc()
                AgentLogger.log(AgentLogger.KUBERNETES, 'process_service_metrics -> Exception -> {0}'.format(e))

    def decide_service_status(self, selector, ns):
        try:
            match_labels = []
            for key, value in selector.items():
                match_labels.append("{}%3D{}".format(key, value))

            status, json = KubeUtil.curl_api_with_token(
                KubeGlobal.apiEndpoint + KubeGlobal.API_ENDPOINT_RES_NAME_MAP["Pods"] + "?fieldSelector=status.phase!=Running,metadata.namespace={}&labelSelector={}&limit=1".format(
                    ns, ",".join(match_labels)))
            if status == 200 and "items" in json and len(json["items"]) > 0:
                return "false"
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'decide_service_status -> Exception -> {0}'.format(e))
        return "true"

    def construct_endpoints(self, svc_key, ports):
        eps_map = {}
        try:
            svc_name, ns = svc_key.split("_")
            status, api_resp = KubeUtil.curl_api_with_token(KubeGlobal.apiEndpoint + KubeGlobal.API_ENDPOINT_RES_NAME_MAP["Endpoints"] + "?fieldSelector=metadata.name={},metadata.namespace={}".format(svc_name, ns))
            if status == 200:
                subsets = api_resp["items"][0]["subsets"][0]
                ports = ",".join(ports)
                for address in subsets["addresses"]:
                    eps_map[address["ip"]] = ports
        except Exception:
            traceback.print_exc()
        return json.dumps(eps_map)
