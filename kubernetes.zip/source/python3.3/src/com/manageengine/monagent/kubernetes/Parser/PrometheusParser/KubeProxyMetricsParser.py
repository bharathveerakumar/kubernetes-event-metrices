from com.manageengine.monagent.kubernetes.Parser.PrometheusParserInterface import PrometheusParser


class KubeProxyMetricsParser(PrometheusParser):
    def __init__(self, kube_proxy_endpoint):
        super().__init__(kube_proxy_endpoint)
        self.parser_config = {
            'kubeproxy_sync_proxy_rules_duration_seconds': [
                {
                    'short_name': 'KPSPDS',
                    'sum': ['', 'KPSPDS']
                }
            ],
            'rest_client_request_duration_seconds': [
                {
                    'short_name': 'KPRCRDS',
                    'group_name': 'request_duration_verb',
                    'labels': {
                        'verb': 'verb'
                    },
                    'sum': ['', 'KPRCRDS'],
                    'group_labels': ['verb']
                }
            ],
            'rest_client_requests': [
                {
                    'short_name': 'KPRCRC',
                    'group_name': 'request_count_code',
                    'labels': {
                        'code': 'code'
                    },
                    'sum': ['', 'KPRCRC'],
                    'group_labels': ['code']
                },
                {
                    'short_name': 'KPRCRV',
                    'group_name': 'request_count_verb',
                    'labels': {
                        'method': 'verb'
                    },
                    'sum': ['', 'KPRCRV'],
                    'group_labels': ['method']
                },
            ]
        }
        self.get_data()
