from com.manageengine.monagent.kubernetes.Parser.PrometheusParserInterface import PrometheusParser


class KubeProxyMetricsParser(PrometheusParser):
    def __init__(self, kube_proxy_endpoint):
        super().__init__(kube_proxy_endpoint)
        self.parser_config = {
            'kubeproxy_sync_proxy_rules_duration_seconds': [
                {
                    'short_name': 'KPSPDS',
                    'sum': ['', 'KPSPDS', 'sum_only']
                }
            ],
            'rest_client_request_duration_seconds': [
                {
                    'short_name': 'KPRCRDS',
                    'group_name': 'request_duration_verb',
                    'labels': {
                        'verb': 'verb'
                    },
                    'group_labels': ['verb']
                }
            ],
            'rest_client_requests': [
                {
                    'short_name': 'KPRCRC',
                    'group_name': 'request_count_code',
                    'labels': {
                        'code': 'code'
                    },
                    'group_labels': ['code']
                },
                {
                    'short_name': 'KPRCRV',
                    'group_name': 'request_count_verb',
                    'labels': {
                        'verb': 'verb'
                    },
                    'group_labels': ['verb']
                },
            ]
        }
        self.get_data()
