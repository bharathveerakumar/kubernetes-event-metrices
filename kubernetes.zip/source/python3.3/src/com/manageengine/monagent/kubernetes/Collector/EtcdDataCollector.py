import traceback

from com.manageengine.monagent.kubernetes import KubeGlobal, KubeUtil
from com.manageengine.monagent.kubernetes.Logging import KubeLogger as AgentLogger
from com.manageengine.monagent.kubernetes.Collector.DataCollectorInterface import DataCollector
from com.manageengine.monagent.kubernetes.Parser.PrometheusParser.EtcdMetricsParser import EtcdMetrics

def exception_handler(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, "*** EXCEPTION *** => [EtcdDataCollector] => {} => {} => {} ******".format(func.__name__, e, traceback.format_exc()))
    return wrapper


class EtcdDataCollector(DataCollector):
    @exception_handler
    def __init__(self, dc_requisites_obj):
        super().__init__(dc_requisites_obj)
        self.etcd_config = {}
        self.etcd_config_id = KubeGlobal.kubeIds.get("KubeEtcd", {}) if KubeGlobal.kubeIds else {}

    @exception_handler
    def set_etcd_termination(self):
        for reg_instance_key, instance_config in self.etcd_config_id.items():
            if reg_instance_key not in self.final_json["KubeEtcd"]:
                self.final_json["KubeEtcd"][reg_instance_key] = instance_config
                self.final_json["KubeEtcd"][reg_instance_key]["deleted"] = "true"
                self.final_json["perf"] = "false"
                AgentLogger.log(AgentLogger.KUBERNETES, '*** INFO *** => Etcd Instance marked as deleted -> {} = {}'.format(reg_instance_key, instance_config))

    @exception_handler
    def init_etcd_dc(self):
        self.final_json["perf"] = "true"
        self.final_json["KubeEtcd"] = {}
        for etcd_instance in self.etcd_config:
            self.final_json["KubeEtcd"].update(getattr(EtcdMetrics(self.etcd_config[etcd_instance]), "final_data"))
            if self.etcd_config_id and etcd_instance in self.etcd_config_id:
                self.final_json["KubeEtcd"][etcd_instance]["id"] = self.etcd_config_id[etcd_instance]["id"]
            else:
                # dummy monitor flow will break here, since no data will be present in final_json
                if etcd_instance in self.final_json["KubeEtcd"]:
                    self.final_json["KubeEtcd"][etcd_instance]["id"] = ""
                    self.final_json["perf"] = "false"
        # extra metrics parsing, adding etcd instance ip:port as name in peers data, this can be only done here
        etcd_instance_id_mapper = {}
        for etcd_instance in self.final_json["KubeEtcd"]:
            etcd_instance_id_mapper[self.final_json["KubeEtcd"][etcd_instance]["ESI"] if "ESI" in self.final_json["KubeEtcd"][etcd_instance] else ""] = etcd_instance
        for etcd_instance in self.final_json["KubeEtcd"]:
            if "etcd_peers" in self.final_json["KubeEtcd"][etcd_instance]:
                for peer_id in self.final_json["KubeEtcd"][etcd_instance]["etcd_peers"]:
                    if peer_id in etcd_instance_id_mapper:
                        self.final_json["KubeEtcd"][etcd_instance]["etcd_peers"][peer_id]["host"] = etcd_instance_id_mapper[peer_id]


    @exception_handler
    def init_etcd_config(self):
        api_url = KubeGlobal.host+KubeGlobal.API_ENDPOINT_RES_NAME_MAP["KubeEtcd"]
        status, cp_node_data = KubeUtil.curl_api_with_token(api_url)

        if status == 200 and "items" in cp_node_data and cp_node_data["items"] and cp_node_data["items"][0]:
            cp_node = cp_node_data["items"][0]
            if "subsets" in cp_node and cp_node["subsets"][0]:
                endpoint_data = cp_node["subsets"][0]
                if "addresses" in endpoint_data and endpoint_data["addresses"] and "ports" in endpoint_data and endpoint_data["ports"][0]:
                    if endpoint_data["ports"][0]["name"] in ["https", "etcd"] and "port" in endpoint_data["ports"][0]:
                        port = endpoint_data["ports"][0]["port"]
                        for each_ip in endpoint_data["addresses"]:
                            self.etcd_config[str(each_ip["ip"])+":"+str(port)] = { "ip": each_ip["ip"], "port": str(port) }
                        AgentLogger.log(AgentLogger.KUBERNETES, '*** DATA *** => [Conf] Etcd Instance Present in Cluster')
                    else:
                        AgentLogger.log(AgentLogger.KUBERNETES, '*** INFO *** => Etcd Port data not fount -> {} = {}'.format("Etcd",endpoint_data))
                else:
                    AgentLogger.log(AgentLogger.KUBERNETES, '*** INFO *** => Etcd data not fount -> {} = {}'.format("Etcd",endpoint_data))
            else:
                AgentLogger.log(AgentLogger.KUBERNETES, '*** INFO *** => Etcd subset data not fount -> {} = {}'.format("Etcd",cp_node))
        AgentLogger.log(AgentLogger.KUBERNETES, '*** DATA *** => Etcd Components Data -> {}'.format(self.etcd_config))

    @exception_handler
    def collect_data(self):
        self.init_etcd_config()
        self.init_etcd_dc()
        self.set_etcd_termination()
        AgentLogger.debug(AgentLogger.KUBERNETES, '*** DEBUG *** => Etcd Collected Data -> \n{}\n'.format(self.final_json))
