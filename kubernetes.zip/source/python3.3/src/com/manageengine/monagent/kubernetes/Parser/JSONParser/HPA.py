import json
from com.manageengine.monagent.kubernetes.Parser.JSONParserInterface import JSONParser


class HPA(JSONParser):
    def __init__(self):
        super().__init__('HorizontalPodAutoscalers')

    def get_metadata(self):
        super().get_metadata()
        self.value_dict['An'] = json.dumps(self.get_2nd_path_value(['metadata', 'annotations'], {}))
        self.value_dict['Lb'] = json.dumps(self.get_2nd_path_value(['metadata', 'labels'], {}))
        self.value_dict['MLb'] = json.dumps(self.get_3rd_path_value(['spec', 'selector', 'matchLabels'], {}))
        self.value_dict['KHSMiR'] = self.get_2nd_path_value(['spec', 'minReplicas'])
        self.value_dict['KHSMaR'] = self.get_2nd_path_value(['spec', 'maxReplicas'])
        self.value_dict['TCPUUP'] = self.get_2nd_path_value(['spec', 'targetCPUUtilizationPercentage'])
        self.value_dict['Ki'] = self.get_3rd_path_value(['spec', 'scaleTargetRef', 'kind'])
        self.value_dict['SSCTNa'] = self.get_3rd_path_value(['spec', 'scaleTargetRef', 'name'])

    def get_perf_metrics(self):
        self.value_dict['LST'] = self.get_2nd_path_value(['status', 'lastScaleTime'])
        self.value_dict['KHSCR'] = self.get_2nd_path_value(['status', 'currentReplicas'])
        self.value_dict['DR'] = self.get_2nd_path_value(['status', 'desiredReplicas'])
        self.value_dict['CCPUUP'] = self.get_2nd_path_value(['status', 'currentCPUUtilizationPercentage'])
