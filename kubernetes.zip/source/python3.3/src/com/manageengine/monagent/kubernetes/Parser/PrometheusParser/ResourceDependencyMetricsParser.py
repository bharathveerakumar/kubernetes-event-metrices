from com.manageengine.monagent.kubernetes.Parser.PrometheusParserInterface import PrometheusParser
from com.manageengine.monagent.kubernetes import KubeGlobal

families = {
    'kube_pod_owner': ['Pod', ['pod', 'namespace'], None, {'owner_kind': 'kind', 'owner_name': 'owner_name', 'pod': 'name', 'namespace': 'namespace'}],
    'kube_pod_info': ['Node', ['pod', 'namespace'], None, {'node': 'node'}],
    'kube_pod_container_info': ['Containers', ['container', 'pod', 'namespace'], None, {'container': 'name', 'namespace': 'namespace', 'pod': 'pod_name'}],
    'kube_replicaset_owner': ['ReplicaSet', ['replicaset', 'namespace'], None, {'owner_name': 'owner_name', 'owner_kind': 'owner_kind', 'namespace': 'namespace'}]
}


class ResourceDependency(PrometheusParser):
    def __init__(self):
        super().__init__(KubeGlobal.kubeStateMetricsUrl + '/metrics')
        self.families = families
