from com.manageengine.monagent.kubernetes.Parser.StateMetricsParser import PrometheusParser
from com.manageengine.monagent.kubernetes import KubeGlobal

families = {
    'kube_pod_owner': ['Pod', ['pod', 'namespace'], None, {'owner_kind': 'kind', 'owner_name': 'owner_name'}],
    'kube_pod_info': ['Node', ['pod', 'namespace'], None, {'node': 'node'}],
    'kube_pod_container_info': ['Container', ['container', 'pod', 'namespace'], None, {'container': 'name', 'namespace': 'ns', 'pod': 'pod_name'}],
    'kube_replicaset_owner': ['ReplicaSet', ['replicaset', 'namespace'], None, {'owner_name': 'owner_name', 'owner_kind': 'owner_kind'}],
    'kube_ingress_path': ['Ingress', ['service_name', 'namespace'], None, {'ingress': 'ingress'}],
    'kube_horizontalpodautoscaler_info': ['HPA', ['scaletargetref_name', 'namespace'], None, {'scaletargetref_kind': 'child_kind', 'horizontalpodautoscaler': 'hpa'}]
}


class ResourceDependency(PrometheusParser):
    def __init__(self):
        super().__init__(KubeGlobal.kubeStateMetricsUrl + '/metrics')
        self.families = families
