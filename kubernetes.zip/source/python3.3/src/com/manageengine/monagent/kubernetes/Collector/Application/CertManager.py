from com.manageengine.monagent.kubernetes.Collector.DataCollectorInterface import DataCollector, DCRequisites
from com.manageengine.monagent.kubernetes.Collector.EventCollector import KubeUtil
from com.manageengine.monagent.kubernetes.Parser import ParserFactory


# class CertManager(DataCollector):
#     def collect_data(self):
#         self.final_json = ParserFactory.get_prometheus_parser('CertManager')()
#         self.final_json['Certificates'].update(
#             ParserFactory.get_json_parser('Certificates')().get_data()
#         )
#         self.final_json['Issuers'].update(
#             ParserFactory.get_json_parser('Issuers')().get_data()
#         )
#         self.final_json['ClusterIssuers'].update(
#             ParserFactory.get_json_parser('ClusterIssuers')().get_data()
#         )



final_json = ParserFactory.get_prometheus_parser('CertManager')().final_data
final_json['Certificates'] = KubeUtil.MergeDataDictionaries(
    ParserFactory.get_json_parser('Certificates')().get_data(),
    final_json['Certificates']
)
final_json['Issuers'] = ParserFactory.get_json_parser('Issuers')().get_data()
final_json['ClusterIssuers'] = ParserFactory.get_json_parser('ClusterIssuers')().get_data()

for key, value in final_json['Controllers'].items():
    if 'certificates' in key:
        final_json[key.replace('certificates-', '') + '_sync_call'] = value['sync_call_count']
    elif 'certificaterequests-' in key:
        final_json[key.replace('certificaterequests-', '') + '_sync_call'] = value['sync_call_count']
    else:
        final_json[key + '_sync_call'] = value['sync_call_count']

final_json.pop('Controllers', None)

print(final_json)
