import time
import traceback

from com.manageengine.monagent.kubernetes.Collector.PerfDataCollector import PerfDataCollector
from com.manageengine.monagent.kubernetes.Collector.ConfDataCollector import ConfDataCollector
from com.manageengine.monagent.kubernetes.Collector.EventCollector import EventCollector
from com.manageengine.monagent.kubernetes.Collector.ResourceDependency import ResourceDependency
from com.manageengine.monagent.kubernetes.Collector.ClusterMetricsAggregator import ClusterMetricsAggregator
from com.manageengine.monagent.kubernetes.Collector.GuidanceMetrics import GuidanceMetrics
from com.manageengine.monagent.kubernetes.Collector.DataCollector import DCRequisites
from com.manageengine.monagent.kubernetes import KubeGlobal, KubeUtil
from concurrent.futures import ThreadPoolExecutor, as_completed


DC_OBJ_LIST = []

@KubeUtil.pre_dc_init
def execute_tasks():
    global DC_OBJ_LIST
    KubeGlobal.DC_START_TIME = time.time()
    final_json = []

    try:
        with ThreadPoolExecutor(max_workers=2) as exe:
            futures = []
            for dc_prerequest in DC_OBJ_LIST:
                if KubeUtil.is_eligible_to_execute(dc_prerequest.dc_name, KubeGlobal.DC_START_TIME):
                    futures.append(
                        exe.submit(
                            dc_prerequest.dc_class(dc_prerequest).execute_dc_tasks
                        )
                    )

            for future in as_completed(futures):
                final_json.extend(future.result())
    except Exception:
        traceback.print_exc()
    return final_json

def create_perf_agent_dc_objs():
    global DC_OBJ_LIST
    DC_OBJ_LIST = []
    dc_requisites_obj = DCRequisites()
    dc_requisites_obj.set_dc_name(PerfDataCollector.__name__)
    dc_requisites_obj.set_termination_needed(True)
    dc_requisites_obj.set_dc_type_needed(True)
    dc_requisites_obj.set_child_write_count(int(KubeGlobal.childWriteCount))
    dc_requisites_obj.set_node_base_ksm_needed(True)
    dc_requisites_obj.set_servlet_name(KubeGlobal.KDR_SERVLET)
    dc_requisites_obj.set_split_data_required(True)
    dc_requisites_obj.set_id_mapping_needed(True)
    dc_requisites_obj.set_dc_class(PerfDataCollector)
    DC_OBJ_LIST.append(dc_requisites_obj)

def create_conf_agent_dc_objs():
    global DC_OBJ_LIST
    DC_OBJ_LIST = []
    dc_requisites_obj = DCRequisites()
    dc_requisites_obj.set_dc_name(PerfDataCollector.__name__)
    dc_requisites_obj.set_dc_type_needed(True)
    dc_requisites_obj.set_child_write_count(int(KubeGlobal.childWriteCount))
    dc_requisites_obj.set_servlet_name(KubeGlobal.KDR_SERVLET)
    dc_requisites_obj.set_split_data_required(True)
    dc_requisites_obj.set_id_mapping_needed(True)
    dc_requisites_obj.set_node_base_ksm_needed(True)
    dc_requisites_obj.set_dc_class(PerfDataCollector)
    DC_OBJ_LIST.append(dc_requisites_obj)

    dc_requisites_obj = DCRequisites()
    dc_requisites_obj.set_dc_name(ConfDataCollector.__name__)
    dc_requisites_obj.set_termination_needed(True)
    dc_requisites_obj.set_dc_type_needed(True)
    dc_requisites_obj.set_child_write_count(int(KubeGlobal.childWriteCount))
    dc_requisites_obj.set_servlet_name(KubeGlobal.KDR_SERVLET)
    dc_requisites_obj.set_split_data_required(True)
    dc_requisites_obj.set_id_mapping_needed(True)
    dc_requisites_obj.set_dc_class(ConfDataCollector)
    dc_requisites_obj.set_dependent_classes(get_conf_dependent_classes())
    DC_OBJ_LIST.append(dc_requisites_obj)

    dc_requisites_obj = DCRequisites()
    dc_requisites_obj.set_dc_name(EventCollector.__name__)
    dc_requisites_obj.set_child_write_count(int(KubeGlobal.eventsWriteCount))
    dc_requisites_obj.set_servlet_name(KubeGlobal.KDR_SERVLET)
    dc_requisites_obj.set_dc_class(EventCollector)
    dc_requisites_obj.set_split_data_required(True)
    DC_OBJ_LIST.append(dc_requisites_obj)

    dc_requisites_obj = DCRequisites()
    dc_requisites_obj.set_dc_name(ResourceDependency.__name__)
    dc_requisites_obj.set_child_write_count(1000)
    dc_requisites_obj.set_servlet_name(KubeGlobal.RD_SERVLET)
    dc_requisites_obj.set_dc_class(ResourceDependency)
    dc_requisites_obj.set_split_data_required(True)
    DC_OBJ_LIST.append(dc_requisites_obj)




def get_conf_dependent_classes():
    dc_list = []
    dc_requisites_obj = DCRequisites()
    dc_requisites_obj.set_dc_name(ClusterMetricsAggregator.__name__)
    dc_requisites_obj.set_node_base_ksm_needed(True)
    dc_requisites_obj.get_from_cluster_agent(True)
    dc_requisites_obj.set_dc_class(ClusterMetricsAggregator)
    dc_list.append(dc_requisites_obj)

    dc_requisites_obj = DCRequisites()
    dc_requisites_obj.set_dc_name(GuidanceMetrics.__name__)
    dc_requisites_obj.set_dc_class(GuidanceMetrics)
    dc_list.append(dc_requisites_obj)

    return dc_list

