import traceback
from abc import abstractmethod
from com.manageengine.monagent.kubernetes import KubeGlobal, KubeUtil


class Integrations:
    def __init__(self, task_name):
        self.integration_matching_key_name = None
        self.integration_config = None
        self.active_instances = {}
        self.instance_config = None
        self.display_name = None
        self.is_config_map_modified = True
        self.is_svc_exporter_supported = False
        self.task_name = task_name

    @abstractmethod
    def handle_integration(self):
        pass

    @abstractmethod
    def define_display_name(self, app_name):
        self.display_name = app_name + '_' + self.instance_config['host_name'] + '_' + self.instance_config['namespace']

    @abstractmethod
    def pre_action(self):
        pass

    @abstractmethod
    def post_action(self):
        pass

    def do_integration(self):
        try:
            self.is_config_map_modified = KubeGlobal.CONFIGMAP_INTEG_DATA.get('rv', 0) != KubeGlobal.CONFIGMAP_RESOURCE_VERSION

            for app_name, integration_config in KubeGlobal.CONFIGMAP_INTEG_DATA.get('config', {}).items():
                self.integration_config = integration_config
                self.is_svc_exporter_supported = True if "SVC_NAME" in self.integration_config and KubeUtil.is_conf_agent() else False

                if self.is_eligible_config():
                    if self.is_svc_exporter_supported:
                        self.handle_svc_flow(app_name)
                        continue

                    matching_pod_list = self.get_matching_pod_list()

                    if matching_pod_list:
                        self.pre_action()

                        for pod_value in matching_pod_list:
                            # pod info
                            self.instance_config = {
                                'host': pod_value['status']['podIP'],
                                'host_name': pod_value['metadata']['name'],
                                'namespace': pod_value['metadata']['namespace']
                            }
                            self.define_display_name(app_name)
                            self.active_instances[self.display_name] = 1
                            self.handle_integration()

                        self.post_action()
        except Exception:
            traceback.print_exc()

    def is_eligible_config(self):
        for matching_keys in self.integration_matching_key_name:
            if matching_keys not in self.integration_config:
                return False
        return True

    def handle_svc_flow(self, app_name):
        self.pre_action()
        self.instance_config = {
            'host': self.integration_config['SVC_NAME'] + '.' + self.integration_config['NAMESPACE'],
            'host_name': self.integration_config['SVC_NAME'],
            'namespace': self.integration_config['NAMESPACE']
        }
        self.define_display_name(app_name)
        self.active_instances[self.display_name] = 1
        self.handle_integration()
        self.post_action()

    def get_matching_pod_list(self):
        pod_list = []
        try:
            namespace = self.integration_config["NAMESPACE"]
            matching_labels = self.integration_config.get("LABELS_TO_SELECT_PODS")
            pod_name = self.integration_config.get("POD_NAME")
            for pod in KubeGlobal.NODE_BASE_PODS_CONFIGS['items']:
                if pod['metadata']['namespace'] != namespace:
                    continue

                if matching_labels:
                    pod_lbls = pod['metadata'].get("labels", {})
                    is_matched = True
                    for lb_key, lb_value in matching_labels.items():
                        if lb_key not in pod_lbls or lb_value != pod_lbls[lb_key]:
                            is_matched = False
                            break

                    if not is_matched:
                        continue
                elif pod_name != pod['metadata']['name']:
                    continue

                pod_list.append(pod)
        except Exception:
            traceback.print_exc()
        return pod_list
