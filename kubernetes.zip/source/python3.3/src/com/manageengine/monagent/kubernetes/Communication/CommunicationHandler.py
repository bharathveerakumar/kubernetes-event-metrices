import os
import traceback
import requests
from com.manageengine.monagent.kubernetes import KubeGlobal
from com.manageengine.monagent.kubernetes.Logging import KubeLogger

def send_request(method='GET', path='', payload=None, headers=None, params=None):
    try:
        # add default request params
        params.update({
            'bno': KubeGlobal.AGENT_BNO_VERSION,
            'CUSTOMERID': KubeGlobal.CUSTOMER_ID,
            'AGENTKEY': KubeGlobal.AGENT_KEY,
        })
        response = requests.request(method=method, url=set_plus_server_url(path), data=payload, headers=headers, params=params)
        response.raise_for_status()  # Raise an error for bad responses (4xx and 5xx)
        KubeLogger.log(KubeLogger.KUBERNETES, "Agent Communication ::: Request {}, URL: {}, Headers: {}, Params: {}".format(method, path, headers, params))
        if 'Content-Type' in response.headers and 'text/json' in response.headers['Content-Type'] or 'application/json' in response.headers['Content-Type']:
            return response.json()
        else:
            return response.text
    except requests.RequestException as e:
        KubeLogger.log(KubeLogger.KUBERNETES, "Agent Communication ::: Request failed: {}, {}".format(e.__str__(), traceback.format_exc()))
    except Exception as e:
        traceback.print_exc()

def set_plus_server_url(path):
    return KubeGlobal.SERVER_PROTOCOL + '://' + KubeGlobal.SERVER_NAME + ':' + str(KubeGlobal.SERVER_PORT) + path
