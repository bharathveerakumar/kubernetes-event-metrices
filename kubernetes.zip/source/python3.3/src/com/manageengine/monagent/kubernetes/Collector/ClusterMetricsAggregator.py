'''
@author: bharath.veerakumar

Created on Feb 20 2023
'''


from com.manageengine.monagent.kubernetes.Logging import KubeLogger as AgentLogger
from com.manageengine.monagent.kubernetes import KubeUtil
from com.manageengine.monagent.kubernetes import KubeGlobal
from com.manageengine.monagent.kubernetes.ClusterAgent import ClusterAgentUtil
from com.manageengine.monagent.kubernetes.Collector.DataCollectorInterface import DataCollector
import traceback
import json
import math
import time
from concurrent.futures import ThreadPoolExecutor


class ClusterMetricsAggregator(DataCollector):
    def __init__(self, dc_requisites_obj):
        super().__init__(dc_requisites_obj)

        self.cluster_aggregated_metrics = {
            'totalCoresUse': 0,
            'totalCapaCores': 0,
            'cpuAllocatable': 0,
            'totalMemUse': 0,
            'memCapacity': 0,
            'memAllocatable': 0,
            'avaiStorage': 0,
            'usedStorage': 0,
            'podsAllocatable': 0,
            'podsScheduled': 0,
            "KCCR": 0,
            "KCMR": 0
        }
        if not self.dc_requisites_obj.workloads_aggregation_needed:
            self.final_json = {
                "kubernetes": {}
            }
        else:
            self.final_json = {
                "PersistentVolumeClaim": {},
                "DaemonSets": {},
                "Deployments": {},
                "StatefulSets": {},
                "ReplicaSets": {},
                "kubernetes": {},
                "Namespaces": {},
                "Services": {}
            }

    def collect_data(self):
        try:
            self.ksm_data = ClusterAgentUtil.get_ca_parsed_data("npc_ksm")
            self.execute_metrics_aggregator_tasks()
            AgentLogger.log(AgentLogger.KUBERNETES, "***** Executed CMA Task in Conf Agent *****")
        except Exception:
            traceback.print_exc()

    def get_data_for_cluster_agent(self):
        self.ksm_data = ClusterAgentUtil.get_parsed_data_for_ca("npc_ksm")
        self.execute_metrics_aggregator_tasks()
        return self.final_json

    def execute_metrics_aggregator_tasks(self):
        try:
            dc_start_time = time.time()
            service_selectors = {}

            thread_count = math.ceil(len(self.ksm_data["Nodes"]) / 10)
            AgentLogger.log(AgentLogger.KUBERNETES, "Maximum Threads to be allocated for CMA task {}".format(thread_count))
            KubeUtil.get_api_data_by_limit(KubeGlobal.apiEndpoint + '/api/v1/services?limit=500', self.hash_service_selectors, service_selectors)

            with ThreadPoolExecutor(max_workers = thread_count) as exe:
                for node_name in self.ksm_data["Nodes"]:
                    exe.submit(self.aggregate_metrics, node_name, service_selectors)

            self.aggregate_deployment_perf_values()
            self.calculate_cluster_capacity()
            self.final_json["kubernetes"]["CMA_DC_TIME"] = time.time() - dc_start_time
            AgentLogger.log(AgentLogger.KUBERNETES, "## DCTIME for CMA {}".format(self.final_json['kubernetes']["CMA_DC_TIME"]))
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> execute_metrics_aggregator_tasks -> {}".format(e))
            traceback.print_exc()

    def aggregate_metrics(self, node_name, service_selectors):
        try:
            kubelet_data = self.get_kubelet_data(node_name)
            self.aggregate_cluster_metrics(kubelet_data["node"], self.ksm_data["Nodes"][node_name])

            if self.dc_requisites_obj.workloads_aggregation_needed:
                self.aggregate_workload_metrics(kubelet_data["pods"], self.ksm_data["Pods"], service_selectors)
                return

            # no need to call this method if aggregate_workload_metrics method has been called
            self.calculate_reserved_metrics()
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> aggregate_metrics -> {}".format(e))
            traceback.print_exc()

    def aggregate_cluster_metrics(self, node_data, kube_state_data):
        try:
            # cpu
            if "cpu" in node_data  and "usageNanoCores" in node_data["cpu"]:
                self.cluster_aggregated_metrics['totalCoresUse'] += float(node_data["cpu"]["usageNanoCores"]) / 1000000000
            if "KNSCCC" in kube_state_data and kube_state_data["KNSCCC"] and len(str(kube_state_data["KNSCCC"])) > 0:
                self.cluster_aggregated_metrics['totalCapaCores'] += float(kube_state_data["KNSCCC"])
            if "KNSACC" in kube_state_data and kube_state_data["KNSACC"] and len(str(kube_state_data["KNSACC"])) > 0:
                self.cluster_aggregated_metrics['cpuAllocatable'] += float(kube_state_data["KNSACC"])

            # mem
            if "memory" in node_data and "workingSetBytes" in node_data["memory"]:
                self.cluster_aggregated_metrics['totalMemUse'] += float(node_data["memory"]["workingSetBytes"]) / 1073741824
            if "KNSCMB" in kube_state_data and kube_state_data["KNSCMB"] and len(str(kube_state_data["KNSCMB"])) > 0:
                self.cluster_aggregated_metrics['memCapacity'] += float(kube_state_data["KNSCMB"]) / 1073741824
            if "KNSAMB" in kube_state_data and kube_state_data["KNSAMB"] and len(str(kube_state_data["KNSAMB"])) > 0:
                self.cluster_aggregated_metrics['memAllocatable'] += float(kube_state_data["KNSAMB"]) / 1073741824

            # disk
            if "fs" in node_data:
                if "capacityBytes" in node_data["fs"]:
                    self.cluster_aggregated_metrics['avaiStorage'] += float(node_data["fs"]["capacityBytes"]) / 1073741824
                if "usedBytes" in node_data["fs"]:
                    self.cluster_aggregated_metrics['usedStorage'] += float(node_data["fs"]["usedBytes"]) / 1073741824

            # pods
            if "KNSAP" in kube_state_data and kube_state_data["KNSAP"] and len(str(kube_state_data["KNSAP"])) > 0:
                self.cluster_aggregated_metrics['podsAllocatable'] += float(kube_state_data["KNSAP"])
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> aggregate_cluster_metrics -> {}".format(e))
            traceback.print_exc()

    def calculate_reserved_metrics(self):
        for pod_state_data in self.ksm_data["Pods"]:
            self.cluster_aggregated_metrics["KCCR"] += ((float(pod_state_data["PRMB"]) if "PRMB" in pod_state_data else 0) / 1000)
            self.cluster_aggregated_metrics["KCMR"] += ((float(pod_state_data["PRRCC"]) if "PRRCC" in pod_state_data else 0) / 1024)

    def aggregate_workload_metrics(self, pods_data, kube_state_data, service_selectors):
        try:
            for pod in pods_data:
                try:
                    perf_value_dict = {}
                    namespace = pod["podRef"]["namespace"]
                    pod_name = pod["podRef"]["name"] + "_" + namespace
                    service_name = service_selectors.get(pod_name)
                    pod_state_data = kube_state_data[pod_name]

                    perf_value_dict['cpu_used'] = float(pod["cpu"]["usageNanoCores"]) / 1000000     if "cpu" in pod and "usageNanoCores" in pod["cpu"] else 0
                    perf_value_dict['mem_used'] = float(pod["memory"]["workingSetBytes"]) / 1048576 if "memory" in pod and "workingSetBytes" in pod["memory"] else 0
                    perf_value_dict['rss_mem_used'] = float(pod["memory"]["rssBytes"]) / 1048576    if "memory" in pod and "rssBytes" in pod["memory"] else 0
                    perf_value_dict['mem_req'] = float(pod_state_data["PRMB"])                      if "PRMB" in pod_state_data else 0
                    perf_value_dict['cpu_req'] = float(pod_state_data["PRRCC"])                     if "PRRCC" in pod_state_data else 0
                    perf_value_dict['mem_limit'] = float(pod_state_data["PRLMB"])                   if "PRLMB" in pod_state_data else 0
                    perf_value_dict['cpu_limit'] = float(pod_state_data["PRLCC"]) * 1000            if "PRLCC" in pod_state_data else 0
                    perf_value_dict['rx'] = KubeUtil.get_counter_value(pod_name+"_CMA_RX", float(pod["network"]["rxBytes"]) / 1024, True) if "network" in pod and "rxBytes" in pod["network"] else 0
                    perf_value_dict['tx'] = KubeUtil.get_counter_value(pod_name+"_CMA_TX", float(pod["network"]["txBytes"]) / 1024, True) if "network" in pod and "txBytes" in pod["network"] else 0

                    self.cluster_aggregated_metrics["KCCR"] += (perf_value_dict['cpu_req'] / 1000)
                    self.cluster_aggregated_metrics["KCMR"] += (perf_value_dict['mem_req'] / 1024)

                    self.aggregate_perf_values_to_owner_dict('Namespaces', namespace, perf_value_dict)

                    if service_name:
                        self.aggregate_perf_values_to_owner_dict('Services', service_name, perf_value_dict)

                    if pod_state_data["owner_kind"] in ['DaemonSet', 'ReplicaSet', 'StatefulSet']:
                        owner_kind = pod_state_data["owner_kind"] + "s"   # Appending 's' for merging the FINAL_METRICS_DICT & FINAL_DATA of ConfDataCollector
                        owner_name = pod_state_data["owner_name"] + "_" + namespace
                        self.aggregate_perf_values_to_owner_dict(owner_kind, owner_name, perf_value_dict)

                    self.get_pvc_utilization_metric(pod.get("volume", []))
                except Exception:
                    traceback.print_exc()
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> aggregate_workload_metrics -> {}".format(e))
            traceback.print_exc()

    def get_pvc_utilization_metric(self, volume_list):
        for volume in volume_list:
            if "pvcRef" in volume:
                pvc_name = volume["pvcRef"]["name"] + "_" + volume["pvcRef"]["namespace"]
                self.final_json["PersistentVolumeClaim"][pvc_name] = {
                    "used": volume["usedBytes"],
                    "available": volume["availableBytes"],
                    "capacity": volume["capacityBytes"],
                    "used_perc": volume['usedBytes'] / volume["capacityBytes"] * 100
                }

    def calculate_cluster_capacity(self):
        try:
            self.final_json['kubernetes']["cpu_used"] = self.cluster_aggregated_metrics['totalCoresUse']
            self.final_json['kubernetes']["cpu_capacity"] = self.cluster_aggregated_metrics['totalCapaCores']
            self.final_json['kubernetes']["cpu_allocatable"] = self.cluster_aggregated_metrics['cpuAllocatable']
            self.final_json['kubernetes']["cpu_reserved"] = self.cluster_aggregated_metrics["KCCR"]

            self.final_json['kubernetes']["mem_used"] = self.cluster_aggregated_metrics['totalMemUse']
            self.final_json['kubernetes']["mem_capacity"] = self.cluster_aggregated_metrics['memCapacity']
            self.final_json['kubernetes']["mem_allocatable"] = self.cluster_aggregated_metrics['memAllocatable']
            self.final_json['kubernetes']["mem_reserved"] = self.cluster_aggregated_metrics["KCMR"]

            self.final_json['kubernetes']["disk_used"] = self.cluster_aggregated_metrics['usedStorage']
            self.final_json['kubernetes']["disk_capacity"] = self.cluster_aggregated_metrics['avaiStorage']

            self.final_json['kubernetes']["pods_perc"] = (KubeUtil.get_count_metric(KubeGlobal.apiEndpoint + KubeGlobal.API_ENDPOINT_RES_NAME_MAP['Pods'] + '?limit=1') / self.cluster_aggregated_metrics['podsAllocatable']) * 100

            self.final_json['kubernetes']["cpu_perc"] = (self.final_json['kubernetes']["cpu_used"] / self.final_json['kubernetes']["cpu_capacity"]) * 100
            self.final_json['kubernetes']["mem_perc"] = (self.final_json['kubernetes']["mem_used"] / self.final_json['kubernetes']["mem_capacity"]) * 100
            self.final_json['kubernetes']["disk_perc"] = (self.cluster_aggregated_metrics['usedStorage'] / self.cluster_aggregated_metrics['avaiStorage']) * 100
            self.final_json['kubernetes']["res_cpu_perc"] = (self.final_json['kubernetes']["cpu_reserved"] / self.final_json['kubernetes']["cpu_allocatable"]) * 100
            self.final_json['kubernetes']["res_mem_perc"] = (self.final_json['kubernetes']["mem_reserved"] / self.final_json['kubernetes']["mem_allocatable"]) * 100

            AgentLogger.log(AgentLogger.KUBERNETES, "cluster metrics {}".format(json.dumps(self.final_json)))
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> calculate_cluster_capacity -> {}".format(e))
            traceback.print_exc()

    def hash_service_selectors(self, service_data, lookup_dict):
        try:
            for val in service_data['items']:
                try:
                    name = val['metadata']['name']
                    ns = val['metadata']['namespace']
                    svc_name = name + "_" + ns
                    sel = val['spec']['selector']
                    match_labels = []
                    for key, value in sel.items():
                        match_labels.append("{}%3D{}".format(key, value))

                    status, api_resp = KubeUtil.curl_api_with_token(KubeGlobal.apiEndpoint + "/api/v1/namespaces/{}/pods?labelSelector={}".format(ns, ",".join(match_labels)))
                    if status == 200:
                        for pod_value in api_resp.get("items", []):
                            lookup_dict[pod_value['metadata']['name'] + "_" + ns] = svc_name
                except Exception:
                    continue
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> hash_service_selectors -> {}".format(e))

    def aggregate_deployment_perf_values(self):
        self.final_json["Deployments"] = {}
        for rs_name, rs_value in self.final_json.get("ReplicaSets", {}).items():
            deploy_name = KubeUtil.find_replicaset_owner(rs_name)
            if deploy_name:
                self.final_json["Deployments"][deploy_name] = rs_value
        self.final_json.pop("ReplicaSets", None)

    def aggregate_perf_values_to_owner_dict(self, owner_kind, owner_name, perf_value_dict):
        try:
            if owner_name not in self.final_json[owner_kind]:
                self.init_final_dict_for_workloads(owner_kind, owner_name)
            self.add_perf_values_to_dict(owner_kind, owner_name, self.final_json, perf_value_dict)
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> aggregate_ns_perf_values -> {}".format(e))
            traceback.print_exc()

    def init_final_dict_for_workloads(self, owner_kind, owner_name):
        self.final_json[owner_kind][owner_name] = {
             'cpu_used': 0,
             'mem_used': 0,
             'rss_mem_used': 0,
             'cpu_req': 0,
             'mem_req': 0,
             'cpu_limit': 0,
             'mem_limit': 0,
             'rx': 0,
             'tx': 0
        }

    def get_kubelet_data(self, node_name):
        try:
            status, json = KubeUtil.curl_api_with_token(KubeGlobal.apiEndpoint + '/api/v1/nodes/{}/proxy/stats/summary'.format(node_name))
            if status == 200:
                return json
            status, json = KubeUtil.curl_api_with_token('https://{}:10250/stats/summary'.format(node_name))
            return json
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> get_kubelet_data -> {}".format(e))
            traceback.print_exc()

    def add_perf_values_to_dict(self, owner_kind, owner_name, metric_dict, perf_values):
        try:
            owner_dict = metric_dict[owner_kind][owner_name]
            owner_dict["cpu_used"] += perf_values['cpu_used']
            owner_dict["mem_used"] += perf_values['mem_used']
            owner_dict["rss_mem_used"] += perf_values['rss_mem_used']
            owner_dict["mem_req"] += perf_values['mem_req']
            owner_dict["cpu_req"] += perf_values['cpu_req']
            owner_dict["cpu_limit"] += perf_values['cpu_limit']
            owner_dict["mem_limit"] += perf_values['mem_limit']
            owner_dict["rx"] += perf_values['rx']
            owner_dict["tx"] += perf_values['tx']
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> add_perf_values_to_dict -> {}".format(e))
            traceback.print_exc()