from com.manageengine.monagent.kubernetes.Logging import KubeLogger as AgentLogger
from com.manageengine.monagent.kubernetes import KubeUtil
from com.manageengine.monagent.kubernetes.KubeUtil import exception_handler
from com.manageengine.monagent.kubernetes import KubeGlobal
import traceback
import json
import math
import time
from concurrent.futures import ThreadPoolExecutor

AGGREGATED_METRICS = {}
FINAL_METRIC_DICT = {}

@exception_handler
def get_metrics_aggregation_data(npc_ksm_data):
    global FINAL_METRIC_DICT
    if KubeGlobal.CLUSTER_AGENT_SVC:
        bef_req = time.time()
        status, cma_data = KubeUtil.curl_api_with_token(KubeGlobal.CLUSTER_AGENT_SVC + '/pd/cma')
        AgentLogger.log(AgentLogger.KUBERNETES, "********* Cluster agent responded in {} for CMA *********\n".format(time.time() - bef_req))
        if status == 200:
            AgentLogger.log(AgentLogger.KUBERNETES, "******* CMA metrics fetched from cluster agent *******")
            FINAL_METRIC_DICT = cma_data
            return
    AgentLogger.log(AgentLogger.KUBERNETES, "******** Cluster Agent not Ready *********")
    execute_metrics_aggregator_tasks(npc_ksm_data)
    AgentLogger.log(AgentLogger.KUBERNETES, "***** Executed CMA Task in Conf Agent *****")

def execute_metrics_aggregator_tasks(npc_ksm_data):
    global FINAL_METRIC_DICT
    try:
        pod_config_list = {}
        service_selectors = {}

        init_aggregate_keys()
        dc_start_time = time.time()
        thread_count = math.ceil(len(npc_ksm_data["Nodes"]) / 10)
        AgentLogger.log(AgentLogger.KUBERNETES, "Maximum Threads to be allocated for CMA task {}".format(thread_count))
        KubeUtil.get_api_data_by_limit(KubeGlobal.apiEndpoint + '/api/v1/services?limit=500', hash_service_selectors, service_selectors)
        KubeUtil.get_api_data_by_limit(KubeGlobal.apiEndpoint + '/api/v1/pods?limit=500', KubeUtil.filter_labels_to_constructed_dict, pod_config_list)

        with ThreadPoolExecutor(max_workers = thread_count) as exe:
            for node_name in npc_ksm_data["Nodes"]:
                exe.submit(aggregate_metrics, node_name, npc_ksm_data, pod_config_list, service_selectors)

        calculate_cluster_capacity()
        FINAL_METRIC_DICT["kubernetes"]["CMA_DC_TIME"] = time.time() - dc_start_time
        AgentLogger.log(AgentLogger.KUBERNETES, "## DCTIME for CMA {}".format(FINAL_METRIC_DICT['kubernetes']["CMA_DC_TIME"]))
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> execute_metrics_aggregator_tasks -> {}".format(e))
        traceback.print_exc()

def aggregate_metrics(node_name, npc_ksm_data, pod_config_list, service_selectors):
    try:
        kubelet_data = get_kubelet_data(node_name)
        aggregate_cluster_metrics(kubelet_data["node"], npc_ksm_data["Nodes"][node_name])
        aggregate_workload_metrics(kubelet_data["pods"], npc_ksm_data["Pods"], pod_config_list, service_selectors)
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> aggregate_metrics -> {}".format(e))
        traceback.print_exc()

def aggregate_cluster_metrics(node_data, kube_state_data):
    global AGGREGATED_METRICS
    try:
        # cpu
        if "cpu" in node_data  and "usageNanoCores" in node_data["cpu"]:
            AGGREGATED_METRICS['totalCoresUse'] += float(node_data["cpu"]["usageNanoCores"]) / 1000000000
        if "KNSCCC" in kube_state_data and kube_state_data["KNSCCC"] and len(str(kube_state_data["KNSCCC"])) > 0:
            AGGREGATED_METRICS['totalCapaCores'] += float(kube_state_data["KNSCCC"])
        if "KNSACC" in kube_state_data and kube_state_data["KNSACC"] and len(str(kube_state_data["KNSACC"])) > 0:
            AGGREGATED_METRICS['cpuAllocatable'] += float(kube_state_data["KNSACC"])

        # mem
        if "memory" in node_data and "workingSetBytes" in node_data["memory"]:
            AGGREGATED_METRICS['totalMemUse'] += float(node_data["memory"]["workingSetBytes"]) / 1073741824
        if "KNSCMB" in kube_state_data and kube_state_data["KNSCMB"] and len(str(kube_state_data["KNSCMB"])) > 0:
            AGGREGATED_METRICS['memCapacity'] += float(kube_state_data["KNSCMB"]) / 1073741824
        if "KNSAMB" in kube_state_data and kube_state_data["KNSAMB"] and len(str(kube_state_data["KNSAMB"])) > 0:
            AGGREGATED_METRICS['memAllocatable'] += float(kube_state_data["KNSAMB"]) / 1073741824

        # disk
        if "fs" in node_data:
            if "capacityBytes" in node_data["fs"]:
                AGGREGATED_METRICS['avaiStorage'] += float(node_data["fs"]["capacityBytes"]) / 1073741824
            if "usedBytes" in node_data["fs"]:
                AGGREGATED_METRICS['usedStorage'] += float(node_data["fs"]["usedBytes"]) / 1073741824

        # pods
        if "KNSAP" in kube_state_data and kube_state_data["KNSAP"] and len(str(kube_state_data["KNSAP"])) > 0:
            AGGREGATED_METRICS['podsAllocatable'] += float(kube_state_data["KNSAP"])
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> aggregate_cluster_metrics -> {}".format(e))
        traceback.print_exc()

def aggregate_workload_metrics(pods_data, kube_state_data, pod_config_list, service_selectors):
    global AGGREGATED_METRICS, FINAL_METRIC_DICT
    try:
        AGGREGATED_METRICS['podsScheduled'] += len(pods_data)
        for pod in pods_data:
            try:
                perf_value_dict = {}
                namespace = pod["podRef"]["namespace"]
                pod_name = pod["podRef"]["name"] + "_" + namespace
                service_name = KubeUtil.get_pod_service_map(pod_name, pod_config_list, service_selectors)
                pod_state_data = kube_state_data[pod_name]

                perf_value_dict['cpu_used'] = float(pod["cpu"]["usageNanoCores"]) / 1000000     if "cpu" in pod and "usageNanoCores" in pod["cpu"] else 0
                perf_value_dict['mem_used'] = float(pod["memory"]["workingSetBytes"]) / 1048576 if "memory" in pod and "workingSetBytes" in pod["memory"] else 0
                perf_value_dict['rss_mem_used'] = float(pod["memory"]["rssBytes"]) / 1048576    if "memory" in pod and "rssBytes" in pod["memory"] else 0
                perf_value_dict['mem_req'] = float(pod_state_data["PRMB"])                      if "PRMB" in pod_state_data else 0
                perf_value_dict['cpu_req'] = float(pod_state_data["PRRCC"])                     if "PRRCC" in pod_state_data else 0
                perf_value_dict['mem_limit'] = float(pod_state_data["PRLMB"])                   if "PRLMB" in pod_state_data else 0
                perf_value_dict['cpu_limit'] = float(pod_state_data["PRLCC"]) * 1000            if "PRLCC" in pod_state_data else 0
                perf_value_dict['rx'] = KubeUtil.get_counter_value(pod_name+"_CMA_RX", float(pod["network"]["rxBytes"]) / 1024, True) if "network" in pod and "rxBytes" in pod["network"] else 0
                perf_value_dict['tx'] = KubeUtil.get_counter_value(pod_name+"_CMA_TX", float(pod["network"]["txBytes"]) / 1024, True) if "network" in pod and "txBytes" in pod["network"] else 0

                AGGREGATED_METRICS["KCCR"] += (perf_value_dict['cpu_req'] / 1000)
                AGGREGATED_METRICS["KCMR"] += (perf_value_dict['mem_req'] / 1024)

                aggregate_perf_values_to_owner_dict('Namespaces', namespace, perf_value_dict)

                if service_name:
                    aggregate_perf_values_to_owner_dict('Services', service_name, perf_value_dict)

                if pod_state_data["owner_kind"] in ['DaemonSet', 'ReplicaSet', 'StatefulSet']:
                    owner_kind = pod_state_data["owner_kind"] + "s"   # Appending 's' for merging the FINAL_METRICS_DICT & FINAL_DATA of ConfDataCollector
                    owner_name = pod_state_data["owner_name"] + "_" + namespace
                    aggregate_perf_values_to_owner_dict(owner_kind, owner_name, perf_value_dict)
            except Exception as e:
                traceback.print_exc()
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> aggregate_workload_metrics -> {}".format(e))
        traceback.print_exc()

def calculate_cluster_capacity():
    global AGGREGATED_METRICS, FINAL_METRIC_DICT
    FINAL_METRIC_DICT['kubernetes'] = {}
    kube_dict = FINAL_METRIC_DICT['kubernetes']
    try:
        kube_dict["cpu_used"] = AGGREGATED_METRICS['totalCoresUse']
        kube_dict["cpu_capacity"] = AGGREGATED_METRICS['totalCapaCores']
        kube_dict["cpu_allocatable"] = AGGREGATED_METRICS['cpuAllocatable']
        kube_dict["cpu_reserved"] = AGGREGATED_METRICS["KCCR"]

        kube_dict["mem_used"] = AGGREGATED_METRICS['totalMemUse']
        kube_dict["mem_capacity"] = AGGREGATED_METRICS['memCapacity']
        kube_dict["mem_allocatable"] = AGGREGATED_METRICS['memAllocatable']
        kube_dict["mem_reserved"] = AGGREGATED_METRICS["KCMR"]

        kube_dict["disk_used"] = AGGREGATED_METRICS['usedStorage']
        kube_dict["disk_capacity"] = AGGREGATED_METRICS['avaiStorage']

        kube_dict["pods_perc"] = (AGGREGATED_METRICS['podsScheduled'] / AGGREGATED_METRICS['podsAllocatable']) * 100

        kube_dict["cpu_perc"] = (kube_dict["cpu_used"] / kube_dict["cpu_capacity"]) * 100
        kube_dict["mem_perc"] = (kube_dict["mem_used"] / kube_dict["mem_capacity"]) * 100
        kube_dict["disk_perc"] = (AGGREGATED_METRICS['usedStorage'] / AGGREGATED_METRICS['avaiStorage']) * 100
        kube_dict["res_cpu_perc"] = (kube_dict["cpu_reserved"] / kube_dict["cpu_allocatable"]) * 100
        kube_dict["res_mem_perc"] = (kube_dict["mem_reserved"] / kube_dict["mem_allocatable"]) * 100

        AgentLogger.log(AgentLogger.KUBERNETES, "cluster metrics {}".format(json.dumps(kube_dict)))
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> calculate_cluster_capacity -> {}".format(e))
        traceback.print_exc()

def hash_service_selectors(service_data, lookup_dict):
    try:
        for val in service_data['items']:
            try:
                name = val['metadata']['name']
                ns = val['metadata']['namespace']
                sel = val['spec']['selector']
                for sel_key, sel_val in sel.items():
                    hash_key = sel_key+'@'+sel_val+'@'+ns
                    lookup_dict[hash_key] = name +"_"+ ns
            except Exception:
                continue
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> hash_service_selectors -> {}".format(e))

def init_aggregate_keys():
    global AGGREGATED_METRICS

    AGGREGATED_METRICS['totalCoresUse'] = 0
    AGGREGATED_METRICS['totalCapaCores'] = 0
    AGGREGATED_METRICS['cpuAllocatable'] = 0
    AGGREGATED_METRICS['totalMemUse'] = 0
    AGGREGATED_METRICS['memCapacity'] = 0
    AGGREGATED_METRICS['memAllocatable'] = 0
    AGGREGATED_METRICS['avaiStorage'] = 0
    AGGREGATED_METRICS['usedStorage'] = 0
    AGGREGATED_METRICS['podsAllocatable'] = 0
    AGGREGATED_METRICS['podsScheduled'] = 0
    AGGREGATED_METRICS["KCCR"] = 0
    AGGREGATED_METRICS["KCMR"] = 0

def aggregate_replicaset_perf_values(final_data):
    check_list = {}
    try:
        rs_data = final_data.get("ReplicaSets", {})
        deploy_list = final_data.get("Deployments", {})
        for rs_name, rs_value in rs_data.items():
            deploy_name = rs_value.get("owner_name", "") +"_"+ rs_value.get("NS", "")
            if not check_list.get(deploy_name):
                deploy_dict = deploy_list.get(deploy_name, {})
                for metric in ['cpu_used', 'mem_used', 'rss_mem_used', 'mem_req', 'cpu_req', 'cpu_limit', 'mem_limit', 'rx', 'tx']:
                    deploy_dict[metric] = 0
                check_list[deploy_name] = 1
            add_perf_values_to_dict('Deployments', deploy_name, final_data, rs_value)
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> aggregate_replicaset_perf_values -> {}".format(e))
        traceback.print_exc()

def aggregate_perf_values_to_owner_dict(owner_kind, owner_name, perf_value_dict):
    try:
        global FINAL_METRIC_DICT
        if owner_kind not in FINAL_METRIC_DICT or owner_name not in FINAL_METRIC_DICT[owner_kind]:
            init_final_dict_for_workloads(owner_kind, owner_name)
        add_perf_values_to_dict(owner_kind, owner_name, FINAL_METRIC_DICT, perf_value_dict)
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> aggregate_ns_perf_values -> {}".format(e))
        traceback.print_exc()

def init_final_dict_for_workloads(owner_kind, owner_name):
    global FINAL_METRIC_DICT
    FINAL_METRIC_DICT[owner_kind] = {} if owner_kind not in FINAL_METRIC_DICT else FINAL_METRIC_DICT[owner_kind]
    FINAL_METRIC_DICT[owner_kind][owner_name] = {
         'cpu_used': 0,
         'mem_used': 0,
         'rss_mem_used': 0,
         'cpu_req': 0,
         'mem_req': 0,
         'cpu_limit': 0,
         'mem_limit': 0,
         'rx': 0,
         'tx': 0
    }

def get_kubelet_data(node_name):
    try:
        status, json = KubeUtil.curl_api_with_token(KubeGlobal.apiEndpoint + '/api/v1/nodes/{}/proxy/stats/summary'.format(node_name))
        if status == 200:
            return json
        status, json = KubeUtil.curl_api_with_token('https://{}:10250/stats/summary'.format(node_name))
        return json
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> get_kubelet_data -> {}".format(e))
        traceback.print_exc()

def add_perf_values_to_dict(owner_kind, owner_name, metric_dict, perf_values):
    try:
        owner_dict = metric_dict[owner_kind][owner_name]
        owner_dict["cpu_used"] += perf_values.get('cpu_used', 0)
        owner_dict["mem_used"] += perf_values.get('mem_used', 0)
        owner_dict["rss_mem_used"] += perf_values.get('rss_mem_used', 0)
        owner_dict["mem_req"] += perf_values.get('mem_req', 0)
        owner_dict["cpu_req"] += perf_values.get('cpu_req', 0)
        owner_dict["cpu_limit"] += perf_values.get('cpu_limit', 0)
        owner_dict["mem_limit"] += perf_values.get('mem_limit', 0)
        owner_dict["rx"] += perf_values.get('rx', 0)
        owner_dict["tx"] += perf_values.get('tx', 0)
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> add_perf_values_to_dict -> {}".format(e))
        traceback.print_exc()