from com.manageengine.monagent.kubernetes.Parser.JSONParserInterface import JSONParser

class ClusterIssuers(JSONParser):
    def __init__(self):
        super().__init__('ClusterIssuers')
        self.is_namespaces = False
        self.fetch_with_limit = False

    def get_perf_metrics(self):
        for cnd in self.get_2nd_path_value(['status', 'conditions'], []):
            if cnd.get('type') == 'Ready':
                self.value_dict['ready_status'] = 0 if cnd['status'] == 'False' else 1
                self.value_dict['CIRR'] = cnd.get('reason', '')
                self.value_dict['CIRM'] = cnd.get('message', '')
                break

        self.value_dict['Cnds'] = {
            cnd['type']: {
                'St': cnd['status'],
                'Re': cnd.get('reason', ''),
                'Msg': cnd.get('message', '')
            } for cnd in self.get_2nd_path_value(['status', 'conditions'], [])
        }
