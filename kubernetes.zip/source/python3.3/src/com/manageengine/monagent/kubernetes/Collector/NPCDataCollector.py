'''
@author: bharath.veerakumar

Created on Feb 20 2023
'''


import traceback
import json
from abc import abstractmethod
from com.manageengine.monagent.kubernetes.Logging import KubeLogger as AgentLogger
from com.manageengine.monagent.kubernetes.Parser import KubeJsonParser, KubePrometheusParser
from com.manageengine.monagent.kubernetes import KubeUtil
from com.manageengine.monagent.kubernetes.KubeUtil import exception_handler
from com.manageengine.monagent.kubernetes import KubeGlobal
from com.manageengine.monagent.kubernetes.Collector.DataCollectorInterface import DataCollector

class NPCDataCollector(DataCollector):
    def collect_data(self):
        try:
            kubelet_data = self.collect_kubelet_data()
            k8s_api_data = self.collect_k8s_api_data()
            cadvisor_data = self.collect_cadvisor_data()

            self.merge_apis_data(k8s_api_data, kubelet_data, cadvisor_data)

            self.merge_cont_data(self.final_json)
            self.process_node_metrics(self.final_json)
            self.process_pod_metrics(self.final_json)
            AgentLogger.debug(AgentLogger.DA, '## final perf data {}'.format(json.dumps(self.final_json)))
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'CollectPerfData -> Exception -> {0}'.format(e))

    def collect_kubelet_data(self):
        kubelet_data = {}
        try:
            kubelet_data = KubeJsonParser.load_k8s_config_xml(KubeGlobal.confXmlFile, False, True)
            kubelet_health = KubeUtil.getKubeletHealthStatus()

            if kubelet_data and "Nodes" in kubelet_data:
                nodes_dict_copy = kubelet_data.pop("Nodes")
                nodes_dict_copy["kubelet_health"] = kubelet_health
                if "NN" in nodes_dict_copy:
                    KubeGlobal.KUBELET_NODE_NAME = nodes_dict_copy["NN"]
                    kubelet_data["Nodes"] = {}
                    kubelet_data["Nodes"][nodes_dict_copy["NN"]] = nodes_dict_copy

            AgentLogger.debug(AgentLogger.DA, '## kubelet data {}'.format(json.dumps(kubelet_data)))
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, "Exc in collect_kubelet_data {}".format(e))
        return kubelet_data

    def collect_cadvisor_data(self):
        cadvisor_data = {}
        try:
            container_data = KubePrometheusParser.load_k8s_perf_xml(KubeGlobal.cadvisorXmlFile)
            cadvisor_data = container_data.pop("CAdvisor") if "CAdvisor" in container_data else {}
            AgentLogger.debug(AgentLogger.DA,'## cadvisor data {}'.format(json.dumps(cadvisor_data)))
        except Exception:
            traceback.print_exc()
        return cadvisor_data

    @abstractmethod
    def merge_apis_data(self, k8s_api_data, kubelet_data, cadvisor_data):
        perf_data = {}
        pod_data = {}
        node_data = {}
        node_name = KubeGlobal.KUBELET_NODE_NAME
        try:
            pod_data = kubelet_data.pop("Pods") if "Pods" in kubelet_data else {}
            node_data[node_name] = self.ksm_data["Nodes"].pop(node_name) if "Nodes" in self.ksm_data and node_name in self.ksm_data["Nodes"] else {}

            if "Nodes" in kubelet_data and node_name in kubelet_data["Nodes"]:
                node_data[node_name].update(kubelet_data["Nodes"][node_name])

            for pod_key, pod_val in pod_data.items():
                if pod_key in self.ksm_data["Pods"]:
                    pod_data[pod_key].update(self.ksm_data["Pods"][pod_key])

            for cont_key, cont_val in cadvisor_data.items():
                if cont_key in self.ksm_data["Cont"]:
                    cadvisor_data[cont_key].update(self.ksm_data["Cont"][cont_key])
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, "Exc in collect_cadvisor_data {}".format(e))
        finally:
            perf_data['Nodes'] = node_data
            perf_data['Pods'] = pod_data
            perf_data['Cont'] = cadvisor_data
            self.final_json = KubeUtil.MergeDataDictionaries(perf_data, k8s_api_data)

    def collect_k8s_api_data(self):
        k8s_api_data = {}
        try:
            k8s_api_data = KubeJsonParser.load_k8s_perf_xml(KubeGlobal.npcConfigXmlFile, self.dc_requisites_obj.is_sidecar_agent)
            AgentLogger.debug(AgentLogger.DA, "## k8s api data {}".format(json.dumps(k8s_api_data)))
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, "Exc in collect_k8s_api_data {}".format(e))
        return k8s_api_data

    @exception_handler
    def process_pod_metrics(self, k8s_api_data):
        node_cpu_request, node_cpu_limit, node_memory_request, node_memory_limit, cpu_throttle_secs, cpu_tot_period, cpu_throttle_period = 0, 0, 0, 0, 0, 0, 0
        for each_pod, pod_metrics in k8s_api_data['Pods'].items():
            try:
                if isinstance(pod_metrics, dict):
                    if 'UNC' in pod_metrics and "PRLCC" in pod_metrics:
                        pod_metrics['CPU'] = (pod_metrics["UNC"] / pod_metrics["PRLCC"]) * 100
                    if 'UB' in pod_metrics and 'PRLMB' in pod_metrics:
                        pod_metrics['MEM'] = (pod_metrics['UB'] / pod_metrics['PRLMB']) * 100
                    if "tolerations" in pod_metrics:
                        pod_metrics["tolerations"] = self.get_pod_toleration(pod_metrics["tolerations"])

                    # Slack metric
                    if "PRRCC" in pod_metrics and "UNC" in pod_metrics:
                        pod_metrics["cpu_slack_mic"] = pod_metrics["PRRCC"] - pod_metrics["UNC"]
                        pod_metrics["cpu_slack_perc"] = KubeUtil.calc_perc(pod_metrics["UNC"], pod_metrics["PRRCC"])
                    if "PRMB" in pod_metrics and "UB" in pod_metrics:
                        pod_metrics["mem_slack_mic"] = pod_metrics["PRMB"] - pod_metrics["UB"]
                        pod_metrics["mem_slack_perc"] = KubeUtil.calc_perc(pod_metrics["UB"], pod_metrics["PRMB"])

                    pod_metrics["GRPWO"] = pod_metrics.get("owner_kind", "") != "" #GR
                    node_cpu_request += pod_metrics.get("PRRCC", 0)
                    node_cpu_limit += pod_metrics.get("PRLCC", 0)
                    node_memory_request += pod_metrics.get("PRMB", 0)
                    node_memory_limit += pod_metrics.get("PRLMB", 0)

                    self.get_pod_status_based_metrics(pod_metrics, each_pod)
                    self.process_cont_metrics(pod_metrics["Cont"], each_pod, pod_metrics)

                    cpu_throttle_secs, cpu_throttle_period, cpu_tot_period = pod_metrics["KPTHS"] + cpu_throttle_secs, pod_metrics["KPTHP"] + cpu_throttle_period, pod_metrics["KPP"] + cpu_tot_period
            except Exception as e:
                AgentLogger.log(AgentLogger.KUBERNETES, "Exception in process_pod_metrics {}".format(e))
                traceback.print_exc()
            pod_metrics.pop("PodSt", None)

        k8s_api_data['Nodes'][KubeGlobal.KUBELET_NODE_NAME]['NCR'] = node_cpu_request
        k8s_api_data['Nodes'][KubeGlobal.KUBELET_NODE_NAME]['NCL'] = node_cpu_limit
        k8s_api_data['Nodes'][KubeGlobal.KUBELET_NODE_NAME]['NMR'] = node_memory_request
        k8s_api_data['Nodes'][KubeGlobal.KUBELET_NODE_NAME]['NML'] = node_memory_limit

        # cpu throttling metrics
        k8s_api_data['Nodes'][KubeGlobal.KUBELET_NODE_NAME]['KNTHS'] = cpu_throttle_secs
        k8s_api_data['Nodes'][KubeGlobal.KUBELET_NODE_NAME]['KNTHP'] = cpu_throttle_period
        k8s_api_data['Nodes'][KubeGlobal.KUBELET_NODE_NAME]['KNP'] = cpu_tot_period
        k8s_api_data['Nodes'][KubeGlobal.KUBELET_NODE_NAME]['cpu_throttle_perc'] = (cpu_throttle_period / cpu_tot_period) * 100 if cpu_tot_period else 0

    @exception_handler
    def process_cont_metrics(self, cont_data, pod_name, pod_metrics):
        tc, rd_c, KCTHS, KCTHP, KCP = len(cont_data), 0, 0, 0, 0

        for cont_key, cont_metrics in cont_data.items():
            if "KPCSRT" in cont_metrics:
                cont_metrics["KCRCPI"] = KubeUtil.get_counter_value(pod_name + "_" + cont_key, cont_metrics["KPCSRT"], True)
            if "KPCSRe" in cont_metrics and int(cont_metrics["KPCSRe"]) == 1:
                cont_metrics["status"], rd_c = "Ready", rd_c + 1
            if "KCACPU" in cont_metrics and "KPCRLCC" in cont_metrics:
                cont_metrics['cpu_percent'] = (cont_metrics["KCACPU"] / cont_metrics["KPCRLCC"]) * 100
            if "KCAMUB" in cont_metrics and "KPCRLMB" in cont_metrics:
                cont_metrics["memory_percent"] = (cont_metrics["KCAMUB"] / cont_metrics["KPCRLMB"]) * 100

            # Slack metric
            if "KPCRRCC" in cont_metrics and "KCACPU" in cont_metrics:
                cont_metrics["cpu_slack_mic"] = cont_metrics["KPCRRCC"] - cont_metrics["KCACPU"]
                cont_metrics["cpu_slack_perc"] = KubeUtil.calc_perc(cont_metrics["KCACPU"], cont_metrics["KPCRRCC"])
            if "KPCRRMB" in cont_metrics and "KCAMUB" in cont_metrics:
                cont_metrics["mem_slack_mic"] = cont_metrics["KPCRRMB"] - cont_metrics["KCAMUB"]
                cont_metrics["mem_slack_perc"] = KubeUtil.calc_perc(cont_metrics["KCAMUB"], cont_metrics["KPCRRMB"])

            cpu_throttle_period, cpu_throttle_sec, cpu_tot_period = cont_metrics.get("KCTHP", 0), cont_metrics.get("KCTHS", 0), cont_metrics.get("KCP", 0)
            cont_metrics["cpu_throttle_perc"] = (cpu_throttle_period / cpu_tot_period) * 100 if cpu_tot_period else 0

            KCTHS, KCTHP, KCP = KCTHS + cpu_throttle_sec, KCTHP + cpu_throttle_period, KCP + cpu_tot_period

        pod_metrics["rd_c"], pod_metrics["tc"] = rd_c, tc
        pod_metrics["cpu_throttle_perc"] = (KCTHP / KCP) * 100 if KCP else 0
        pod_metrics["KPTHS"], pod_metrics["KPP"], pod_metrics["KPTHP"] = KCTHS, KCP, KCTHP

    @exception_handler
    def process_node_metrics(self, k8s_api_data):
        for key, value in k8s_api_data['Nodes'].items():
            value["Schedulabilty"] = "Schedulable" if "KNSU" in value and value["KNSU"] == 0 else "Not Schedulable"

            node_taints = {}
            if "taints" in value:
                taints = value["taints"]
                for each in taints:
                    tk = each["key"]
                    tval = each["value"]
                    eff = each["effect"]
                    node_taints[tk] = "=" + tval + ":" + eff
            value["taints"] = json.dumps(node_taints)

            if "Cnds" in value and "Ready" in value["Cnds"] and "St" in value["Cnds"]["Ready"]:
                value["ready_status"] = "Ready" if value["Cnds"]["Ready"]["St"] == "True" else "Not Ready"

            value["KNPC"] = len(k8s_api_data["Pods"]) if "Pods" in k8s_api_data else 0

            if "KNSCMB" in value and "WSB" in value:
                value["mem_perc"] = KubeUtil.calc_perc(value["WSB"], value["KNSCMB"])
            if "KNSCCC" in value and "UNC" in value:
                value["cpu_perc"] = KubeUtil.calc_perc(value["UNC"], int(value["KNSCCC"]) * 1000)
            if "KNSAMB" in value and "WSB" in value:
                value["alloc_mem_perc"] = KubeUtil.calc_perc(value["WSB"], value["KNSAMB"])
            if "KNSACC" in value and "UNC" in value:
                value["alloc_cpu_perc"] = KubeUtil.calc_perc(value["UNC"], int(value["KNSACC"]) * 1000)
            if "FSCB" in value and "FSUB" in value:
                value["disk_perc"] = KubeUtil.calc_perc(value["FSUB"], value["FSCB"])
            if "KNSCP" in value:
                value["pod_perc"] = KubeUtil.calc_perc(value["KNPC"], value["KNSAP"])

    def merge_cont_data(self, dataDic):
        try:
            AgentLogger.debug(AgentLogger.KUBERNETES,'inside merge_cont_data....')
            if dataDic and "Pods" in dataDic and "Cont" in dataDic:
                podDic = dataDic["Pods"]
                contDic = dataDic["Cont"]
                for cont_name, cont_val in contDic.items():
                    try:
                        contName, podName, nameSpace = cont_name.split("_")
                        podName = podName+"_"+nameSpace
                        if podName in podDic and "Cont" in podDic[podName]:
                            contData = podDic[podName]["Cont"]
                            newDic = KubeUtil.MergeDataDictionaries(cont_val,contData[contName])
                            contData.update({contName:newDic})
                    except Exception as e:
                        traceback.print_exc()
                AgentLogger.log(AgentLogger.KUBERNETES,'merge_cont_data -> removing Cont from dataDic')
                del dataDic["Cont"]
            else:
                AgentLogger.log(AgentLogger.KUBERNETES,'merge_cont_data -> empty data inputs')
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES,'Exception -> merge_cont_data -> {0}'.format(e))

    def get_pod_toleration(self, tolerations):
        pod_tolerations = {}
        try:
            for each in tolerations:
                tolk = each["key"] if "key" in each else ""
                tolop = each["operator"] if "operator" in each else ""
                toleff = each["effect"] if "effect" in each else ""
                tolsecs = each["tolerationSeconds"] if "tolerationSeconds" in each else ""
                if tolsecs:
                    pod_tolerations[tolk] = toleff + " " + "op = " + tolop + " for " + str(tolsecs) + "s"
                else:
                    pod_tolerations[tolk] = toleff + " " + "op = " + tolop
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> merge_cont_data -> {0}".format(e))
        return json.dumps(pod_tolerations)

    @exception_handler
    def get_pod_status_based_metrics(self, pod_data, pod_name):
        ph = pod_data["Ph"] if "Ph" in pod_data else None
        status = None
        podState = None
        if "PodSt" in pod_data:
            podState = pod_data["PodSt"]

        if "PRC" in pod_data:
            pod_data["KPRCPI"] = KubeUtil.get_counter_value(pod_name, pod_data["PRC"], True)

        if podState:
            for k1, v1 in podState.items():
                temp = v1["PCR"]
                if "waiting" in temp and "reason" in temp["waiting"]:
                    cont_status = status = temp["waiting"]["reason"]
                elif "terminated" in temp and "reason" in temp["terminated"]:
                    cont_status = status = temp["terminated"]["reason"]
                else:
                    cont_status = "Running"
                pod_data["Cont"][k1]["cont_status"] = cont_status

        if not status and "PFR" in pod_data and len(pod_data["PFR"])>0:
            status = pod_data["PFR"]

        if not status:
            status = ph

        pod_data["reason"] = status
        pod_data["p_status"] = status