import traceback
import json
from abc import abstractmethod
from com.manageengine.monagent.kubernetes.Logging import KubeLogger as AgentLogger
from com.manageengine.monagent.kubernetes.Parser import KubeJsonParser, KubePrometheusParser
from com.manageengine.monagent.kubernetes import KubeUtil
from com.manageengine.monagent.kubernetes import KubeGlobal
from com.manageengine.monagent.kubernetes.Collector.DataCollectorWrapper import DataCollector

class NPCDataCollector(DataCollector):
    def collect_data(self):
        try:
            kubelet_data = self.collect_kubelet_data()
            k8s_api_data = self.collect_k8s_api_data()
            cadvisor_data = self.collect_cadvisor_data()

            self.merge_apis_data(k8s_api_data, kubelet_data, cadvisor_data)

            self.merge_cont_data(self.final_json)
            self.process_node_metrics(self.final_json)
            self.process_pod_metrics(self.final_json)
            AgentLogger.debug(AgentLogger.DA, '## final perf data {}'.format(json.dumps(self.final_json)))
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, 'CollectPerfData -> Exception -> {0}'.format(e))

    def collect_kubelet_data(self):
        kubelet_data = {}
        try:
            kubelet_data = KubeJsonParser.load_k8s_config_xml(KubeGlobal.confXmlFile, False, True)
            kubelet_health = KubeUtil.getKubeletHealthStatus()

            if kubelet_data and "Nodes" in kubelet_data:
                nodes_dict_copy = kubelet_data.pop("Nodes")
                nodes_dict_copy["kubelet_health"] = kubelet_health
                if "NN" in nodes_dict_copy:
                    KubeGlobal.KUBELET_NODE_NAME = nodes_dict_copy["NN"]
                    kubelet_data["Nodes"] = {}
                    kubelet_data["Nodes"][nodes_dict_copy["NN"]] = nodes_dict_copy

            AgentLogger.debug(AgentLogger.DA, '## kubelet data {}'.format(json.dumps(kubelet_data)))
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, "Exc in collect_kubelet_data {}".format(e))
        return kubelet_data

    def collect_cadvisor_data(self):
        cadvisor_data = {}
        try:
            container_data = KubePrometheusParser.load_k8s_perf_xml(KubeGlobal.cadvisorXmlFile)
            cadvisor_data = container_data.pop("CAdvisor") if "CAdvisor" in container_data else {}
            AgentLogger.debug(AgentLogger.DA,'## cadvisor data {}'.format(json.dumps(cadvisor_data)))
        except Exception:
            traceback.print_exc()
        return cadvisor_data

    @abstractmethod
    def merge_apis_data(self, k8s_api_data, kubelet_data, cadvisor_data):
        perf_data = {}
        pod_data = {}
        node_data = {}
        node_name = KubeGlobal.KUBELET_NODE_NAME
        try:
            pod_data = kubelet_data.pop("Pods") if "Pods" in kubelet_data else {}
            node_data[node_name] = self.ksm_data["Nodes"].pop(node_name) if "Nodes" in self.ksm_data and node_name in self.ksm_data["Nodes"] else {}

            if "Nodes" in kubelet_data and node_name in kubelet_data["Nodes"]:
                node_data[node_name].update(kubelet_data["Nodes"][node_name])

            for pod_key, pod_val in pod_data.items():
                if pod_key in self.ksm_data["Pods"]:
                    pod_data[pod_key].update(self.ksm_data["Pods"][pod_key])

            for cont_key, cont_val in cadvisor_data.items():
                if cont_key in self.ksm_data["Cont"]:
                    cadvisor_data[cont_key].update(self.ksm_data["Cont"][cont_key])
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, "Exc in collect_cadvisor_data {}".format(e))
        finally:
            perf_data['Nodes'] = node_data
            perf_data['Pods'] = pod_data
            perf_data['Cont'] = cadvisor_data
            self.final_json = KubeUtil.MergeDataDictionaries(perf_data, k8s_api_data)

    def collect_k8s_api_data(self):
        k8s_api_data = {}
        try:
            k8s_api_data = KubeJsonParser.load_k8s_perf_xml(KubeGlobal.npcConfigXmlFile, self.dc_requisites_obj.is_sidecar_agent)
            AgentLogger.debug(AgentLogger.DA, "## k8s api data {}".format(json.dumps(k8s_api_data)))
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, "Exc in collect_k8s_api_data {}".format(e))
        return k8s_api_data

    def process_pod_metrics(self, k8s_api_data):
        node_cpu_request, node_cpu_limit, node_memory_request, node_memory_limit = 0, 0, 0, 0
        try:
            for each_pod, pod_metrics in k8s_api_data['Pods'].items():
                try:
                    if isinstance(pod_metrics, dict):
                        if 'UNC' in pod_metrics and "PRLCC" in pod_metrics:
                            cpu_used = pod_metrics["UNC"]
                            cpu_limit = pod_metrics["PRLCC"]
                            cpu_perc = (cpu_used / cpu_limit) * 100
                            pod_metrics['CPU'] = cpu_perc
                        if 'UB' in pod_metrics and 'PRLMB' in pod_metrics:
                            mem_used = pod_metrics['UB']
                            mem_limits = pod_metrics['PRLMB']
                            mem_perc = (mem_used / mem_limits) * 100
                            pod_metrics['MEM'] = mem_perc

                        pod_metrics["GRPWO"] = pod_metrics.get("owner_kind", "") != "" #GR

                        if "tolerations" in pod_metrics:
                            pod_metrics["tolerations"] = self.get_pod_toleration(pod_metrics["tolerations"])

                        if "PRRCC" in pod_metrics:
                            node_cpu_request += pod_metrics["PRRCC"]
                        if "PRLCC" in pod_metrics:
                            node_cpu_limit += pod_metrics["PRLCC"]
                        if "PRMB" in pod_metrics:
                            node_memory_request += pod_metrics["PRMB"]
                        if "PRLMB" in pod_metrics:
                            node_memory_limit += pod_metrics["PRLMB"]

                        self.get_pod_status_based_metrics(pod_metrics, each_pod)
                        self.process_cont_metrics(pod_metrics["Cont"], each_pod, pod_metrics)
                except Exception as e:
                    AgentLogger.log(AgentLogger.KUBERNETES, "Exception in process_pod_metrics {}".format(e))
                    traceback.print_exc()
                if "PodSt" in pod_metrics: pod_metrics.pop("PodSt", None)

            k8s_api_data['Nodes'][KubeGlobal.KUBELET_NODE_NAME]['NCR'] = node_cpu_request
            k8s_api_data['Nodes'][KubeGlobal.KUBELET_NODE_NAME]['NCL'] = node_cpu_limit
            k8s_api_data['Nodes'][KubeGlobal.KUBELET_NODE_NAME]['NMR'] = node_memory_request
            k8s_api_data['Nodes'][KubeGlobal.KUBELET_NODE_NAME]['NML'] = node_memory_limit
        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, "Exc in process_pod_metrics {}".format(e))

    def process_cont_metrics(self, cont_data, pod_name, pod_metrics):
        try:
            tc, rd_c = len(cont_data), 0
            for cont_key, cont_metrics in cont_data.items():
                if "KPCSRT" in cont_metrics:
                    cont_metrics["KCRCPI"] = KubeUtil.get_counter_value(pod_name + "_" + cont_key, cont_metrics["KPCSRT"], True)
                if "KPCSRe" in cont_metrics and int(cont_metrics["KPCSRe"]) == 1:
                    cont_metrics["status"] = "Ready"
                    rd_c += 1
                if "KCACPU" in cont_metrics and "KPCRLCC" in cont_metrics:
                    cpu_used = cont_metrics["KCACPU"]
                    cpu_limit = cont_metrics["KPCRLCC"]
                    cpu_perc = (cpu_used / cpu_limit) * 100
                    cont_metrics['cpu_percent'] = cpu_perc
                if "KCAMUB" in cont_metrics and "KPCRLMB" in cont_metrics:
                    mem_used = cont_metrics["KCAMUB"]
                    mem_limit = cont_metrics["KPCRLMB"]
                    mem_perc = (mem_used / mem_limit) * 100
                    cont_metrics["memory_percent"] = mem_perc
            pod_metrics["rd_c"] = rd_c
            pod_metrics["tc"] = tc
        except Exception as e:
            traceback.print_exc()

    def process_node_metrics(self, k8s_api_data):
        try:
            for key, value in k8s_api_data['Nodes'].items():
                value["Schedulabilty"] = "Schedulable" if "KNSU" in value and value["KNSU"] == 0 else "Not Schedulable"

                node_taints = {}
                if "taints" in value:
                    taints = value["taints"]
                    for each in taints:
                        tk = each["key"]
                        tval = each["value"]
                        eff = each["effect"]
                        node_taints[tk] = "=" + tval + ":" + eff
                value["taints"] = json.dumps(node_taints)

                if "Cnds" in value and "Ready" in value["Cnds"] and "St" in value["Cnds"]["Ready"]:
                    value["ready_status"] = "Ready" if value["Cnds"]["Ready"]["St"] == "True" else "Not Ready"

                value["KNPC"] = len(k8s_api_data["Pods"]) if "Pods" in k8s_api_data else 0

                if "KNSCMB" in value and "WSB" in value:
                    value["mem_perc"] = KubeUtil.calc_perc(value["WSB"], value["KNSCMB"])
                if "KNSCCC" in value and "UNC" in value:
                    value["cpu_perc"] = KubeUtil.calc_perc(value["UNC"], int(value["KNSCCC"]) * 1000)
                if "FSCB" in value and "FSUB" in value:
                    value["disk_perc"] = KubeUtil.calc_perc(value["FSUB"], value["FSCB"])
                if "KNSCP" in value:
                    value["pod_perc"] = KubeUtil.calc_perc(value["KNPC"], value["KNSAP"])

        except Exception as e:
            traceback.print_exc()
            AgentLogger.log(AgentLogger.KUBERNETES, "Exc in process_node_metrics {}".format(e))

    def merge_cont_data(self, dataDic):
        try:
            AgentLogger.debug(AgentLogger.KUBERNETES,'inside merge_cont_data....')
            if dataDic and "Pods" in dataDic and "Cont" in dataDic:
                podDic = dataDic["Pods"]
                contDic = dataDic["Cont"]
                for k,v in contDic.items():
                    try:
                        if isinstance(v,dict):
                            temp = k.split("_")
                            if len(temp) < 3:
                                continue
                            contName = temp[0]
                            podName = temp[1]
                            nameSpace = temp[2]
                            podName = podName+"_"+nameSpace
                            if podName in podDic:
                                podData = podDic[podName]
                                if podData and "Cont" in podData:
                                    contData = podData["Cont"]
                                    if contName in contData:
                                        v1 = contData[contName]
                                        newDic = KubeUtil.MergeDataDictionaries(v,v1)
                                        if newDic:
                                            contData.update({contName:newDic})
                    except Exception as e:
                        traceback.print_exc()
                AgentLogger.log(AgentLogger.KUBERNETES,'merge_cont_data -> removing Cont from dataDic')
                del dataDic["Cont"]
            else:
                AgentLogger.log(AgentLogger.KUBERNETES,'merge_cont_data -> empty data inputs')
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES,'Exception -> merge_cont_data -> {0}'.format(e))

    def get_pod_toleration(self, tolerations):
        pod_tolerations = {}
        try:
            for each in tolerations:
                tolk = each["key"] if "key" in each else ""
                tolop = each["operator"] if "operator" in each else ""
                toleff = each["effect"] if "effect" in each else ""
                tolsecs = each["tolerationSeconds"] if "tolerationSeconds" in each else ""
                if tolsecs:
                    pod_tolerations[tolk] = toleff + " " + "op = " + tolop + " for " + str(tolsecs) + "s"
                else:
                    pod_tolerations[tolk] = toleff + " " + "op = " + tolop
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> merge_cont_data -> {0}".format(e))
        return json.dumps(pod_tolerations)

    def get_pod_status_based_metrics(self, pod_data, pod_name):
        try:
            ph = pod_data["Ph"] if "Ph" in pod_data else None
            status = None
            podState = None
            if "PodSt" in pod_data:
                podState = pod_data["PodSt"]

            if "PRC" in pod_data:
                pod_data["KPRCPI"] = KubeUtil.get_counter_value(pod_name, pod_data["PRC"], True)

            if podState:
                for k1, v1 in podState.items():
                    temp = v1["PCR"]
                    if "waiting" in temp and "reason" in temp["waiting"]:
                        cont_status = status = temp["waiting"]["reason"]
                    elif "terminated" in temp and "reason" in temp["terminated"]:
                        cont_status = status = temp["terminated"]["reason"]
                    else:
                        cont_status = "Running"
                    pod_data["Cont"][k1]["cont_status"] = cont_status

            if not status and "PFR" in pod_data and len(pod_data["PFR"])>0:
                status = pod_data["PFR"]

            if not status:
                status = ph

            pod_data["reason"] = status
            pod_data["p_status"] = status
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, "Exception -> get_pod_status_based_metrics -> {}".format(e))