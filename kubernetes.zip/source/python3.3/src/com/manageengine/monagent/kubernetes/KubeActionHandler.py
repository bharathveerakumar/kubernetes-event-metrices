from com.manageengine.monagent.kubernetes import KubeGlobal, KubeUtil
from com.manageengine.monagent.kubernetes.ClusterAgent import ClusterAgentUtil
import json
import traceback


def kube_agent_action_handler(wms_response):
    try:
        if 'CLUSTER_AGENT_VERSION' in wms_response or 'NODE_AGENT_VERSION' in wms_response:
            update_configmap_agent_version(wms_response)
        if 'FETCH_CONFIG_MAP_DATA' in wms_response:
            load_configmap_data()
        if 'UPGRADE_CLUSTER_AGENT' in wms_response:
            ClusterAgentUtil.upgrade_cluster_agent()
    except Exception:
        traceback.print_exc()


def update_configmap_agent_version(version):
    try:
        # fetching existing configmap values
        status, response = KubeUtil.curl_api_with_token(KubeGlobal.apiEndpoint + KubeGlobal.s247ConfigMapPath)
        if status == 200:
            data = {
                'data': response['data']
            }
            if 'CLUSTER_AGENT_VERSION' in version:
                data['data']['CLUSTER_AGENT_VERSION'] = version['CLUSTER_AGENT_VERSION']
            if 'NODE_AGENT_VERSION' in version:
                data['data']['NODE_AGENT_VERSION'] = version['NODE_AGENT_VERSION']
            headers = {
                'Authorization': 'Bearer ' + KubeGlobal.bearerToken,
                'Content-Type': 'application/strategic-merge-patch+json',
                'Accept': 'application/json'
            }
            response = KubeGlobal.REQUEST_MODULE.patch(
                KubeGlobal.apiEndpoint + KubeGlobal.s247ConfigMapPath,
                headers=headers,
                verify=KubeGlobal.serviceAccPath + '/ca.crt',
                data=json.dumps(data)
            )

            return response.status_code
    except Exception:
        traceback.print_exc()
    return -1


def load_configmap_data():
    status, response = KubeUtil.curl_api_with_token(KubeGlobal.apiEndpoint + KubeGlobal.s247ConfigMapPath)
    if status == 200:
        KubeGlobal.CLUSTER_AGENT_STATS['cm_data'] = response['data']
