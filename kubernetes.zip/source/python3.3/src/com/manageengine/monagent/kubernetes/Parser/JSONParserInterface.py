from abc import abstractmethod
from com.manageengine.monagent.kubernetes.KubeUtil import curl_api_with_token, getAge, is_eligible_to_execute, curl_api_without_token
from com.manageengine.monagent.kubernetes import KubeGlobal
import traceback
from datetime import datetime


class JSONParser:
    def __init__(self, type=None):
        self.type = type
        self.final_dict = {}    # contains all the resources data as key: value pair
        self.value_dict = {}    # contains data for particular resource, used in iterating the raw value
        self.api_url = KubeGlobal.apiEndpoint + KubeGlobal.API_ENDPOINT_RES_NAME_MAP[type] if type else None
        self.raw_data = None
        self.is_namespaces = True
        self.fetch_with_limit = True
        self.metadata_needed = True
        self.certificate_verification = True
        self.paths_to_iterate = "items"
        self.cluster_level_metrics = {}
        self.yaml_parsing = False

    @abstractmethod
    def get_perf_metrics(self):
        pass

    @abstractmethod
    def handle_api_response(self, response):
        try:
            if self.yaml_parsing:
                for value in response[self.paths_to_iterate]:
                    self.raw_data = value
                    root_name = self.get_root_name()
                    if root_name not in KubeGlobal.RESOURCE_VERSIONS[self.type] or KubeGlobal.RESOURCE_VERSIONS[self.type][root_name] != value['metadata']['resourceVersion']:
                        self.final_dict[root_name] = value
                    KubeGlobal.RESOURCE_VERSIONS[self.type][root_name] = value['metadata']['resourceVersion']
                return

            for value in response[self.paths_to_iterate]:
                self.raw_data, self.value_dict = value, {}
                root_name = self.get_root_name()

                if self.metadata_needed:   # metadata will only be collected if the resource got updated
                    self.get_metadata()

                self.get_perf_metrics()
                self.save_value_dict(root_name)
        except Exception:
            traceback.print_exc()

    @abstractmethod
    def save_value_dict(self, root_name):
        self.final_dict[root_name] = self.value_dict

    @abstractmethod
    def get_root_name(self):
        if not self.is_namespaces:
            return self.raw_data['metadata']['name']
        return self.raw_data['metadata']['name'] + '_' + self.raw_data['metadata']['namespace']

    @abstractmethod
    def get_metadata(self):
        self.get_namespaces_resource_metadata() if self.is_namespaces else self.get_resource_metadata()

    @abstractmethod
    def is_resource_modified(self, root_name):
        if root_name not in KubeGlobal.RESOURCE_VERSIONS[self.type] or KubeGlobal.RESOURCE_VERSIONS[self.type][root_name] != self.get_2nd_path_value(['metadata', 'resourceVersion']):
            KubeGlobal.RESOURCE_VERSIONS[self.type][root_name] = self.get_2nd_path_value(['metadata', 'resourceVersion'])
            return True
        return False

    def get_data(self):
        self.get_data_by_limit() if self.fetch_with_limit else self.get_data_without_limit()
        if self.cluster_level_metrics:
            self.final_dict["aggregated_metrics"] = self.cluster_level_metrics
        return self.final_dict

    def get_yaml_data(self):
        self.yaml_parsing = True
        self.get_data_by_limit()
        return self.final_dict

    def get_data_by_limit(self, continue_token=None):
        status, response = curl_api_with_token(self.api_url + (("&continue=" + continue_token) if continue_token else ""), self.certificate_verification)
        if status == 200 and response:
            self.handle_api_response(response)
            if 'continue' in response['metadata'] and response['metadata']['remainingItemCount'] > 0:
                self.get_data_by_limit(response['metadata']['continue'])

    def get_data_without_limit(self):
        status, response = curl_api_with_token(self.api_url, self.certificate_verification)
        if status == 200 and response:
            self.handle_api_response(response)

    def get_namespaces_resource_metadata(self):
        self.value_dict = {
            "Na": self.raw_data['metadata']['name'],
            "NS": self.raw_data['metadata']['namespace'],
            "UID": self.raw_data['metadata']['uid'],
            "CT": self.raw_data['metadata']['creationTimestamp'],
            "rv": self.raw_data['metadata']['resourceVersion'],
            "age": getAge(self.raw_data['metadata']['creationTimestamp'], datetime.now())
        }

    def get_resource_metadata(self):
        self.value_dict = {
            "Na": self.raw_data['metadata']['name'],
            "UID": self.raw_data['metadata']['uid'],
            "CT": self.raw_data['metadata']['creationTimestamp'],
            "rv": self.raw_data['metadata']['resourceVersion'],
            "age": getAge(self.raw_data['metadata']['creationTimestamp'], datetime.now())
        }

    def aggregate_cluster_metrics(self, key_name, value):
        self.cluster_level_metrics[key_name] = self.cluster_level_metrics.get(key_name, 0) + value

    def get_1st_path_value(self, path, default_value=None):
        try:
            return self.raw_data[path[0]]
        except KeyError:
            return default_value

    def get_2nd_path_value(self, path, default_value=None):
        try:
            return self.raw_data[path[0]][path[1]]
        except KeyError:
            return default_value

    def get_3rd_path_value(self, path, default_value=None):
        try:
            return self.raw_data[path[0]][path[1]][path[2]]
        except KeyError:
            return default_value

    def get_4th_path_value(self, path, default_value=None):
        try:
            return self.raw_data[path[0]][path[1]][path[2]][path[3]]
        except KeyError:
            return default_value

    def get_5th_path_value(self, path, default_value=None):
        try:
            return self.raw_data[path[0]][path[1]][path[2]][path[3]][path[4]]
        except KeyError:
            return default_value
