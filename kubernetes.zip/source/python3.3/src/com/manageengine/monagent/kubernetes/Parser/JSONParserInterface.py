from abc import abstractmethod
from com.manageengine.monagent.kubernetes.KubeUtil import curl_api_with_token
from com.manageengine.monagent.kubernetes.KubeUtil import getAge
import traceback
from datetime import datetime


class JSONParser:
    def __init__(self, url):
        self.final_dict = {}    # contains all the resources data as key: value pair
        self.value_dict = {}    # contains data for particular resource, used in iterating the raw value
        self.api_url = url
        self.raw_data = None
        self.is_namespaces = True
        self.fetch_with_limit = True
        self.paths_to_iterate = "items"
        self.aggregated_metrics = {}

    @abstractmethod
    def parse(self):
        pass

    @abstractmethod
    def handle_api_response(self, response):
        try:
            for value in response[self.paths_to_iterate]:
                self.raw_data, self.value_dict = value, {}
                self.get_namespaces_resource_metadata() if self.is_namespaces else self.get_resource_metadata()
                self.parse()
                self.final_dict[self.get_root_name()] = self.value_dict
        except Exception:
            traceback.print_exc()

    def aggregate_metrics(self, key_name, value):
        self.aggregated_metrics[key_name] += value

    @abstractmethod
    def get_root_name(self):
        return self.raw_data['metadata']['name'] + '_' + self.raw_data['metadata']['namespace']

    def get_data(self):
        if self.fetch_with_limit:
            self.get_data_by_limit()
            return self.final_dict

        self.get_data_without_limit()
        return self.final_dict

    def get_data_by_limit(self, continue_token=None):
        status, response = curl_api_with_token(self.api_url + ("&continue=" + continue_token) if continue_token else "")

        if status == 200 and response:
            self.handle_api_response(response)
            if 'continue' in response['metadata'] and response['metadata']['remainingItemCount'] > 0:
                self.get_data_by_limit(response['metadata']['continue'])

    def get_data_without_limit(self):
        status, response = curl_api_with_token(self.api_url)
        if status == 200 and response:
            self.handle_api_response(response)

    def get_namespaces_resource_metadata(self):
        self.value_dict = {
            "Na": self.raw_data['metadata']['name'],
            "NS": self.raw_data['metadata']['namespace'],
            "UID": self.raw_data['metadata']['uid'],
            "age": getAge(self.raw_data['metadata']['creationTimestamp'], datetime.now())
        }

    def get_resource_metadata(self):
        self.value_dict = {
            "Na": self.raw_data['metadata']['name'],
            "UID": self.raw_data['metadata']['uid'],
            "age": getAge(self.raw_data['metadata']['creationTimestamp'], datetime.now())
        }

    def get_1st_path_value(self, path, default_value=None):
        try:
            return self.raw_data[path[0]]
        except KeyError:
            return default_value

    def get_2nd_path_value(self, path, default_value=None):
        try:
            return self.raw_data[path[0]][path[1]]
        except KeyError:
            return default_value

    def get_3rd_path_value(self, path, default_value=None):
        try:
            return self.raw_data[path[0]][path[1]][path[2]]
        except KeyError:
            return default_value

    def get_4th_path_value(self, path, default_value=None):
        try:
            return self.raw_data[path[0]][path[1]][path[2]][path[3]]
        except KeyError:
            return default_value

    def get_5th_path_value(self, path, default_value=None):
        try:
            return self.raw_data[path[0]][path[1]][path[2]][path[3]][path[4]]
        except KeyError:
            return default_value
