'''
@author: bharath.veerakumar

Created on Feb 20 2023
'''


import traceback
from com.manageengine.monagent.kubernetes import KubeUtil
from com.manageengine.monagent.kubernetes.KubeUtil import exception_handler
from com.manageengine.monagent.kubernetes.Logging import KubeLogger as AgentLogger
from com.manageengine.monagent.kubernetes.ClusterAgent import ClusterAgentUtil
from com.manageengine.monagent.kubernetes import KubeGlobal
from com.manageengine.monagent.kubernetes.Collector.DataCollectorInterface import DataCollector
from com.manageengine.monagent.kubernetes.Parser.PrometheusParser.ResourceDependencyMetricsParser import ResourceDependency as ResourceDependencyParser


class ResourceDependency(DataCollector):

    def init_dependent_dict(self):
        self.final_json = {
            'Pod': {},
            'Node': {},
            'DaemonSet': {},
            'StatefulSet': {},
            'Deployment': {},
            'Job': {},
            'Service': {},
            'Namespace': {}
        }

    def collect_data(self):
        try:
            self.init_dependent_dict()

            owners_info = ResourceDependencyParser().get_data()
            owners_info['Pod'] = KubeUtil.MergeDataDictionaries(owners_info.pop('Pod'), owners_info.pop('Node'))
            owners_info['Services'] = {}

            # hashing necessary things(Service labels, Pod->Container) for creating final DEPENDENCY_DICT
            KubeUtil.get_api_data_by_limit(KubeGlobal.apiEndpoint + KubeGlobal.API_ENDPOINT_RES_NAME_MAP['Services'], self.hash_service_selectors, owners_info)
            self.hash_pod_container(owners_info)
            self.map_workload_pods(owners_info)

            AgentLogger.debug(AgentLogger.KUBERNETES, 'Dependent Resource Dict {}'.format(self.final_json))
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, 'Exception -> construct_dependency -> {}'.format(e))
            traceback.print_exc()

    def get_data_for_cluster_agent(self, req_params=None):
        self.init_dependent_dict()

        owners_info = ClusterAgentUtil.get_parsed_data_for_ca("resource_dependency_ksm")
        owners_info['Pod'] = KubeUtil.MergeDataDictionaries(owners_info.pop('Pod'), owners_info.pop('Node'))

        # hashing necessary things(Service labels, Pod->Container) for creating final DEPENDENCY_DICT
        owners_info['Services'] = ClusterAgentUtil.get_parsed_data_for_ca('service_rs')
        self.hash_pod_container(owners_info)
        self.map_workload_pods(owners_info)

        AgentLogger.debug(AgentLogger.KUBERNETES, 'Dependent Resource Dict {}'.format(self.final_json))
        return self.final_json

    def hash_pod_container(self, owners_info):
        pod_cont_map_dict = {}
        try:
            pods_id_dict = KubeUtil.get_id_group_dict('Pods')
            for key, val in owners_info['Containers'].items():
                try:
                    pod_key = val['pod_name'] +'_'+ val['namespace']
                    id_dict = pods_id_dict[pod_key] if pods_id_dict and pod_key in pods_id_dict else {}

                    if pod_key not in pod_cont_map_dict:
                        pod_cont_map_dict[pod_key] = {}

                    pod_cont_map_dict[pod_key][key] = {
                        'name': val['name'],
                        'pod_name': val['pod_name'],
                        'namespace': val['namespace'],
                        'id': id_dict['Cont'][val['name']]['id'] if 'Cont' in id_dict and val['name'] in id_dict['Cont'] else None
                    }
                except Exception as e:
                    traceback.print_exc()
        except Exception as e:
            traceback.print_exc()
        owners_info['Containers'] = pod_cont_map_dict

    def hash_service_selectors(self, service_data, lookup_dict):
        try:
            for val in service_data['items']:
                try:
                    name = val['metadata']['name']
                    ns = val['metadata']['namespace']
                    if 'spec' in val and 'selector' in val['spec']:
                        sel = val['spec']['selector']
                        match_labels = []
                        for key, value in sel.items():
                            match_labels.append("{}%3D{}".format(key, value))

                        status, api_resp = KubeUtil.curl_api_with_token(KubeGlobal.apiEndpoint + "/api/v1/namespaces/{}/pods?labelSelector={}".format(ns, ",".join(match_labels)))
                        if status == 200:
                            for pod_value in api_resp["items"]:
                                lookup_dict['Services'][pod_value['metadata']['name'] + "_" + ns] = {
                                    'name': name,
                                    'namespace': ns,
                                    'id': KubeUtil.get_resource_id(name+'_'+ns, 'Services')
                                }
                except Exception:
                    traceback.print_exc()
        except Exception as e:
            traceback.print_exc()

    @exception_handler
    def map_workload_pods(self, owners_info):
        pod_cont_map_dict = owners_info['Containers']

        for key, val in owners_info['Pod'].items():
            try:
                ns = val['namespace']
                service_info = owners_info["Services"].get(key)    # Getting dependent pod of service by matching selectors and lables
                pod_id = KubeUtil.get_resource_id(key, 'Pods')
                owner_name = val['owner_name'] +'_'+ ns
                owner_kind = val['kind']

                if owner_kind == "ReplicaSet":
                    deploy_name = owners_info['ReplicaSet'].get(owner_name, {}).get("owner_name")
                    if not deploy_name:
                        continue
                    owner_name, owner_kind, val['owner_name'] = deploy_name, "Deployment", deploy_name

                owner_id = KubeUtil.get_resource_id(owner_name, owner_kind+'s')
                pod_info_dict = {
                    'name': val['name'],
                    'namespace': val['namespace'],
                    'id': pod_id
                }

                if owner_kind in ['DaemonSet', 'Deployment', 'StatefulSet', 'Job']:   # adding this check to avoid the CustomResourceDefinitions
                    self.map_namespace_workloads(ns, owner_kind, owner_name, owner_id, service_info)        # namespace --> workloads
                    KubeUtil.init_nested_dict(self.final_json[owner_kind], [owner_name, 'Pod'])     # workloads --> pods
                    self.init_owners_info(self.final_json[owner_kind][owner_name], val, owner_id, 'owner_name')
                    self.final_json[owner_kind][owner_name]['Pod'][key] = pod_info_dict

                KubeUtil.init_nested_dict(self.final_json['Pod'], [key])       # pods --> containers
                self.init_owners_info(self.final_json['Pod'][key], val, pod_id)
                self.final_json['Pod'][key]['Container'] = pod_cont_map_dict[key] if key in pod_cont_map_dict else {}

                if val['node']:
                    KubeUtil.init_nested_dict(self.final_json['Node'], [val['node'], 'Pod'])     # nodes --> pods
                    self.init_owners_info(self.final_json['Node'][val['node']], val, KubeUtil.get_resource_id(val['node'], 'Nodes'), 'node')
                    self.final_json['Node'][val['node']]['Pod'][key] = pod_info_dict

                if service_info:                                                    # services --> pods
                    service_name = service_info['name']+'_'+service_info['namespace']
                    KubeUtil.init_nested_dict(self.final_json['Service'], [service_name, 'Pod'])
                    self.init_owners_info(self.final_json['Service'][service_name], service_info, KubeUtil.get_resource_id(service_name, 'Services'))
                    self.final_json['Service'][service_name]['Pod'][key] = pod_info_dict
            except Exception:
                traceback.print_exc()

    @exception_handler
    def init_owners_info(self, owner_dict, val, id, owner_keyname = 'name'):
        owner_dict['name'] = val[owner_keyname]
        owner_dict['namespace'] = val['namespace']
        owner_dict['id'] = id

    @exception_handler
    def map_namespace_workloads(self, ns, owner_kind, owner_name, owner_id, service_info):
        if ns not in self.final_json['Namespace']:
            self.final_json['Namespace'][ns] = {
                'name': ns,
                'id': KubeUtil.get_resource_id(ns, 'Namespaces')
            }
        KubeUtil.init_nested_dict(self.final_json['Namespace'][ns], [owner_kind])
        self.final_json['Namespace'][ns][owner_kind][owner_name] = {
            'name': owner_name,
            'namespace': ns,
            'id': owner_id
        }
        if service_info:
            service_name = service_info['name'] + '_' + service_info['namespace']
            KubeUtil.init_nested_dict(self.final_json['Namespace'][ns], ['Service'])
            self.final_json['Namespace'][ns]['Service'][service_name] = {
                'name': service_info['name'],
                'namespace': ns,
                'id': KubeUtil.get_resource_id(service_name, "Services")
            }
