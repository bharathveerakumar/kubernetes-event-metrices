import traceback
from com.manageengine.monagent.kubernetes import KubeUtil
from com.manageengine.monagent.kubernetes.Logging import KubeLogger as AgentLogger
from com.manageengine.monagent.kubernetes import KubeGlobal
from com.manageengine.monagent.kubernetes.Collector.DataCollector import DataCollector

DEPENDENCY_DICT = {}

class ResourceDependency(DataCollector):
    def init_dependent_dict(self):
        global DEPENDENCY_DICT

        DEPENDENCY_DICT = {
            'Pod': {},
            'Node': {},
            'DaemonSet': {},
            'StatefulSet': {},
            'Deployment': {},
            'ReplicaSet': {},
            'Job': {},
            'Service': {},
            'Namespace': {}
        }

    def collect_data(self, kube_state_data):
        global DEPENDENCY_DICT
        try:
            self.init_dependent_dict()

            owners_info = KubeUtil.get_ca_parsed_data("resource_dependency")
            owners_info['Pod'] = KubeUtil.MergeDataDictionaries(owners_info.pop('Pod'), owners_info.pop('Node'))

            # hashing necessary things(Service labels, Deployment->ReplicaSet, Pod->Container) for creating final DEPENDENCY_DICT
            KubeUtil.get_api_data_by_limit(KubeGlobal.apiEndpoint + '/api/v1/services?limit=500', self.hash_service_selectors, owners_info)
            self.hash_deployment_replicaset(owners_info)
            self.hash_pod_container(owners_info)
            self.map_workload_pods(owners_info)

            AgentLogger.debug(AgentLogger.KUBERNETES, 'Dependent Resource Dict {}'.format(DEPENDENCY_DICT))
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, 'Exception -> construct_dependency -> {}'.format(e))
            traceback.print_exc()
        return DEPENDENCY_DICT

    def hash_pod_container(self, owners_info):
        pod_cont_map_dict = {}
        try:
            pods_id_dict = KubeUtil.get_id_group_dict('Pods')
            for key, val in owners_info['Containers'].items():
                try:
                    pod_key = val['pod_name'] +'_'+ val['namespace']
                    id_dict = pods_id_dict[pod_key] if pods_id_dict and pod_key in pods_id_dict else {}

                    if pod_key not in pod_cont_map_dict:
                        pod_cont_map_dict[pod_key] = {}

                    pod_cont_map_dict[pod_key][key] = {
                        'name': val['name'],
                        'pod_name': val['pod_name'],
                        'namespace': val['namespace'],
                        'id': id_dict['Cont'][val['name']]['id'] if 'Cont' in id_dict and val['name'] in id_dict['Cont'] else None
                    }
                except Exception as e:
                    traceback.print_exc()
        except Exception as e:
            traceback.print_exc()
        owners_info['Containers'] = pod_cont_map_dict

    def hash_deployment_replicaset(self, owners_info):     #  This method is for creating ReplicaSet -> Deployment dependency, as it available as seperate family in KSM
        repl_depl_map_dict = {
            'Deployment': {}
        }
        try:
            for key, val in owners_info['ReplicaSet'].items():
                try:
                    owner_kind = val['kind']
                    if owner_kind == 'Deployment':
                        owner_name = val['owner_name'] +'_'+ val['namespace']
                        owner_id = KubeUtil.get_resource_id(owner_name, 'Deployments')

                        KubeUtil.init_nested_dict(repl_depl_map_dict[owner_kind], [owner_name, 'ReplicaSet'])     # Mapping ReplicaSets to Deployment
                        self.init_owners_info(repl_depl_map_dict[owner_kind][owner_name], val, owner_id, 'owner_name')
                        repl_depl_map_dict[owner_kind][owner_name]['ReplicaSet'][key] = {
                            'name': val['name'],
                            'namespace': val['namespace'],
                            'id': KubeUtil.get_resource_id(key, 'ReplicaSets')
                        }
                except Exception as e:
                    traceback.print_exc()
            owners_info['ReplicaSet'] = repl_depl_map_dict
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, 'Exception -> map_deployment_replicaset -> {}'.format(e))
            traceback.print_exc()

    def hash_service_selectors(self, service_data, owners_info):
        lookup_dict = {}
        try:
            for val in service_data['items']:
                try:
                    name = val['metadata']['name']
                    ns = val['metadata']['namespace']
                    if 'spec' in val and 'selector' in val['spec']:
                        sel = val['spec']['selector']
                        for sel_key, sel_val in sel.items():
                            hash_key = sel_key+'@'+sel_val+'@'+ns
                            lookup_dict[hash_key] = {
                                'name': name,
                                'namespace': ns,
                                'id': KubeUtil.get_resource_id(name+'_'+ns, 'Services')
                            }
                except Exception as e:
                    traceback.print_exc()
        except Exception as e:
            traceback.print_exc()
        owners_info['Services'] = lookup_dict

    def map_workload_pods(self, owners_info):
        global DEPENDENCY_DICT
        try:
            pods_list = {}
            KubeUtil.get_api_data_by_limit(KubeGlobal.apiEndpoint + '/api/v1/pods?limit=500', KubeUtil.filter_labels_to_constructed_dict, pods_list)

            repl_deploy_map_dict = owners_info['ReplicaSet']
            pod_cont_map_dict = owners_info['Containers']

            for key, val in owners_info['Pod'].items():
                try:
                    ns = val['namespace']
                    service_info = KubeUtil.get_pod_service_map(key, pods_list, owners_info['Services'])    # Getting dependent pod of service by matching selectors and lables
                    owner_name = val['owner_name'] +'_'+ ns
                    owner_kind = val['kind']
                    pod_id = KubeUtil.get_resource_id(key, 'Pods')
                    owner_id = KubeUtil.get_resource_id(owner_name, owner_kind+'s')
                    pod_info_dict = {
                            'name': val['name'],
                            'namespace': val['namespace'],
                            'id': pod_id
                    }

                    if owner_kind in ['DaemonSet', 'ReplicaSet', 'StatefulSet', 'Job']:   # adding this check to avoid the CustomResourceDefinitions
                        self.map_namespace_workloads(ns, owner_kind, owner_name, owner_id, service_info)        # namespace --> workloads
                        KubeUtil.init_nested_dict(DEPENDENCY_DICT[owner_kind], [owner_name, 'Pod'])     # workloads --> pods
                        self.init_owners_info(DEPENDENCY_DICT[owner_kind][owner_name], val, owner_id, 'owner_name')
                        DEPENDENCY_DICT[owner_kind][owner_name]['Pod'][key] = pod_info_dict

                    KubeUtil.init_nested_dict(DEPENDENCY_DICT['Pod'], [key])       # pods --> containers
                    self.init_owners_info(DEPENDENCY_DICT['Pod'][key], val, pod_id)
                    DEPENDENCY_DICT['Pod'][key]['Container'] = pod_cont_map_dict[key] if key in pod_cont_map_dict else {}

                    KubeUtil.init_nested_dict(DEPENDENCY_DICT['Node'], [val['node'], 'Pod'])     # nodes --> pods
                    self.init_owners_info(DEPENDENCY_DICT['Node'][val['node']], val, KubeUtil.get_resource_id(val['node'], 'Nodes'), 'node')
                    DEPENDENCY_DICT['Node'][val['node']]['Pod'][key] = pod_info_dict

                    if service_info:                                                    # services --> pods
                        service_name = service_info['name']+'_'+service_info['namespace']
                        KubeUtil.init_nested_dict(DEPENDENCY_DICT['Service'], [service_name, 'Pod'])
                        self.init_owners_info(DEPENDENCY_DICT['Service'][service_name], service_info, KubeUtil.get_resource_id(service_name, 'Services'))
                        DEPENDENCY_DICT['Service'][service_name]['Pod'][key] = pod_info_dict
                except Exception as e:
                    traceback.print_exc()

            if 'Deployment' in repl_deploy_map_dict:
                DEPENDENCY_DICT['Deployment'] = repl_deploy_map_dict['Deployment']
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, 'Exception -> map_workload_pods -> {}'.format(e))
            traceback.print_exc()

    def init_owners_info(self, owner_dict, val, id, owner_keyname = 'name'):
        try:
            owner_dict['name'] = val[owner_keyname]
            owner_dict['namespace'] = val['namespace']
            owner_dict['id'] = id
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, 'Exception -> init_owners_info -> {}'.format(e))
            traceback.print_exc()

    def map_namespace_workloads(self, ns, owner_kind, owner_name, owner_id, service_info):
        global DEPENDENCY_DICT
        try:
            if ns not in DEPENDENCY_DICT['Namespace']:
                DEPENDENCY_DICT['Namespace'][ns] = {
                    'name': ns,
                    'id': KubeUtil.get_resource_id(ns, 'Namespaces')
                }
            KubeUtil.init_nested_dict(DEPENDENCY_DICT['Namespace'][ns], [owner_kind])
            DEPENDENCY_DICT['Namespace'][ns][owner_kind][owner_name] = {
                'name': owner_name,
                'namespace': ns,
                'id': owner_id
            }
            if service_info:
                service_name = service_info['name'] + '_' + service_info['namespace']
                KubeUtil.init_nested_dict(DEPENDENCY_DICT['Namespace'][ns], ['Service'])
                DEPENDENCY_DICT['Namespace'][ns]['Service'][service_name] = {
                    'name': service_info['name'],
                    'namespace': ns,
                    'id': KubeUtil.get_resource_id(service_name, "Services")
                }
        except Exception as e:
            AgentLogger.log(AgentLogger.KUBERNETES, 'Exception -> map_namespace_workloads -> {}'.format(e))
            traceback.print_exc()

    def __del__(self):
        global DEPENDENCY_DICT
        KubeUtil.clear_and_init_dict(DEPENDENCY_DICT)