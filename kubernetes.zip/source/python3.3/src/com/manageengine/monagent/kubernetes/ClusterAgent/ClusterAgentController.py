'''
@author: bharath.veerakumar

Created on Feb 20 2024
'''


import json
import os
import traceback
from flask.blueprints import Blueprint
from flask import request
from com.manageengine.monagent.kubernetes import KubeGlobal
from com.manageengine.monagent.kubernetes.ClusterAgent import ClusterAgentUtil
from com.manageengine.monagent.kubernetes.Logging import KubeLogger

blp = Blueprint("ParsedDataBlp", __name__)


@blp.route("/pd/<data_type>")
def get_parsed_data(data_type):
    if data_type in KubeGlobal.DATA_TYPE_PARSED_FILE_MAP:
        # constructing the file path for requested data_type
        file_path = KubeGlobal.PARSED_DATA_FOLDER_PATH + '/{}'.format(KubeGlobal.DATA_TYPE_PARSED_FILE_MAP[data_type])

        # checking if that file is in cache (1 min TTL)
        parsed_data = ClusterAgentUtil.read_json_from_file(file_path)
        if parsed_data:
            return parsed_data

        # checking KSM api response exists in cache or not (1 min TTL)
        # ksm_needed query param is required for this view function becoz it handles multiple data types
        parsed_data = KubeGlobal.DATA_TYPE_METHOD_MAP[data_type][0](KubeGlobal.DATA_TYPE_METHOD_MAP[data_type][1], ClusterAgentUtil.get_ksm_api_resp()) if request.args.get("ksm_needed") == "true" else KubeGlobal.DATA_TYPE_METHOD_MAP[data_type][0](KubeGlobal.DATA_TYPE_METHOD_MAP[data_type][1])

        # finally, storing the parsed data to cache
        if parsed_data:
            with open(file_path, 'w') as write_obj:
                write_obj.write(json.dumps(parsed_data))
            return parsed_data
    else:
        return "Data Type not Found", 404
    return "Error found in Cluster Agent Service !!!", 500


@blp.route("/pd/get_dc_json/<dc_name>")
def get_aggregation_data(dc_name):
    dc_obj = KubeGlobal.CLUSTER_AGENT_DC_OBJS_LIST[dc_name]
    if dc_obj.is_pre_parsing_needed:
        # constructing the file path for requested data_type
        file_path = KubeGlobal.PARSED_DATA_FOLDER_PATH + '/{}'.format(KubeGlobal.DATA_TYPE_PARSED_FILE_MAP[dc_name])

        # checking if that file is in cache (1 min TTL)
        parsed_data = ClusterAgentUtil.read_json_from_file(file_path)
        if parsed_data:
            return parsed_data

    return dc_obj.dc_class(dc_obj).get_data_for_cluster_agent()


@blp.route("/pd/node_base_ksm")
def get_node_base_ksm():
    try:
        node_name = request.args.get("node_name")
        if not node_name:
            return "node_name param missing !!!", 401

        node_base_ksm = ClusterAgentUtil.read_json_from_file(
            KubeGlobal.PARSED_DATA_FOLDER_PATH + '/{}'.format(KubeGlobal.DATA_TYPE_PARSED_FILE_MAP['node_base_ksm'])
        )

        # checking if the node_base_ksm file exists & nodes resources are present in cache
        if node_base_ksm and node_name in node_base_ksm:
            return node_base_ksm[node_name]

        # checking if npc_ksm file is in cache
        npc_ksm = ClusterAgentUtil.read_json_from_file(
            KubeGlobal.PARSED_DATA_FOLDER_PATH + '/{}'.format(KubeGlobal.DATA_TYPE_PARSED_FILE_MAP['npc_ksm'])
        )

        # if not, then initiate the parsing for npc ksm
        if not npc_ksm:
            ksm_data = ClusterAgentUtil.get_ksm_api_resp()
            npc_ksm = KubeGlobal.DATA_TYPE_METHOD_MAP['npc_ksm'][0](KubeGlobal.DATA_TYPE_METHOD_MAP['npc_ksm'][1], ksm_data)

        # filtering the node base resources (pod, cont) from npc ksm
        filtered_dict = {}
        for key, val in npc_ksm.items():
            filtered_dict[key] = {}
            try:
                for inner_key, inner_val in val.items():
                    if inner_val.get("No") == node_name:
                        filtered_dict[key][inner_key] = inner_val
            except Exception:
                pass

        return filtered_dict
    except Exception as e:
        KubeLogger.log(KubeLogger.KUBERNETES, "Exception -> {}".format(e))
    return "Not Found", 404


@blp.route("/ca/health_check")
def cluster_agent_healthcheck():
    return "Cluster Agent Running Successfully", 200


@blp.route("/ca/initiate_agent_upgrade")
def handle_upgrade():
    try:
        # if upgrade lock file exists and the last modified time is > 5 mins, then it is removed
        # After the removal, the main process will get exited for pod restart.
        if os.path.exists(KubeGlobal.CLUSTER_AGENT_UPGRADE_LOCK_FILE) and not ClusterAgentUtil.check_last_mtime(KubeGlobal.CLUSTER_AGENT_UPGRADE_LOCK_FILE, 300):
            os.remove(KubeGlobal.CLUSTER_AGENT_UPGRADE_LOCK_FILE)
            return "Successfully removed the upgrade flag file"
    except Exception as e:
        traceback.print_exc()
        KubeLogger.log(KubeLogger.KUBERNETES, "Exception -> initiate_agent_upgrade -> {}".format(e))
    return "Upgrade File not Found or not Eligible to proceed", 400


@blp.route("/ca/version")
def get_version():
    return KubeGlobal.CLUSTER_AGENT_VERSION
