import json
import os
import traceback
from flask.blueprints import Blueprint
from flask import request
from com.manageengine.monagent.kubernetes import KubeGlobal, KubeUtil
from com.manageengine.monagent.kubernetes.Logging import KubeLogger
from com.manageengine.monagent.kubernetes.Collector import ClusterMetricsAggregator

blp = Blueprint("ParsedDataBlp", __name__)


@blp.route("/pd/<data_type>")
def get_parsed_data(data_type):
    if data_type in KubeGlobal.DATA_TYPE_PARSED_FILE_MAP:
        # constructing the file path for requested data_type
        file_path = KubeGlobal.PARSED_DATA_FOLDER_PATH + '/{}'.format(KubeGlobal.DATA_TYPE_PARSED_FILE_MAP[data_type])

        # checking if that file is in cache (1 min TTL)
        parsed_data = KubeUtil.read_json_from_file(file_path)
        if parsed_data:
            return parsed_data

        # checking KSM api response exists in cache or not (1 min TTL)
        # ksm_needed query param is required for this view function becoz it handles multiple data types
        ksm_data = None
        if request.args.get("ksm_needed") == "true":
            KubeUtil.get_ksm_api_resp(ksm_data)
            parsed_data = KubeGlobal.DATA_TYPE_METHOD_MAP[data_type][0](KubeGlobal.DATA_TYPE_METHOD_MAP[data_type][1], ksm_data)
        else:
            parsed_data = KubeGlobal.DATA_TYPE_METHOD_MAP[data_type][0](KubeGlobal.DATA_TYPE_METHOD_MAP[data_type][1])

        # finally, storing the parsed data to cache
        if parsed_data:
            with open(file_path, 'w') as write_obj:
                write_obj.write(json.dumps(parsed_data))
            return parsed_data
    else:
        return "Data Type not Found", 404
    return "Error found in Cluster Agent Service !!!", 500


@blp.route("/pd/cma")
def get_aggregation_data():
    # checking npc_ksm is exists in cache (npc_ksm is required for aggregation)
    file_path = KubeGlobal.PARSED_DATA_FOLDER_PATH + '/{}'.format(KubeGlobal.DATA_TYPE_PARSED_FILE_MAP['npc_ksm'])
    npc_ksm = KubeUtil.read_json_from_file(file_path)

    # initiate npc_ksm data parsing if not exists in cache
    if not npc_ksm:
        ksm_data = None
        KubeUtil.get_ksm_api_resp(ksm_data)
        npc_ksm = KubeGlobal.DATA_TYPE_METHOD_MAP['npc_ksm'][0](KubeGlobal.DATA_TYPE_METHOD_MAP['npc_ksm'][1], ksm_data)

    KubeUtil.clear_and_init_dict(ClusterMetricsAggregator.FINAL_METRIC_DICT)
    ClusterMetricsAggregator.execute_metrics_aggregator_tasks(npc_ksm)
    return ClusterMetricsAggregator.FINAL_METRIC_DICT


@blp.route("/pd/node_base_ksm")
def get_node_base_ksm():
    try:
        node_name = request.args.get("node_name")
        if not node_name:
            return "node_name param missing !!!", 401

        file_path = KubeGlobal.PARSED_DATA_FOLDER_PATH + '/{}'.format(KubeGlobal.DATA_TYPE_PARSED_FILE_MAP['npc_ksm'])

        npc_ksm = KubeUtil.read_json_from_file(file_path)

        if not npc_ksm:
            ksm_data = None
            KubeUtil.get_ksm_api_resp(ksm_data)
            npc_ksm = KubeGlobal.DATA_TYPE_METHOD_MAP['npc_ksm'][0](KubeGlobal.DATA_TYPE_METHOD_MAP['npc_ksm'][1], ksm_data)

        filtered_dict = {}
        for key, val in npc_ksm.items():
            if type(val) == dict:
                filtered_dict[key] = {}
                for inner_key, inner_val in val.items():
                    if type(inner_val) == dict:
                        if inner_val.get("No") == node_name:
                            filtered_dict[key][inner_key] = inner_val

        return filtered_dict
    except Exception as e:
        KubeLogger.log(KubeLogger.KUBERNETES, "Exception -> {}".format(e))
    return "Not Found", 404


@blp.route("/ca/health_check")
def network_healthcheck():
    return "Cluster Agent Running Successfully", 200


@blp.route("/ca/initiate_agent_upgrade")
def handle_upgrade():
    try:
        if os.path.exists(KubeGlobal.CLUSTER_AGENT_UPGRADE_LOCK_FILE) and not KubeUtil.check_last_mtime(KubeGlobal.CLUSTER_AGENT_UPGRADE_LOCK_FILE, 300):
            os.remove(KubeGlobal.CLUSTER_AGENT_UPGRADE_LOCK_FILE)
            return "Successfully removed the upgrade flag file"
    except Exception:
        traceback.print_exc()
    return "Upgrade File not Found or not Eligible to proceed", 400


@blp.route("/ca/version")
def get_version():
    return KubeGlobal.CLUSTER_AGENT_VERSION

@blp.route("/ca/stats")
def get_stats():
    return KubeGlobal.CLUSTER_AGENT_STATS
