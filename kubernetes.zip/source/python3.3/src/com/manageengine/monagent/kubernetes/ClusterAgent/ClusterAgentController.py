import json
import os
import traceback
from flask.blueprints import Blueprint
from flask import request
from com.manageengine.monagent.kubernetes import KubeGlobal, KubeUtil
from com.manageengine.monagent.kubernetes.ClusterAgent import ClusterAgentUtil
from com.manageengine.monagent.kubernetes.Logging import KubeLogger
from com.manageengine.monagent.kubernetes.Collector.ClusterMetricsAggregator import ClusterMetricsAggregator
from com.manageengine.monagent.kubernetes.Collector.DataCollectorWrapper import DCRequisites

blp = Blueprint("ParsedDataBlp", __name__)


@blp.route("/pd/<data_type>")
def get_parsed_data(data_type):
    if data_type in KubeGlobal.DATA_TYPE_PARSED_FILE_MAP:
        # constructing the file path for requested data_type
        file_path = KubeGlobal.PARSED_DATA_FOLDER_PATH + '/{}'.format(KubeGlobal.DATA_TYPE_PARSED_FILE_MAP[data_type])

        # checking if that file is in cache (1 min TTL)
        parsed_data = ClusterAgentUtil.read_json_from_file(file_path)
        if parsed_data:
            return parsed_data

        # checking KSM api response exists in cache or not (1 min TTL)
        # ksm_needed query param is required for this view function becoz it handles multiple data types
        if request.args.get("ksm_needed") == "true":
            ksm_data = ClusterAgentUtil.get_ksm_api_resp()
            parsed_data = KubeGlobal.DATA_TYPE_METHOD_MAP[data_type][0](KubeGlobal.DATA_TYPE_METHOD_MAP[data_type][1], ksm_data)
        else:
            parsed_data = KubeGlobal.DATA_TYPE_METHOD_MAP[data_type][0](KubeGlobal.DATA_TYPE_METHOD_MAP[data_type][1])

        # finally, storing the parsed data to cache
        if parsed_data:
            with open(file_path, 'w') as write_obj:
                write_obj.write(json.dumps(parsed_data))
            return parsed_data
    else:
        return "Data Type not Found", 404
    return "Error found in Cluster Agent Service !!!", 500


@blp.route("/pd/cma")
def get_aggregation_data():
    # constructing the file path for requested data_type
    file_path = KubeGlobal.PARSED_DATA_FOLDER_PATH + '/{}'.format(KubeGlobal.DATA_TYPE_PARSED_FILE_MAP["cma"])

    # checking if that file is in cache (1 min TTL)
    parsed_data = ClusterAgentUtil.read_json_from_file(file_path)
    if parsed_data:
        return parsed_data

    dc_requisites_obj = DCRequisites()
    dc_requisites_obj.set_dc_name(ClusterMetricsAggregator.__name__)
    dc_requisites_obj.set_dc_class(ClusterMetricsAggregator)

    # checking npc_ksm is exists in cache (npc_ksm is required for aggregation)
    file_path = KubeGlobal.PARSED_DATA_FOLDER_PATH + '/{}'.format(KubeGlobal.DATA_TYPE_PARSED_FILE_MAP['npc_ksm'])
    npc_ksm = ClusterAgentUtil.read_json_from_file(file_path)

    # initiate npc_ksm data parsing if not exists in cache
    if not npc_ksm:
        ksm_data = ClusterAgentUtil.get_ksm_api_resp()
        npc_ksm = KubeGlobal.DATA_TYPE_METHOD_MAP['npc_ksm'][0](KubeGlobal.DATA_TYPE_METHOD_MAP['npc_ksm'][1], ksm_data)

    return ClusterMetricsAggregator(dc_requisites_obj, npc_ksm).initiate_dc()


@blp.route("/pd/node_base_ksm")
def get_node_base_ksm():
    try:
        node_name = request.args.get("node_name")
        if not node_name:
            return "node_name param missing !!!", 401

        node_base_ksm = ClusterAgentUtil.read_json_from_file(
            KubeGlobal.PARSED_DATA_FOLDER_PATH + '/{}'.format(KubeGlobal.DATA_TYPE_PARSED_FILE_MAP['node_base_ksm'])
        )

        if node_base_ksm and node_name in node_base_ksm:
            return node_base_ksm[node_name]

        npc_ksm = ClusterAgentUtil.read_json_from_file(
            KubeGlobal.PARSED_DATA_FOLDER_PATH + '/{}'.format(KubeGlobal.DATA_TYPE_PARSED_FILE_MAP['npc_ksm'])
        )

        if not npc_ksm:
            ksm_data = ClusterAgentUtil.get_ksm_api_resp()
            npc_ksm = KubeGlobal.DATA_TYPE_METHOD_MAP['npc_ksm'][0](KubeGlobal.DATA_TYPE_METHOD_MAP['npc_ksm'][1], ksm_data)

        filtered_dict = {}
        for key, val in npc_ksm.items():
            filtered_dict[key] = {}
            try:
                for inner_key, inner_val in val.items():
                    if inner_val.get("No") == node_name:
                        filtered_dict[key][inner_key] = inner_val
            except Exception:
                pass

        return filtered_dict
    except Exception as e:
        KubeLogger.log(KubeLogger.KUBERNETES, "Exception -> {}".format(e))
    return "Not Found", 404


@blp.route("/ca/health_check")
def network_healthcheck():
    return "Cluster Agent Running Successfully", 200


@blp.route("/ca/initiate_agent_upgrade")
def handle_upgrade():
    try:
        if os.path.exists(KubeGlobal.CLUSTER_AGENT_UPGRADE_LOCK_FILE) and not ClusterAgentUtil.check_last_mtime(KubeGlobal.CLUSTER_AGENT_UPGRADE_LOCK_FILE, 300):
            os.remove(KubeGlobal.CLUSTER_AGENT_UPGRADE_LOCK_FILE)
            return "Successfully removed the upgrade flag file"
    except Exception as e:
        traceback.print_exc()
        KubeLogger.log(KubeLogger.KUBERNETES, "Exception -> initiate_agent_upgrade -> {}".format(e))
    return "Upgrade File not Found or not Eligible to proceed", 400


@blp.route("/ca/version")
def get_version():
    return KubeGlobal.CLUSTER_AGENT_VERSION
