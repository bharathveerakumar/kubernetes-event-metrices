from com.manageengine.monagent.kubernetes.Collector.DataCollectorInterface import DataCollector
from com.manageengine.monagent.kubernetes.Parser import ParserFactory


class YAMLFetcher(DataCollector):
    def collect_data(self):
        self.final_json = {
            "DaemonSets": ParserFactory.get_json_parser('DaemonSets')().get_data(yaml=True),
            "Deployments": ParserFactory.get_json_parser("Deployments")().get_data(yaml=True),
            "StatefulSets": ParserFactory.get_json_parser("StatefulSets")().get_data(yaml=True),
            "HorizontalPodAutoscalers": ParserFactory.get_json_parser("HorizontalPodAutoscalers")().get_data(yaml=True),
            "Namespaces": ParserFactory.get_json_parser("Namespaces")().get_data(yaml=True),
            "Ingresses": ParserFactory.get_json_parser("Ingresses")().get_data(yaml=True),
            "PersistentVolumeClaim": ParserFactory.get_json_parser("PersistentVolumeClaim")().get_data(yaml=True),
            "PV": ParserFactory.get_json_parser("PV")().get_data(yaml=True),
            "Services": ParserFactory.get_json_parser("Services")().get_data(yaml=True),
            "Jobs": ParserFactory.get_json_parser("Jobs")().get_data(yaml=True),
            "DaemonSets1": ParserFactory.get_json_parser('DaemonSets')().get_data(yaml=True),
            "Deployments1": ParserFactory.get_json_parser("Deployments")().get_data(yaml=True),
            "StatefulSets1": ParserFactory.get_json_parser("StatefulSets")().get_data(yaml=True),
            "HorizontalPodAutoscalers1": ParserFactory.get_json_parser("HorizontalPodAutoscalers")().get_data(yaml=True),
            "Namespaces1": ParserFactory.get_json_parser("Namespaces")().get_data(yaml=True),
            "Ingresses1": ParserFactory.get_json_parser("Ingresses")().get_data(yaml=True),
            "PersistentVolumeClaim1": ParserFactory.get_json_parser("PersistentVolumeClaim")().get_data(yaml=True),
            "PV1": ParserFactory.get_json_parser("PV")().get_data(yaml=True),
            "Ser11vices": ParserFactory.get_json_parser("Services")().get_data(yaml=True),
            "Job1s1": ParserFactory.get_json_parser("Jobs")().get_data(yaml=True),
            "D1aemonSets1": ParserFactory.get_json_parser('DaemonSets')().get_data(yaml=True),
            "De1ployments1": ParserFactory.get_json_parser("Deployments")().get_data(yaml=True),
            "Sta1tefulSets1": ParserFactory.get_json_parser("StatefulSets")().get_data(yaml=True),
            "Hori1zontalPodAutoscalers1": ParserFactory.get_json_parser("HorizontalPodAutoscalers")().get_data(yaml=True),
            "Names1paces1": ParserFactory.get_json_parser("Namespaces")().get_data(yaml=True),
            "Ingres1ses1": ParserFactory.get_json_parser("Ingresses")().get_data(yaml=True),
            "Persist1entVolumeClaim1": ParserFactory.get_json_parser("PersistentVolumeClaim")().get_data(yaml=True),
            "PV11": ParserFactory.get_json_parser("PV")().get_data(yaml=True),
            "Ser1vices": ParserFactory.get_json_parser("Services")().get_data(yaml=True),
            "Jobs1": ParserFactory.get_json_parser("Jobs")().get_data(yaml=True)
        }
