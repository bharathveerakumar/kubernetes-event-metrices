import traceback
import copy

from com.manageengine.monagent.kubernetes.Collector.DataCollectorInterface import DataCollector
from com.manageengine.monagent.kubernetes.Parser import ParserFactory
from com.manageengine.monagent.kubernetes import KubeGlobal
from com.manageengine.monagent.kubernetes.Logging import KubeLogger as AgentLogger

LAST_CONFIG_ID = {}


class YAMLFetcher(DataCollector):
    def __init__(self, dc_requisites_obj):
        super().__init__(dc_requisites_obj)
        self.newly_added_types = []

    def get_request_params(self):
        return {'kube_ids': KubeGlobal.kubeIds}

    def get_data_for_cluster_agent(self, req_params=None):
        KubeGlobal.kubeIds = req_params['kube_ids']
        return super().get_data_for_cluster_agent()

    def get_newly_added_res_types(self):
        for res_type, resouces in KubeGlobal.kubeIds.items():
            if res_type in KubeGlobal.YAML_SUPPORTED_TYPES:
                if res_type not in LAST_CONFIG_ID:
                    self.newly_added_types.append(res_type)
                else:
                    for res_name in resouces:
                        if res_name not in LAST_CONFIG_ID[res_type]:
                            self.newly_added_types.append(res_type)
                            break
        if self.newly_added_types:
            AgentLogger.log(AgentLogger.KUBERNETES, "Newly added resource types for YAMLFetcher task - {}".format(self.newly_added_types))

    def collect_data(self):
        global LAST_CONFIG_ID
        try:
            self.get_newly_added_res_types()
            for res_type in self.newly_added_types:
                self.final_json[res_type] = ParserFactory.get_json_parser(res_type)().get_data(yaml=True)
        except Exception:
            traceback.print_exc()
        LAST_CONFIG_ID = copy.deepcopy(KubeGlobal.kubeIds)
