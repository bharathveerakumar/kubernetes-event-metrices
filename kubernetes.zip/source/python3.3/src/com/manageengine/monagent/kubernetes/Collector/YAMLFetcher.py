from com.manageengine.monagent.kubernetes.Collector.DataCollectorInterface import DataCollector
from com.manageengine.monagent.kubernetes.Parser import ParserFactory
from com.manageengine.monagent.kubernetes import KubeGlobal


class YAMLFetcher(DataCollector):
    def __init__(self, dc_requisites_obj):
        super().__init__(dc_requisites_obj)
        self.ca_method_type = 'POST'

    def get_request_params(self):
        return {'kube_ids': KubeGlobal.kubeIds}

    def get_data_for_cluster_agent(self, req_params=None):
        KubeGlobal.kubeIds = req_params['kube_ids']
        return super().get_data_for_cluster_agent()

    def collect_data(self):
        self.final_json = {
            "DaemonSets": ParserFactory.get_json_parser('DaemonSets')().get_data(yaml=True),
            "Deployments": ParserFactory.get_json_parser("Deployments")().get_data(yaml=True),
            "StatefulSets": ParserFactory.get_json_parser("StatefulSets")().get_data(yaml=True),
            "HorizontalPodAutoscalers": ParserFactory.get_json_parser("HorizontalPodAutoscalers")().get_data(yaml=True),
            "Ingresses": ParserFactory.get_json_parser("Ingresses")().get_data(yaml=True),
            "PersistentVolumeClaim": ParserFactory.get_json_parser("PersistentVolumeClaim")().get_data(yaml=True),
            "PV": ParserFactory.get_json_parser("PV")().get_data(yaml=True),
            "Services": ParserFactory.get_json_parser("Services")().get_data(yaml=True)
        }
        node_obj = ParserFactory.get_json_parser("Nodes")().get_data(yaml=True)
        node_obj.api_url = KubeGlobal.apiEndpoint + KubeGlobal.API_ENDPOINT_RES_NAME_MAP['Nodes']
        self.final_json['Nodes'] = node_obj.get_data(yaml=True)
