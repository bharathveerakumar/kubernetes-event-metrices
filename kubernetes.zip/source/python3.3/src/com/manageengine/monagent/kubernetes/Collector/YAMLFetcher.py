from com.manageengine.monagent.kubernetes.Collector.DataCollectorInterface import DataCollector
from com.manageengine.monagent.kubernetes.Parser import ParserFactory


class YAMLFetcher(DataCollector):
    def collect_data(self):
        self.final_json = {
            "DaemonSets": ParserFactory.get_json_parser('DaemonSets')().get_data(yaml=True),
            "Deployments": ParserFactory.get_json_parser("Deployments")().get_data(yaml=True),
            "StatefulSets": ParserFactory.get_json_parser("StatefulSets")().get_data(yaml=True),
            "HorizontalPodAutoscalers": ParserFactory.get_json_parser("HorizontalPodAutoscalers")().get_data(yaml=True),
            "Namespaces": ParserFactory.get_json_parser("Namespaces")().get_data(yaml=True),
            "Ingresses": ParserFactory.get_json_parser("Ingresses")().get_yaml_data(),
            "PersistentVolumeClaim": ParserFactory.get_json_parser("PersistentVolumeClaim")().get_yaml_data(),
            "PV": ParserFactory.get_json_parser("PV")().get_yaml_data(),
            "Services": ParserFactory.get_json_parser("Services")().get_yaml_data(),
            "Jobs": ParserFactory.get_json_parser("Jobs")().get_yaml_data()
        }
