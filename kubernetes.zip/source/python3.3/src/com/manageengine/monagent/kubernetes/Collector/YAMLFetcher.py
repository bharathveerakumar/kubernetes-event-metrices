import traceback
import copy

from com.manageengine.monagent.kubernetes.Collector.DataCollectorInterface import DataCollector
from com.manageengine.monagent.kubernetes.Parser import ParserFactory
from com.manageengine.monagent.kubernetes import KubeGlobal

LAST_CONFIG_ID = {}


class YAMLFetcher(DataCollector):
    def __init__(self, dc_requisites_obj):
        super().__init__(dc_requisites_obj)
        self.ca_request_type = 'POST'

    def get_request_params(self):
        return {'kube_ids': KubeGlobal.kubeIds}

    def get_data_for_cluster_agent(self, req_params=None):
        KubeGlobal.kubeIds = req_params['kube_ids']
        return super().get_data_for_cluster_agent()

    def get_newly_added_res_types(self):
        newly_added_types = []
        for res_type, res_name in KubeGlobal.kubeIds.items():
            if res_type not in LAST_CONFIG_ID or res_name not in LAST_CONFIG_ID[res_type]:
                newly_added_types.append(res_type)
        return newly_added_types

    def collect_data(self):
        global LAST_CONFIG_ID
        try:
            for res_type in self.get_newly_added_res_types():
                self.final_json[res_type] = ParserFactory.get_json_parser(res_type)().get_data(yaml=True)
        except Exception:
            traceback.print_exc()
        LAST_CONFIG_ID = copy.deepcopy(KubeGlobal.kubeIds)
