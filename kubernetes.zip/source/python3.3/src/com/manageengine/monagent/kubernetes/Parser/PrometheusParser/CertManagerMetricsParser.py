from com.manageengine.monagent.kubernetes.Parser.PrometheusParserInterface import PrometheusParser

class CertManagerMetricsParser(PrometheusParser):
    def __init__(self):
        super().__init__('http://127.0.0.1:8080/api/v1/namespaces/cert-manager/services/cert-manager:9402/proxy/metrics')
        self.parser_config = {
            'certmanager_certificate_expiration_timestamp_seconds': [
                {
                    'short_name': 'expiry_seconds',
                    'group_name': 'Certificates',
                    'group_labels': ['name', 'namespace'],
                    'labels': {
                        'issuer_kind': 'issuer_kind',
                        'issuer_name': 'issuer_name',
                        'namespace': 'NS',
                        'name': 'Na'
                    },
                }
            ],
            'certmanager_certificate_ready_status': [
                {
                    'short_name': 'ready_status',
                    'group_name': 'Certificates',
                    'group_labels': ['name', 'namespace'],
                    'match_labels': {
                        'condition': 'True'
                    }
                }
            ],
            'certmanager_certificate_renewal_timestamp_seconds': [
                {
                    'short_name': 'renewal_timestamp_seconds',
                    'group_name': 'Certificates',
                    'group_labels': ['name', 'namespace']
                }
            ],
            'certmanager_controller_sync_call_count': [
                {
                    'short_name': 'sync_call_count',
                    'group_name': 'Controllers',
                    'group_labels': ['controller'],
                },
                {
                    'short_name': 'sync_call_count',
                    'group_name': '',
                    'sum': ['', 'sync_call_count', 'sum_only'],
                }
            ],
            'certmanager_http_acme_client_request_count': [
                {
                    'short_name': 'acme_request_count',
                    'group_name': 'acme_status_code',
                    'group_labels': ['status'],
                    'labels': {
                        'status': 'status',
                    }
                },
                {
                    'short_name': 'acme_request_count',
                    'group_name': 'acme_method',
                    'group_labels': ['method'],
                    'labels': {
                        'method': 'method',
                    }
                },
                {
                    'short_name': 'acme_request_count',
                    'group_name': 'acme_host',
                    'group_labels': ['host'],
                    'labels': {
                        'host': 'host',
                    }
                },
                {
                    'short_name': 'acme_client_request_count',
                    'group_name': '',
                    'sum': ['', 'acme_client_request_count', 'sum_only'],
                }
            ],
            'certmanager_http_acme_client_request_duration_seconds': [
                {
                    'short_name': 'acme_request_duration',
                    'group_name': 'acme_status_code',
                    'group_labels': ['status'],
                    'labels': {
                        'status': 'status',
                    }
                },
                {
                    'short_name': 'acme_request_duration',
                    'group_name': 'acme_method',
                    'group_labels': ['method'],
                    'labels': {
                        'method': 'method',
                    }
                },
                {
                    'short_name': 'acme_request_duration',
                    'group_name': 'acme_host',
                    'group_labels': ['host'],
                    'labels': {
                        'host': 'host',
                    }
                },
                {
                    'short_name': 'acme_client_request_duration',
                    'group_name': '',
                    'sum': ['', 'acme_client_request_duration', 'sum_only'],
                }
            ]
        }
        self.get_data()
