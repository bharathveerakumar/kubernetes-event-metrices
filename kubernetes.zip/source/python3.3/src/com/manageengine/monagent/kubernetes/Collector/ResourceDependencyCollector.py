from com.manageengine.monagent.kubernetes.Collector.DataCollectorInterface import DataCollector
from com.manageengine.monagent.kubernetes.Parser.ParserFactory import get_prometheus_parser
from com.manageengine.monagent.kubernetes.ClusterAgent import ClusterAgentUtil
from com.manageengine.monagent.kubernetes import KubeUtil, KubeGlobal

import traceback


class ResourceDependency(DataCollector):
    def __init__(self, dc_requisites_obj):
        super().__init__(dc_requisites_obj)
        self.controller_relational = None
        self.svc_relational = None
        self.pod_name = None
        self.namespace = None
        self.pod_name = None
        self.final_json = {'resources': {}, 'Ingress': {}}

    def collect_data(self):
        self.controller_relational = get_prometheus_parser('ResourceDependency')().get_data()
        KubeUtil.get_api_data_by_limit(
            KubeGlobal.apiEndpoint + KubeGlobal.API_ENDPOINT_RES_NAME_MAP['Services'],
            self.hash_service_selectors,
            self.svc_relational
        )
        self.build_container_dependency()

    def get_data_for_cluster_agent(self, req_params=None):
        self.controller_relational = ClusterAgentUtil.get_parsed_data_for_ca("resource_dependency_ksm")
        self.svc_relational = ClusterAgentUtil.get_parsed_data_for_ca("service_rs")
        self.build_container_dependency()
        return self.final_json

    def build_container_dependency(self):
        for pod_name, pod_value in self.controller_relational['Pod'].items():
            self.namespace = pod_value[0]['ns']
            self.pod_name = pod_name
            self.final_json['resources'][self.pod_name] = {
                'Namespace': self.namespace,
                'Container': ['{}_{}_{}'.format(cont_name['cont_name'], self.pod_name, self.namespace) for cont_name in self.controller_relational['Container'][self.pod_name]],
                'Node': pod_value[0]['node']
            }
            self.identify_owner_controller()
            self.build_svc_relation()
            self.build_pv_relation()

    def identify_owner_controller(self):
        if self.pod_name in self.controller_relational['Owner']:
            owner_kind = self.controller_relational['Owner'][self.pod_name][0].get('kind')
            owner_name = self.controller_relational['Owner'][self.pod_name][0].get('owner_name') + '_' + self.namespace
            if owner_kind == 'ReplicaSet':
                if owner_name in self.controller_relational['ReplicaSet'] and self.controller_relational['ReplicaSet'][owner_name][0]['owner_kind'] == 'Deployment':
                    deploy_name = self.controller_relational['ReplicaSet'][owner_name][0]['owner_name'] + '_' + self.namespace
                    self.final_json['resources'][self.pod_name]['Deployment'] = deploy_name
                    self.check_hpa_exists(deploy_name, 'Deployment')
            elif owner_kind == 'StatefulSet':
                self.final_json['resources'][self.pod_name]['Statefulset'] = owner_name
                self.check_hpa_exists(owner_name, owner_kind)
            elif owner_kind == 'DaemonSet':
                self.final_json['resources'][self.pod_name]['Daemonset'] = owner_name

    def build_svc_relation(self):
        if self.pod_name in self.svc_relational:
            self.final_json['resources'][self.pod_name]['Service'] = [svc + '_' + self.namespace for svc in self.svc_relational[self.pod_name]]

    def build_pv_relation(self):
        if self.pod_name in self.controller_relational['PVC']:
            self.final_json['resources'][self.pod_name]['PVC'] = []
            for pvc_name in self.controller_relational['PVC'][self.pod_name]:
                pvc = pvc_name + '_' + self.namespace
                if pvc in self.controller_relational['PV']:
                    self.final_json['resources'][self.pod_name]['PVC'].append({pvc: self.controller_relational['PV'][pvc]['pv']})

    def check_hpa_exists(self, child_name, child_kind):
        if child_name in self.controller_relational['HPA'] and self.controller_relational['HPA'][child_name][0]['child_kind'] == child_kind:
            self.final_json['resources'][self.pod_name]['HPA'] = self.controller_relational['HPA'][child_name][0]['hpa'] + '_' + self.namespace

    def hash_service_selectors(self, service_data, lookup_dict):
        try:
            for val in service_data['items']:
                try:
                    name = val['metadata']['name']
                    ns = val['metadata']['namespace']
                    if 'spec' in val and 'selector' in val['spec']:
                        sel = val['spec']['selector']
                        match_labels = []
                        for key, value in sel.items():
                            match_labels.append("{}%3D{}".format(key, value))

                        status, api_resp = KubeUtil.curl_api_with_token(KubeGlobal.apiEndpoint + "/api/v1/namespaces/{}/pods?labelSelector={}".format(ns, ",".join(match_labels)))
                        if status == 200:
                            for pod_value in api_resp["items"]:
                                pod_name = pod_value['metadata']['name'] + "_" + ns
                                if pod_name not in lookup_dict:
                                    lookup_dict[pod_name] = []
                                lookup_dict[pod_name].append(name)
                except Exception:
                    continue
        except Exception as e:
            traceback.print_exc()

