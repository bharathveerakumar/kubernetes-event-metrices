from com.manageengine.monagent.kubernetes.Collector.DataCollectorInterface import DataCollector
from com.manageengine.monagent.kubernetes.Parser.ParserFactory import get_prometheus_parser
from com.manageengine.monagent.kubernetes.ClusterAgent import ClusterAgentUtil
from com.manageengine.monagent.kubernetes import KubeUtil, KubeGlobal

import traceback


class ResourceDependency(DataCollector):
    def __init__(self, dc_requisites_obj):
        super().__init__(dc_requisites_obj)
        self.controller_relational = None
        self.svc_relational = None
        self.container_name = None
        self.namespace = None
        self.pod_name = None

    def collect_data(self):
        self.controller_relational = get_prometheus_parser('ResourceDependency')().get_data()
        KubeUtil.get_api_data_by_limit(
            KubeGlobal.apiEndpoint + KubeGlobal.API_ENDPOINT_RES_NAME_MAP['Services'],
            self.hash_service_selectors,
            self.svc_relational
        )
        self.build_container_dependency()

    def get_data_for_cluster_agent(self, req_params=None):
        self.controller_relational = ClusterAgentUtil.get_parsed_data_for_ca("resource_dependency_ksm")
        self.svc_relational = ClusterAgentUtil.get_parsed_data_for_ca("service_rs")
        self.build_container_dependency()
        return self.final_json

    def build_container_dependency(self):
        for container_name, container_value in self.controller_relational['Container'].items():
            self.container_name = container_name
            self.namespace = container_value['ns']
            self.pod_name = container_value['pod_name'] + '_' + self.namespace
            self.final_json[container_name] = {
                'Namespace': self.namespace,
                'Pod': self.pod_name,
                'Node': self.controller_relational['Node'][self.pod_name]['node']
            }
            self.identify_owner_controller()
            self.build_svc_relation()
            self.build_pv_relation()

    def identify_owner_controller(self):
        if self.pod_name in self.controller_relational['Pod']:
            owner_kind = self.controller_relational['Pod'][self.pod_name].get('kind')
            owner_name = self.controller_relational['Pod'][self.pod_name].get('owner_name') + '_' + self.namespace
            if owner_kind == 'ReplicaSet':
                if owner_name in self.controller_relational['ReplicaSet'] and self.controller_relational['ReplicaSet'][owner_name]['owner_kind'] == 'Deployment':
                    deploy_name = self.controller_relational['ReplicaSet'][owner_name]['owner_name'] + '_' + self.namespace
                    self.final_json[self.container_name]['Deployment'] = deploy_name
                    self.check_hpa_exists(deploy_name, 'Deployment')
            elif owner_kind == 'StatefulSet':
                self.final_json[self.container_name]['Statefulset'] = owner_name
                self.check_hpa_exists(owner_name, owner_kind)
            elif owner_kind == 'DaemonSet':
                self.final_json[self.container_name]['Daemonset'] = owner_name

    def build_svc_relation(self):
        if self.pod_name in self.svc_relational:
            svc_name = self.svc_relational[self.pod_name]['name'] + '_' + self.namespace
            self.final_json[self.container_name]['Service'] = svc_name

            if 'Ingress' in self.controller_relational and svc_name in self.controller_relational['Ingress']:
                self.final_json[self.container_name]['Ingress'] = self.controller_relational['Ingress'][svc_name]['ingress'] + '_' + self.namespace

    def build_pv_relation(self):
        if self.pod_name in self.controller_relational['PVC']:
            pvc = self.controller_relational['PVC'][self.pod_name]['pvc'] + '_' + self.namespace
            self.final_json[self.container_name]['PVC'] = pvc
            if pvc in self.controller_relational['PV']:
                self.final_json[self.container_name]['PV'] = self.controller_relational['PV'][pvc]['pv']

    def check_hpa_exists(self, child_name, child_kind):
        if child_name in self.controller_relational['HPA'] and self.controller_relational['HPA'][child_name]['child_kind'] == child_kind:
            self.final_json[self.container_name]['HPA'] = self.controller_relational['HPA'][child_name]['hpa'] + '_' + self.namespace

    def hash_service_selectors(self, service_data, lookup_dict):
        try:
            for val in service_data['items']:
                try:
                    name = val['metadata']['name']
                    ns = val['metadata']['namespace']
                    if 'spec' in val and 'selector' in val['spec']:
                        sel = val['spec']['selector']
                        match_labels = []
                        for key, value in sel.items():
                            match_labels.append("{}%3D{}".format(key, value))

                        status, api_resp = KubeUtil.curl_api_with_token(KubeGlobal.apiEndpoint + "/api/v1/namespaces/{}/pods?labelSelector={}".format(ns, ",".join(match_labels)))
                        if status == 200:
                            for pod_value in api_resp["items"]:
                                lookup_dict[pod_value['metadata']['name'] + "_" + ns] = {
                                    'name': name,
                                    'namespace': ns
                                }
                except Exception:
                    continue
        except Exception as e:
            traceback.print_exc()

