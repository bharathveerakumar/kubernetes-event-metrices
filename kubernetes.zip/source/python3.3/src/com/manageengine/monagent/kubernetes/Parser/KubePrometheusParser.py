import traceback
import json
from com.manageengine.monagent.kubernetes.Logging import KubeLogger as AgentLogger
from com.manageengine.monagent.kubernetes import KubeUtil
from com.manageengine.monagent.kubernetes import KubeGlobal
try:
    from prometheus_client.parser import text_string_to_metric_families
    AgentLogger.log(AgentLogger.KUBERNETES,'importing prometheus client success')
    prometheusAvailable = True
except Exception as e:
    AgentLogger.log(AgentLogger.KUBERNETES,'Exception while importing prometheus client - {0}'.format(e))
    prometheusAvailable = False

valList = None
dcErrors = {}

def load_k8s_perf_xml(xmlFile, ksm_api_data = None):
    global valList, dcErrors
    finalDataDic = {}
    try:
        if prometheusAvailable:
            valList = perfData = None
            KubeUtil.clear_and_init_dict(finalDataDic)
            KubeUtil.clear_and_init_dict(dcErrors)
            
            root = KubeUtil.load_xml_root_from_file(xmlFile)
            if root is not None:
                #iterate apis
                for api in root.findall('api'):
                    try:
                        url = api.get('url')
                        useToken = api.get('UseToken')
                        replacedUrl = KubeUtil.replace_tokens(url)
                        AgentLogger.log(AgentLogger.KUBERNETES,'replaced url - ' + replacedUrl)

                        if not ksm_api_data:
                            status, perfData = KubeUtil.curl_api_with_token(replacedUrl) if useToken else KubeUtil.curl_api_without_token(replacedUrl)

                            #add to DcErrors
                            if status != 200:
                                dcErrors[url] = status
                                if "cadvisor" in url:
                                    node_name = KubeGlobal.nodeName
                                    url = KubeGlobal.apiEndpoint + '/api/v1/nodes/{}/proxy/metrics/cadvisor'.format(node_name)
                                    status, perfData = KubeUtil.curl_api_with_token(url)

                        if not perfData:
                            perfData = ksm_api_data

                        if perfData:
                            prom_parser = text_string_to_metric_families(perfData)
                            valList = list(prom_parser)
                            KubeUtil.clear_and_init_dict(prom_parser)
                            parse_group(api.findall("Group"), finalDataDic)
                        else:
                            AgentLogger.log(AgentLogger.KUBERNETES,'LoadK8sPerfXml -> perf data not present')
                    except Exception as e:
                        traceback.print_exc()
                    
                #addDCErrorsTodata
                finalDataDic["DCErrors"] = dcErrors
        else:
            AgentLogger.log(AgentLogger.KUBERNETES,'LoadK8sPerfXml -> skipping dc - prometheus not available')
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'LoadK8sPerfXml -> Exception -> {0}'.format(e))
    KubeUtil.clear_and_init_dict(dcErrors)
    return finalDataDic

def parse_group(groups, finalDataDic):
    AgentLogger.debug(AgentLogger.KUBERNETES,' inside parsegroups.....')
    try:
        #if groups and valList:
        for group in groups:
            groupName = group.get('Name')
            mandatoryLabel = group.get('mandatory')
            AgentLogger.debug(AgentLogger.KUBERNETES,'ParseGroup -> groupName - {0}'.format(groupName))
            groupDic = get_from_data_dic(groupName, finalDataDic)
                          
            idGroupName = group.get('IDGroupName')
            if not idGroupName:
                idGroupName = groupName

            #process labels
            labelRootList = []
            labelXmlDic = {}
            label = group.find("Labels")
            if label is not None:
                labelRootList,labelXmlDic = process_labels(label)
                
            #process Metrics
            AgentLogger.debug(AgentLogger.KUBERNETES,'ParseGroup -> going to parse metrics')
            process_metrics(group.findall("Metric"), labelRootList, labelXmlDic, groupDic,mandatoryLabel)

            #update groupDic in finalDataDic
            finalDataDic[groupName] = groupDic
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'Exception -> ParseGroup -> {0}'.format(e))
        
def process_metrics(metrics,labelRootList,labelXmlDic,groupDic,mandatoryLabel=None):
    try:
        AgentLogger.debug(AgentLogger.KUBERNETES,'inside parse metrics')
        if True:
            for metric in metrics:
                metricName = metric.get('Name')
                metricShortName = metric.get('ShortName')
                hasLabels = metric.get('HasLabels')
                metricFamily = metric.get('Family')
                adder = metric.get('add')
                expression = metric.get('expr')
                round_off = metric.get("round")
                rate = metric.get("rate")
                rate_param_identifier = metric.get("identifier")
                valTag = metric.find('Value')
                countTag = metric.find('Count')
                mapTag = metric.find('Map')
                hasSampleFilter = metric.get('sampleFilter')
                matchName = metric.get('matchName')
                matchValue = metric.get('matchValue')

                valCheck = False
                countCheck = False
                mapCheck = False
                countDic = None
                valLabel = None

                if not metricFamily:
                    metricFamily = metricName

                if valTag is not None:
                    valCheck = True
                    valCond = valTag.get('Condition')
                    valThreshold = valTag.get('Threshold')
                    valLabel = valTag.get('Label')

                if countTag is not None:
                    countCheck = True
                    countDic = {}
                    countShortName = countTag.get('ShortName')
                    countLabel = countTag.get('Label')

                if mapTag is not None:
                    mapCheck = True
                    mapName = mapTag.get('Name')
                    mapKeyLabel = mapTag.get('KeyLabel')
                    mapValLabel = mapTag.get('ValLabel')

                #process data
                for family in valList:
                    if metricFamily != family.name:
                        continue
                    for sample in family.samples:
                        sample_name = sample.name
                        if "_total" in sample_name:
                            sample_name = sample_name.strip("_total")
                        try:
                            if sample_name == metricName:
                                labelDataDic = sample[1]
                                val = sample[2]
                                if hasSampleFilter and not (matchName in labelDataDic and labelDataDic[matchName] == matchValue):
                                    continue

                                if mandatoryLabel:
                                    if mandatoryLabel in labelDataDic and not labelDataDic[mandatoryLabel]:
                                        continue

                                if hasLabels=="True":
                                    rootVal = get_label_root_name_val(labelRootList,labelDataDic)
                                    if rate:
                                        if rate_param_identifier in labelDataDic:
                                            name = labelDataDic[rate_param_identifier] + "_" + metricShortName
                                            val = KubeUtil.get_counter_value(name,val)

                                    if expression:
                                        AgentLogger.debug(AgentLogger.KUBERNETES,'metric name :: {} :: sample name :: {}'.format(metricName,sample.name))
                                        d={metricName:val}
                                        val = KubeUtil.get_value_from_expression(expression,d,round_off)

                                    if rootVal and (not valCheck or (valCheck and check_val_condition(val,valCond,valThreshold))):
                                       childDic = get_from_data_dic(rootVal,groupDic)

                                       if adder and metricShortName in childDic:
                                           val = childDic[metricShortName] + val

                                       map_label_values(labelXmlDic,labelDataDic,childDic) #map label values

                                       if mapCheck:
                                           AgentLogger.debug(AgentLogger.KUBERNETES,'mapCheck true')
                                           if mapName:
                                               if mapName in childDic:
                                                   mapDic = childDic[mapName]
                                               else:
                                                   mapDic = {}
                                               create_map_key_val(childDic,mapKeyLabel,mapValLabel,mapDic)
                                               AgentLogger.debug(AgentLogger.KUBERNETES,'mapName - {0}'.format(mapName))
                                               childDic[mapName] = mapDic
                                               AgentLogger.debug(AgentLogger.KUBERNETES,'mapDic - {0}'.format(json.dumps(mapDic)))
                                           else:
                                                create_map_key_val(childDic,mapKeyLabel,mapValLabel,childDic)
                                                AgentLogger.debug(AgentLogger.KUBERNETES,'childDic - {0}'.format(json.dumps(childDic)))
                                       else:
                                           if valLabel and valLabel in childDic:
                                               toaddVal = childDic[valLabel]
                                               AgentLogger.debug(AgentLogger.KUBERNETES,'toaddVal - {0}'.format(toaddVal))
                                               childDic[metricShortName] = toaddVal
                                           else:
                                               childDic[metricShortName] = val

                                       groupDic[rootVal] = childDic #add it back to groupDic

                                       if countCheck and (countLabel in childDic): #check count
                                          AgentLogger.debug(AgentLogger.KUBERNETES,'countingCheck - {0}'.format(countLabel))
                                          labelVal = childDic[countLabel]
                                          countName = countShortName + "_" + labelVal
                                          AgentLogger.debug(AgentLogger.KUBERNETES,'countName - {0}'.format(countName))
                                          count_metrics(countName,countDic)
                                    else:
                                        AgentLogger.debug(AgentLogger.KUBERNETES,'ProcessMetrics -> valCheck failed')
                                else:
                                    AgentLogger.debug(AgentLogger.KUBERNETES,'ProcessMetrics -> no labels')
                                    if val:
                                        AgentLogger.debug(AgentLogger.KUBERNETES,'value->{0}'.format(val))
                                        groupDic[metricShortName] = val
                                    else:
                                        AgentLogger.debug(AgentLogger.KUBERNETES,'no val')

                        except Exception as e:
                            AgentLogger.log(AgentLogger.KUBERNETES,'Exception -> ProcessMetrics -> adding values - {0}'.format(e))
                    break

                #add count values
                add_count_metrics_to_data_dic(countDic,groupDic)
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'Exception -> ParseGroup -> {0}'.format(e))
        
def add_count_metrics_to_data_dic(countDic,dataDic):
    AgentLogger.debug(AgentLogger.KUBERNETES,'inside AddCountMetricsToDataDic')
    try:
        if not dataDic:
            dataDic = {}

        if countDic:
            for key in countDic.keys():
                AgentLogger.debug(AgentLogger.KUBERNETES,'key - {0}'.format(key))
                dataDic[key] = countDic[key]
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'Exception -> AddCountMetricsToDataDic -> {0}'.format(e))

def count_metrics(key,countDic):
    AgentLogger.debug(AgentLogger.KUBERNETES,'inside CountMetrics')
    try:
        if key:
            AgentLogger.debug(AgentLogger.KUBERNETES,'count metrics key - {0}'.format(key))
            count = 0
            if key in countDic:
                count = countDic[key]
                AgentLogger.debug(AgentLogger.KUBERNETES,'count - {0}'.format(count))
            countDic[key] = count + 1
            AgentLogger.debug(AgentLogger.KUBERNETES,'countDic')
            AgentLogger.debug(AgentLogger.KUBERNETES,json.dumps(countDic))
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'Exception -> CountMetrics -> {0}'.format(e))

def map_label_values(labelXmlDic,labelDataDic,thisDic):
    #AgentLogger.log(AgentLogger.KUBERNETES,'Inside MapLabelValues.....')
    try:
        for key in labelXmlDic.keys():
            labelShortName = labelXmlDic[key]
            if key in labelDataDic:
                thisDic[labelShortName] = labelDataDic[key]
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'Exception -> MapLabelValues -> {0}'.format(e))
        
def create_map_key_val(dataDic,keyName,valName,toAddDic):
    try:
        if toAddDic is None:
            toAddDic = {}
        if dataDic and keyName and valName:
            if keyName in dataDic and valName in dataDic:
                keyVal = dataDic[keyName]
                val = dataDic[valName]
                toAddDic[keyVal] = val
            else:
                AgentLogger.debug(AgentLogger.KUBERNETES,'create_map_key_val -> key - {0} not mapped'.format(keyName))
                AgentLogger.debug(AgentLogger.KUBERNETES,'create_map_key_val -> Val - {0}'.format(valName))
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'Exception -> create_map_key_val -> {0}'.format(e))
        
def get_label_root_name_val(labelRootList,labelDataDic):
    labelRootVal = None
    try:
        if labelRootList and labelDataDic:
            for root in labelRootList:
                if root in labelDataDic:
                    if labelRootVal:
                        labelRootVal = labelRootVal + "_" + labelDataDic[root]
                    else:
                        labelRootVal = labelDataDic[root]
                else:
                    AgentLogger.debug(AgentLogger.KUBERNETES,'get_label_root_name_val -> root not present in data dic - {0}'.format(root))
        else:
            AgentLogger.debug(AgentLogger.KUBERNETES,'get_label_root_name_val -> empty inputs - labelRootList or labelDataDic')
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'Exception -> get_label_root_name_val -> {0}'.format(e))
    return labelRootVal

def check_val_condition(value,condition,threshold):
    AgentLogger.debug(AgentLogger.KUBERNETES,'inside CheckValCondition.....')
    try:
        if value and condition and threshold:
            if condition == "Equals" and value==float(threshold):
                   return True
            if condition == "Gt" and value > int(threshold):
                return True
            if condition == "Lt" and value < int(threshold):
                return True
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'Exception -> CheckValCondition -> {0}'.format(e))
    return False

def process_labels(labels):
    try:
        AgentLogger.debug(AgentLogger.KUBERNETES,'inside processlabels....{0}'.format(type(labels)))
        #get root Name
        rootNameList = []
        for root in labels.findall('Root'):
            rootNameList.append(root.get('Name'))
        AgentLogger.debug(AgentLogger.KUBERNETES,'rootNameList - {0}'.format(rootNameList))

        #get labels
        labelXmlDic = {}
        for label in labels.findall('Label'):
            labelXmlDic[label.get('Name')] = label.get('ShortName')
        return rootNameList,labelXmlDic
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'Exception -> ProcessLabels -> {0}'.format(e))

def get_from_data_dic(key,dic):
    try:
        if key and dic:
            if key in dic:
                return dic[key]
        return {}
    except Exception as e:
        AgentLogger.log(AgentLogger.KUBERNETES,'Exception -> getFromDataDic -> {0}'.format(e))