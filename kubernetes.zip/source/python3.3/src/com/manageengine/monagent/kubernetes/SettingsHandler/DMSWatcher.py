import json
import time
import traceback
import os

from com.manageengine.monagent.kubernetes import KubeGlobal
from com.manageengine.monagent.kubernetes.Logging import KubeLogger
from com.manageengine.monagent.kubernetes.SettingsHandler import KubeActions

def start_dms_message_watcher():
    while True:
        try:
            read_dms_message()
            time.sleep(10)
        except Exception as e:
            traceback.print_exc()
            KubeLogger.log(KubeLogger.KUBERNETES, "********** Exception -> DMS Message Watcher -> {} **********".format(e))

def read_dms_message():
    if os.path.exists(os.path.join(KubeGlobal.KUBE_DMS_FOLDER, 'k8s_dms.json')):
        with open(os.path.join(KubeGlobal.KUBE_DMS_FOLDER, 'k8s_dms.json'), 'r') as file:
            dms_json = json.load(file)
            for dms_key, dms_dict in dms_json.items():
                KubeActions.kube_agent_action_handler(dms_dict)
        os.remove(os.path.join(KubeGlobal.KUBE_DMS_FOLDER, 'k8s_dms.json'))
